import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import * as dotenv from 'dotenv';
import { requireAuth, AuthRequest } from './src/middleware/auth.ts';
import { getOrCreateUser, updateUserRole, getAllUsers } from './src/db/users.ts';
import {
  getAllErpData,
  logAuditAction,
  createAttendanceLog,
  createEmployee,
  createPayrollRecord,
  createInventoryItem,
  updateInventoryStock,
  createProductionBatch,
  createWastageLog,
  createSalesInvoice,
  recordDueCollection,
  createOperatingExpense,
  createEquityRecord,
  createLoanLiability,
  payLoanInstallment,
  createBankCashAccount,
  executeFundTransfer,
  createSystemOfficerUser,
  updateErpRecord,
  deleteErpRecord,
} from './src/db/erp.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '5mb' }));

  async function getUserContext(req: AuthRequest) {
    const uid = req.user!.uid;
    const email = req.user!.email || 'user@mrmushroom.com.bd';
    const displayName = req.user!.name || email.split('@')[0];
    const dbUser = await getOrCreateUser(uid, email, displayName);
    return dbUser;
  }

  // Bootstrap all ERP modules
  app.get('/api/erp/bootstrap', requireAuth, async (req: AuthRequest, res) => {
    try {
      const currentUser = await getUserContext(req);
      const [erpData, systemUsers] = await Promise.all([
        getAllErpData(),
        getAllUsers(),
      ]);
      res.json({
        currentUser,
        systemUsers,
        ...erpData,
      });
    } catch (error: any) {
      console.error('Bootstrap error:', error);
      res.status(500).json({ error: error.message || 'Failed to load ERP data' });
    }
  });

  // Switch/Update Role
  app.post('/api/erp/role', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { role } = req.body;
      const currentUser = await getUserContext(req);
      const updated = await updateUserRole(currentUser.uid, role);
      await logAuditAction({
        userEmail: currentUser.email,
        userName: currentUser.name,
        userRole: role,
        action: 'UPDATE',
        module: 'Audit & RBAC',
        entityRef: currentUser.email,
        details: `Updated active RBAC role to ${role}`,
      });
      res.json(updated);
    } catch (error: any) {
      console.error('Role update error:', error);
      res.status(500).json({ error: error.message || 'Failed to update role' });
    }
  });

  // Module 1: HR Officers/Team Members, Attendance & Payroll
  app.post('/api/erp/employees', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createEmployee(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'HR & Payroll',
        entityRef: created.empCode,
        details: `Added Officer / Team Member ${created.name} (${created.designation}) · Base BDT ${created.baseSalary}`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to add employee' });
    }
  });

  app.post('/api/erp/attendance', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createAttendanceLog(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'HR & Payroll',
        entityRef: `${created.empCode} (${created.date})`,
        details: `Logged ${created.status} for ${created.empName} · OT: ${created.overtimeHours}h`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to log attendance' });
    }
  });

  app.post('/api/erp/payroll', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createPayrollRecord(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'HR & Payroll',
        entityRef: `${created.empCode}-${created.monthYear}`,
        details: `Processed payroll for ${created.empName} (${created.monthYear}) · Net Payable BDT ${created.netPayable}`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to create payroll record' });
    }
  });

  // Module 2: Inventory & Batch Production
  app.post('/api/erp/inventory', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createInventoryItem(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'Inventory & Batch',
        entityRef: created.sku,
        details: `Created SKU ${created.name} · Stock: ${created.currentStock} ${created.unit}`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to create inventory item' });
    }
  });

  app.put('/api/erp/inventory/:id/quick-stock', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const id = Number(req.params.id);
      const { currentStock, unitCost, sellingPrice } = req.body;
      const updated = await updateInventoryStock(
        id,
        Number(currentStock),
        Number(unitCost),
        Number(sellingPrice)
      );
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        module: 'Inventory & Batch',
        entityRef: updated.sku,
        details: `Adjusted stock for ${updated.name} to ${updated.currentStock} ${updated.unit}`,
      });
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to update inventory stock' });
    }
  });

  app.post('/api/erp/batches', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createProductionBatch(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'Inventory & Batch',
        entityRef: created.batchCode,
        details: `Logged production batch ${created.batchCode} (${created.mushroomVariety}) · Yield: ${created.actualYieldKg} kg`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to create production batch' });
    }
  });

  app.post('/api/erp/wastage', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createWastageLog(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'Inventory & Batch',
        entityRef: created.batchCode,
        details: `Recorded spoilage/wastage: ${created.quantity} ${created.unit} ${created.itemName} (Loss: BDT ${created.estimatedLossBdt})`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to record wastage' });
    }
  });

  // Module 3: Sales, POS & Invoicing
  app.post('/api/erp/sales', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createSalesInvoice(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'Sales & POS',
        entityRef: created.invoiceNo,
        details: `Issued ${created.channel} Invoice to ${created.customerName} · Net BDT ${created.netPayableBdt} (Due: BDT ${created.dueAmountBdt})`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to create sales invoice' });
    }
  });

  app.post('/api/erp/sales/:id/collect', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const id = Number(req.params.id);
      const { amount } = req.body;
      const updated = await recordDueCollection(id, Number(amount));
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        module: 'Sales & POS',
        entityRef: updated.invoiceNo,
        details: `Collected customer due BDT ${amount} for ${updated.invoiceNo} (${updated.customerName})`,
      });
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to collect due payment' });
    }
  });

  // Module 4: Operating Expenses
  app.post('/api/erp/expenses', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createOperatingExpense(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'Operating Expenses',
        entityRef: created.voucherNo,
        details: `Posted OpEx ${created.category}: BDT ${created.amountBdt} via ${created.paymentSource}`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to create operating expense' });
    }
  });

  // Module 5: Investment & Equity
  app.post('/api/erp/equity', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createEquityRecord(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'Equity & Capital',
        entityRef: created.shareholderName,
        details: `Recorded ${created.transactionType} for ${created.shareholderName} (${created.sharePercentage}% equity)`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to record equity entry' });
    }
  });

  // Module 6: Loans & Liabilities
  app.post('/api/erp/loans', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createLoanLiability(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'Loans & Liabilities',
        entityRef: created.referenceNo,
        details: `Added ${created.liabilityType} (${created.lenderOrSupplierName}) · Outstanding: BDT ${created.outstandingBalanceBdt}`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to create liability record' });
    }
  });

  app.post('/api/erp/loans/:id/pay', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const id = Number(req.params.id);
      const { amount } = req.body;
      const updated = await payLoanInstallment(id, Number(amount));
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        module: 'Loans & Liabilities',
        entityRef: updated.referenceNo,
        details: `Paid installment/payable BDT ${amount} to ${updated.lenderOrSupplierName}`,
      });
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to record installment payment' });
    }
  });

  // Module 7: Banking & Cash Reconciliation
  app.post('/api/erp/accounts', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createBankCashAccount(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'Banking & Cash',
        entityRef: created.accountName,
        details: `Added ${created.accountType} account: ${created.accountName} (Balance: BDT ${created.currentBalanceBdt})`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to add bank/cash account' });
    }
  });

  app.post('/api/erp/transfers', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await executeFundTransfer(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'RECONCILE',
        module: 'Banking & Cash',
        entityRef: created.transferRef,
        details: `Transferred BDT ${created.amountBdt} from ${created.fromAccount} to ${created.toAccount}`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to execute fund transfer' });
    }
  });

  // Module 9: Add System Officer / Team User
  app.post('/api/erp/users', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const created = await createSystemOfficerUser(req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        module: 'Audit & RBAC',
        entityRef: created.email,
        details: `Granted ${created.role} access to ${created.name} (${created.email})`,
      });
      res.json(created);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to add system user' });
    }
  });

  // Universal Update Record Endpoint across ALL sections
  app.put('/api/erp/:moduleKey/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const { moduleKey, id } = req.params;
      const updated = await updateErpRecord(moduleKey, Number(id), req.body);
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        module: moduleKey.toUpperCase(),
        entityRef: `ID-${id}`,
        details: `Edited record #${id} in ${moduleKey} section`,
      });
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to update record' });
    }
  });

  // Universal Export Audit Logger
  app.post('/api/erp/audit-export', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const { moduleName, format, recordCount, fileName } = req.body;
      const entry = await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'EXPORT',
        module: moduleName || 'Universal Export',
        entityRef: fileName || format,
        details: `Exported ${recordCount} rows from ${moduleName} to ${format} (${fileName})`,
      });
      res.json(entry);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to log export audit' });
    }
  });

  // Universal Delete Record Endpoint across ALL sections
  app.delete('/api/erp/:moduleKey/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserContext(req);
      const { moduleKey, id } = req.params;
      const result = await deleteErpRecord(moduleKey, Number(id));
      await logAuditAction({
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'DELETE',
        module: moduleKey.toUpperCase(),
        entityRef: `ID-${id}`,
        details: `Deleted record #${id} from ${moduleKey} section`,
      });
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to delete record' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Mr. Mushroom ERP Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
