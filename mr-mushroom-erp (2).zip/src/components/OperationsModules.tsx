import React, { useState } from 'react';
import { Plus, Trash2, Pencil, Printer, AlertTriangle, DollarSign, UserPlus, Check, Download } from 'lucide-react';
import { UniversalExportBar } from './UniversalExportBar.tsx';
import {
  SalesInvoiceRecord,
  printInvoiceDocument,
  downloadInvoicePdfDocument,
} from './InvoicePrintModal.tsx';

interface OperationsProps {
  activeSubTab: 'attendance' | 'inventory' | 'sales';
  data: any;
  userRole: string;
  onApiPost: (endpoint: string, body: any) => Promise<void>;
  onApiPut: (endpoint: string, body: any) => Promise<void>;
  onApiDelete: (moduleKey: string, id: number) => Promise<void>;
  onOpenEditModal: (moduleKey: string, record: any) => void;
  onLogExport: (moduleName: string, format: string, recordCount: number, fileName: string) => void;
  onOpenInvoiceModal: (inv: SalesInvoiceRecord, format: 'a4' | 'thermal') => void;
}

export const OperationsModules: React.FC<OperationsProps> = ({
  activeSubTab,
  data,
  onApiPost,
  onApiPut,
  onApiDelete,
  onOpenEditModal,
  onLogExport,
  onOpenInvoiceModal,
}) => {
  // Module 1: HR Officer / Team Member Add Form State
  const [empForm, setEmpForm] = useState({
    empCode: `MM-EMP-00${(data.employees?.length || 5) + 1}`,
    name: '',
    designation: '',
    department: 'Cultivation House A & B',
    baseSalary: '25000',
    hourlyOvertimeRate: '150',
    phone: '',
    status: 'Active',
  });

  // Module 1: Daily Attendance State
  const [attForm, setAttForm] = useState({
    empCode: 'MM-EMP-001',
    date: new Date().toISOString().slice(0, 10),
    checkIn: '08:55',
    checkOut: '18:00',
    status: 'Present',
    overtimeHours: '1.0',
    notes: '',
  });

  // Module 1: Monthly Payroll State
  const [payForm, setPayForm] = useState({
    empCode: 'MM-EMP-001',
    monthYear: '2026-10',
    presentDays: '26',
    absentDays: '0',
    leaveDays: '0',
    overtimeHours: '16',
    bonusAdditions: '1500',
    deductions: '0',
    paymentStatus: 'Paid',
    paymentMethod: 'Bank',
  });

  // Module 2 States
  const [invForm, setInvForm] = useState({
    sku: 'MM-RAW-004',
    name: '',
    category: 'Raw Material',
    unit: 'kg',
    currentStock: '',
    reorderLevel: '100',
    unitCost: '',
    sellingPrice: '0',
  });

  const [batchForm, setBatchForm] = useState({
    batchCode: `BATCH-2026-${106 + (data.productionBatches?.length || 0)}`,
    mushroomVariety: 'Pearl Oyster (Pleurotus ostreatus)',
    bagCount: '1000',
    substrateKg: '1500',
    spawnKg: '80',
    inoculationDate: new Date().toISOString().slice(0, 10),
    expectedHarvestDate: '2026-10-28',
    actualYieldKg: '520',
    totalCogs: '65000',
    status: 'Fruiting',
  });

  const [wasteForm, setWasteForm] = useState({
    batchCode: 'BATCH-2026-101',
    itemName: 'Oyster Substrate Cylinders',
    category: 'Contamination',
    quantity: '10',
    unit: 'pcs',
    estimatedLossBdt: '650',
    reason: 'High humidity condensation spot',
    loggedDate: new Date().toISOString().slice(0, 10),
  });

  // Module 3 States (Sales & POS)
  const [posChannel, setPosChannel] = useState('Wholesale');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [selectedSku, setSelectedSku] = useState('MM-FIN-001');
  const [lineQty, setLineQty] = useState('10');
  const [linePrice, setLinePrice] = useState('280');
  const [lineDiscount, setLineDiscount] = useState('0');
  const [cartItems, setCartItems] = useState<
    { sku: string; name: string; qty: number; price: number; discount: number }[]
  >([
    {
      sku: 'MM-FIN-001',
      name: 'Fresh Pearl Oyster Mushroom (Grade A)',
      qty: 20,
      price: 280,
      discount: 200,
    },
  ]);
  const [invoiceDiscountType, setInvoiceDiscountType] = useState<'Flat' | 'Percentage'>('Flat');
  const [invoiceDiscountVal, setInvoiceDiscountVal] = useState('100');
  const [paidAmount, setPaidAmount] = useState('5000');
  const [paymentMethod, setPaymentMethod] = useState('Bkash');
  const [salesSearch, setSalesSearch] = useState('');
  const [saleSuccessMessage, setSaleSuccessMessage] = useState<string | null>(null);

  // Module 1 Handlers
  const handleAddEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!empForm.name || !empForm.designation) return;
    await onApiPost('/api/erp/employees', {
      empCode: empForm.empCode,
      name: empForm.name,
      designation: empForm.designation,
      department: empForm.department,
      baseSalary: Number(empForm.baseSalary) || 0,
      hourlyOvertimeRate: Number(empForm.hourlyOvertimeRate) || 0,
      phone: empForm.phone || '01700-000000',
      status: empForm.status,
    });
    setEmpForm({
      ...empForm,
      empCode: `MM-EMP-00${(data.employees?.length || 5) + 2}`,
      name: '',
      designation: '',
      phone: '',
    });
  };

  const handleAddAttendance = async (e: React.FormEvent) => {
    e.preventDefault();
    const emp =
      data.employees.find((x: any) => x.empCode === attForm.empCode) || data.employees[0];
    if (!emp) return;
    await onApiPost('/api/erp/attendance', {
      empCode: emp.empCode,
      empName: emp.name,
      department: emp.department,
      date: attForm.date,
      checkIn: attForm.checkIn,
      checkOut: attForm.checkOut,
      status: attForm.status,
      overtimeHours: Number(attForm.overtimeHours) || 0,
      notes: attForm.notes,
    });
    setAttForm({ ...attForm, notes: '' });
  };

  const handleGeneratePayroll = async (e: React.FormEvent) => {
    e.preventDefault();
    const emp =
      data.employees.find((x: any) => x.empCode === payForm.empCode) || data.employees[0];
    if (!emp) return;
    const otHours = Number(payForm.overtimeHours) || 0;
    const otPay = Number((otHours * emp.hourlyOvertimeRate).toFixed(2));
    const bonus = Number(payForm.bonusAdditions) || 0;
    const absentDays = Number(payForm.absentDays) || 0;
    const autoAbsentDeduction = Number(((emp.baseSalary / 30) * absentDays).toFixed(2));
    const manualDed = Number(payForm.deductions) || 0;
    const totalDeductions = Number((autoAbsentDeduction + manualDed).toFixed(2));
    const netPayable = Number((emp.baseSalary + otPay + bonus - totalDeductions).toFixed(2));

    await onApiPost('/api/erp/payroll', {
      empCode: emp.empCode,
      empName: emp.name,
      designation: emp.designation,
      monthYear: payForm.monthYear,
      baseSalary: emp.baseSalary,
      presentDays: Number(payForm.presentDays),
      absentDays,
      leaveDays: Number(payForm.leaveDays),
      overtimeHours: otHours,
      overtimePay: otPay,
      bonusAdditions: bonus,
      deductions: totalDeductions,
      netPayable,
      paymentStatus: payForm.paymentStatus,
      paymentMethod: payForm.paymentMethod,
    });
  };

  // Module 2 Handlers
  const handleAddInventory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!invForm.name) return;
    await onApiPost('/api/erp/inventory', {
      sku: invForm.sku,
      name: invForm.name,
      category: invForm.category,
      unit: invForm.unit,
      currentStock: Number(invForm.currentStock) || 0,
      reorderLevel: Number(invForm.reorderLevel) || 50,
      unitCost: Number(invForm.unitCost) || 0,
      sellingPrice: Number(invForm.sellingPrice) || 0,
    });
    setInvForm({
      ...invForm,
      sku: `MM-SKU-0${(data.inventoryItems?.length || 1) + 2}`,
      name: '',
    });
  };

  const handleAddBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    const yieldKg = Number(batchForm.actualYieldKg) || 0;
    const cogs = Number(batchForm.totalCogs) || 0;
    const costPerKg = yieldKg > 0 ? Number((cogs / yieldKg).toFixed(2)) : 0;
    await onApiPost('/api/erp/batches', {
      batchCode: batchForm.batchCode,
      mushroomVariety: batchForm.mushroomVariety,
      bagCount: Number(batchForm.bagCount) || 0,
      substrateKg: Number(batchForm.substrateKg) || 0,
      spawnKg: Number(batchForm.spawnKg) || 0,
      inoculationDate: batchForm.inoculationDate,
      expectedHarvestDate: batchForm.expectedHarvestDate,
      actualYieldKg: yieldKg,
      totalCogs: cogs,
      costPerKg,
      status: batchForm.status,
    });
  };

  const handleAddWastage = async (e: React.FormEvent) => {
    e.preventDefault();
    await onApiPost('/api/erp/wastage', {
      ...wasteForm,
      quantity: Number(wasteForm.quantity) || 0,
      estimatedLossBdt: Number(wasteForm.estimatedLossBdt) || 0,
    });
  };

  // Module 3 Handlers
  const handleAddLineItem = () => {
    const found = (data.inventoryItems || []).find((i: any) => i.sku === selectedSku);
    const name = found ? found.name : selectedSku;
    const qty = Math.max(1, Number(lineQty) || 1);
    const price =
      Number(linePrice) || (found ? found.sellingPrice || found.unitCost || 250 : 250);
    const discount = Number(lineDiscount) || 0;

    const existingIdx = cartItems.findIndex((c) => c.sku === selectedSku);
    if (existingIdx >= 0) {
      const updated = [...cartItems];
      updated[existingIdx] = {
        ...updated[existingIdx],
        qty: updated[existingIdx].qty + qty,
        price,
        discount: updated[existingIdx].discount + discount,
      };
      setCartItems(updated);
    } else {
      setCartItems([...cartItems, { sku: selectedSku, name, qty, price, discount }]);
    }
  };

  const subtotalBdt = cartItems.reduce((acc, item) => acc + item.qty * item.price, 0);
  const itemDiscountBdt = cartItems.reduce((acc, item) => acc + (item.discount || 0), 0);
  const afterItemDisc = Math.max(0, subtotalBdt - itemDiscountBdt);
  const invDiscNumeric = Number(invoiceDiscountVal) || 0;
  const invoiceLevelDiscBdt =
    invoiceDiscountType === 'Percentage'
      ? Number(((afterItemDisc * invDiscNumeric) / 100).toFixed(2))
      : invDiscNumeric;
  const totalDiscountBdt = Number((itemDiscountBdt + invoiceLevelDiscBdt).toFixed(2));
  const netPayableBdt = Math.max(0, Number((subtotalBdt - totalDiscountBdt).toFixed(2)));
  const paidNum = Number(paidAmount) || 0;
  const dueAmountBdt = Math.max(0, Number((netPayableBdt - paidNum).toFixed(2)));

  const submitInvoiceAndOptionallyPrintPos = async (shouldPrintPos: boolean) => {
    if (cartItems.length === 0) return;
    const nextNum = (data.salesInvoices?.length || 0) + 1;
    const invoiceNo = `INV-MM-2026-00${nextNum}`;
    const summary = cartItems.map((c) => `${c.name} (${c.qty})`).join(', ');
    const status = dueAmountBdt <= 0 ? 'Paid' : paidNum > 0 ? 'Partial' : 'Due';
    const todayDate = new Date().toISOString().slice(0, 10);

    const invoicePayload = {
      invoiceNo,
      date: todayDate,
      channel: posChannel,
      customerName: customerName || 'Walk-in Retail Customer',
      customerPhone: customerPhone || '01700-000000',
      itemsJson: JSON.stringify(cartItems),
      itemsSummary: summary,
      subtotalBdt,
      itemDiscountBdt,
      invoiceDiscountType,
      invoiceDiscountValue: invDiscNumeric,
      totalDiscountBdt,
      netPayableBdt,
      paidAmountBdt: Math.min(netPayableBdt, paidNum),
      dueAmountBdt,
      paymentMethod,
      status,
    };

    const deductedSummary = cartItems
      .map((c) => `${c.name}: -${c.qty}`)
      .join(', ');

    await onApiPost('/api/erp/sales', invoicePayload);
    setCustomerName('');
    setCustomerPhone('');
    setSaleSuccessMessage(
      `Invoice ${invoiceNo} created! Inventory stock automatically deducted (${deductedSummary}).`
    );
    setTimeout(() => setSaleSuccessMessage(null), 6000);

    if (shouldPrintPos) {
      const printableRecord: SalesInvoiceRecord = {
        id: Date.now(),
        ...invoicePayload,
      };
      onOpenInvoiceModal(printableRecord, 'thermal');
      printInvoiceDocument(printableRecord, 'thermal');
    }
  };

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    await submitInvoiceAndOptionallyPrintPos(false);
  };

  if (activeSubTab === 'attendance') {
    return (
      <div className="space-y-8">
        {/* 01. HR Officers & Team Members Directory (Add, Edit, Delete, Export) */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="01. HR Management: Officers & Team Members Directory"
            moduleName="HR & Payroll"
            fileNamePrefix="Mr_Mushroom_HR_Team_Directory"
            sheetName="HR_Officers_Team"
            rows={data.employees || []}
            onLogExport={onLogExport}
          />

          <form
            onSubmit={handleAddEmployee}
            className="grid grid-cols-1 md:grid-cols-8 gap-3 mt-4 pb-4 border-b border-slate-200"
          >
            <input
              type="text"
              placeholder="ID Code (MM-EMP-006)"
              value={empForm.empCode}
              onChange={(e) => setEmpForm({ ...empForm, empCode: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              required
            />
            <input
              type="text"
              placeholder="Officer / Member Name"
              value={empForm.name}
              onChange={(e) => setEmpForm({ ...empForm, name: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md md:col-span-2"
              required
            />
            <input
              type="text"
              placeholder="Designation / Role"
              value={empForm.designation}
              onChange={(e) => setEmpForm({ ...empForm, designation: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
              required
            />
            <select
              value={empForm.department}
              onChange={(e) => setEmpForm({ ...empForm, department: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            >
              <option value="Spawn & Tissue Culture Lab">Spawn & Tissue Culture Lab</option>
              <option value="Finance & Accounts">Finance & Accounts</option>
              <option value="Cultivation House A & B">Cultivation House A & B</option>
              <option value="Sterilization Unit">Sterilization Unit</option>
              <option value="Processing & Powder Unit">Processing & Powder Unit</option>
              <option value="Sales & Distribution">Sales & Distribution</option>
              <option value="Management & HR">Management & HR</option>
            </select>
            <input
              type="number"
              placeholder="Base Salary (৳)"
              value={empForm.baseSalary}
              onChange={(e) => setEmpForm({ ...empForm, baseSalary: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              title="Monthly Base Salary (BDT)"
              required
            />
            <input
              type="text"
              placeholder="Phone (017XX...)"
              value={empForm.phone}
              onChange={(e) => setEmpForm({ ...empForm, phone: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 rounded-md hover:bg-emerald-600 cursor-pointer whitespace-nowrap"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Add Member</span>
            </button>
          </form>

          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Officer Code</th>
                  <th className="py-2.5 px-3 font-medium">Name & Designation</th>
                  <th className="py-2.5 px-3 font-medium">Department</th>
                  <th className="py-2.5 px-3 font-medium">Phone</th>
                  <th className="py-2.5 px-3 font-medium text-right">Base Salary (৳)</th>
                  <th className="py-2.5 px-3 font-medium text-right">OT Rate (৳/hr)</th>
                  <th className="py-2.5 px-3 font-medium">Status</th>
                  <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {(data.employees || []).map((emp: any) => (
                  <tr key={emp.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                      {emp.empCode}
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-slate-900">{emp.name}</div>
                      <div className="text-[11px] text-slate-500">{emp.designation}</div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-700">{emp.department}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">{emp.phone}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold text-slate-900">
                      ৳{emp.baseSalary.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                      ৳{emp.hourlyOvertimeRate}/hr
                    </td>
                    <td className="py-2.5 px-3 font-medium text-emerald-800">{emp.status}</td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenEditModal('employees', emp)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                          title="Edit Officer / Team Member"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onApiDelete('employees', emp.id)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                          title="Delete Officer / Team Member"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* 02. Daily Attendance Form + Table */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="02. Daily Employee Attendance & Overtime Register"
            moduleName="Attendance & Payroll"
            fileNamePrefix="Mr_Mushroom_Attendance_Log"
            sheetName="Attendance_Logs"
            rows={data.attendanceLogs || []}
            onLogExport={onLogExport}
          />

          <form
            onSubmit={handleAddAttendance}
            className="grid grid-cols-1 md:grid-cols-7 gap-3 mt-4 pb-4 border-b border-slate-200"
          >
            <select
              value={attForm.empCode}
              onChange={(e) => setAttForm({ ...attForm, empCode: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md md:col-span-2"
            >
              {(data.employees || []).map((emp: any) => (
                <option key={emp.id} value={emp.empCode}>
                  {emp.empCode} · {emp.name}
                </option>
              ))}
            </select>
            <input
              type="date"
              value={attForm.date}
              onChange={(e) => setAttForm({ ...attForm, date: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <div className="flex items-center gap-1">
              <input
                type="time"
                value={attForm.checkIn}
                onChange={(e) => setAttForm({ ...attForm, checkIn: e.target.value })}
                className="w-full px-2 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
                title="Check-In Time"
              />
              <input
                type="time"
                value={attForm.checkOut}
                onChange={(e) => setAttForm({ ...attForm, checkOut: e.target.value })}
                className="w-full px-2 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
                title="Check-Out Time"
              />
            </div>
            <select
              value={attForm.status}
              onChange={(e) => setAttForm({ ...attForm, status: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            >
              <option value="Present">Present</option>
              <option value="Late">Late</option>
              <option value="Leave">Leave</option>
              <option value="Absent">Absent</option>
            </select>
            <input
              type="number"
              step="0.5"
              placeholder="OT Hours"
              value={attForm.overtimeHours}
              onChange={(e) => setAttForm({ ...attForm, overtimeHours: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Attendance</span>
            </button>
          </form>

          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Date</th>
                  <th className="py-2.5 px-3 font-medium">Employee</th>
                  <th className="py-2.5 px-3 font-medium">Department</th>
                  <th className="py-2.5 px-3 font-medium">Check-In / Out</th>
                  <th className="py-2.5 px-3 font-medium">Status</th>
                  <th className="py-2.5 px-3 font-medium text-right">Overtime (Hrs)</th>
                  <th className="py-2.5 px-3 font-medium">Shift Notes</th>
                  <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {(data.attendanceLogs || []).map((row: any) => (
                  <tr key={row.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono tabular-nums text-slate-700">{row.date}</td>
                    <td className="py-2.5 px-3">
                      <span className="font-medium text-slate-900">{row.empName}</span>
                      <span className="text-slate-400 mx-1">·</span>
                      <span className="font-mono text-slate-500">{row.empCode}</span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">{row.department}</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-slate-700">
                      {row.checkIn} – {row.checkOut}
                    </td>
                    <td className="py-2.5 px-3 font-medium text-slate-800">{row.status}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-medium">
                      {row.overtimeHours.toFixed(1)} h
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">{row.notes || 'Regular shift'}</td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenEditModal('attendance', row)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onApiDelete('attendance', row.id)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* 03. Monthly Auto-Payroll Generator & Sheet */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="03. Monthly Auto-Calculated Payroll Register (Additions, Overtime & Deductions)"
            moduleName="Attendance & Payroll"
            fileNamePrefix="Mr_Mushroom_Payroll_Sheet"
            sheetName="Monthly_Payroll"
            rows={data.payrollRecords || []}
            onLogExport={onLogExport}
          />

          <form
            onSubmit={handleGeneratePayroll}
            className="grid grid-cols-1 md:grid-cols-8 gap-3 mt-4 pb-4 border-b border-slate-200"
          >
            <select
              value={payForm.empCode}
              onChange={(e) => setPayForm({ ...payForm, empCode: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md md:col-span-2"
            >
              {(data.employees || []).map((emp: any) => (
                <option key={emp.id} value={emp.empCode}>
                  {emp.name} (Base: ৳{emp.baseSalary})
                </option>
              ))}
            </select>
            <input
              type="month"
              value={payForm.monthYear}
              onChange={(e) => setPayForm({ ...payForm, monthYear: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <input
              type="number"
              placeholder="Absent Days"
              value={payForm.absentDays}
              onChange={(e) => setPayForm({ ...payForm, absentDays: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              title="Absent Days (Auto-deducts pro-rata base salary)"
            />
            <input
              type="number"
              placeholder="OT Hours"
              value={payForm.overtimeHours}
              onChange={(e) => setPayForm({ ...payForm, overtimeHours: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              title="Total Overtime Hours"
            />
            <input
              type="number"
              placeholder="Bonus (BDT)"
              value={payForm.bonusAdditions}
              onChange={(e) => setPayForm({ ...payForm, bonusAdditions: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              title="Festival / Production Bonus (BDT)"
            />
            <select
              value={payForm.paymentMethod}
              onChange={(e) => setPayForm({ ...payForm, paymentMethod: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            >
              <option value="Bank">Bank Transfer</option>
              <option value="Bkash">Bkash</option>
              <option value="Nagad">Nagad</option>
              <option value="Cash">Cash</option>
            </select>
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Run Payroll</span>
            </button>
          </form>

          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Month</th>
                  <th className="py-2.5 px-3 font-medium">Employee & Role</th>
                  <th className="py-2.5 px-3 font-medium text-right">Base Salary (৳)</th>
                  <th className="py-2.5 px-3 font-medium text-right">Days (P/A/L)</th>
                  <th className="py-2.5 px-3 font-medium text-right">OT Pay (৳)</th>
                  <th className="py-2.5 px-3 font-medium text-right">Bonus (৳)</th>
                  <th className="py-2.5 px-3 font-medium text-right">Deductions (৳)</th>
                  <th className="py-2.5 px-3 font-medium text-right">Net Payable (৳)</th>
                  <th className="py-2.5 px-3 font-medium">Disbursement</th>
                  <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {(data.payrollRecords || []).map((row: any) => (
                  <tr key={row.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono tabular-nums">{row.monthYear}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-medium text-slate-900">{row.empName}</div>
                      <div className="text-slate-500 text-[11px]">
                        {row.empCode} · {row.designation}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {row.baseSalary.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                      {row.presentDays}P / {row.absentDays}A / {row.leaveDays}L
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-700">
                      +{row.overtimePay.toLocaleString('en-BD')} ({row.overtimeHours}h)
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-700">
                      +{row.bonusAdditions.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-red-700">
                      -{row.deductions.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                      ৳{row.netPayable.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-slate-700">
                      {row.paymentStatus} · {row.paymentMethod}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenEditModal('payroll', row)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onApiDelete('payroll', row.id)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    );
  }

  if (activeSubTab === 'inventory') {
    return (
      <div className="space-y-8">
        {/* Raw Material, Spawn & Finished Product Stock */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="01. Raw Materials, Spawn, Packaging & Processed Mushroom Inventory"
            moduleName="Inventory & Batch"
            fileNamePrefix="Mr_Mushroom_Inventory_Stock"
            sheetName="Inventory_Stock"
            rows={data.inventoryItems || []}
            onLogExport={onLogExport}
          />

          <form
            onSubmit={handleAddInventory}
            className="grid grid-cols-1 md:grid-cols-8 gap-3 mt-4 pb-4 border-b border-slate-200"
          >
            <input
              type="text"
              placeholder="SKU (e.g. MM-RAW-04)"
              value={invForm.sku}
              onChange={(e) => setInvForm({ ...invForm, sku: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              required
            />
            <input
              type="text"
              placeholder="Item Name (Sawdust, Spawn, Powder)"
              value={invForm.name}
              onChange={(e) => setInvForm({ ...invForm, name: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md md:col-span-2"
              required
            />
            <select
              value={invForm.category}
              onChange={(e) => setInvForm({ ...invForm, category: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            >
              <option value="Raw Material">Raw Material</option>
              <option value="Spawn & Culture">Spawn & Culture</option>
              <option value="Packaging">Packaging</option>
              <option value="Fresh Produce">Fresh Produce</option>
              <option value="Processed Product">Processed Product</option>
            </select>
            <input
              type="number"
              placeholder="Current Stock"
              value={invForm.currentStock}
              onChange={(e) => setInvForm({ ...invForm, currentStock: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              required
            />
            <input
              type="number"
              placeholder="Unit Cost (৳)"
              value={invForm.unitCost}
              onChange={(e) => setInvForm({ ...invForm, unitCost: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              required
            />
            <input
              type="number"
              placeholder="Sell Price (৳)"
              value={invForm.sellingPrice}
              onChange={(e) => setInvForm({ ...invForm, sellingPrice: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add SKU</span>
            </button>
          </form>

          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">SKU</th>
                  <th className="py-2.5 px-3 font-medium">Item Name</th>
                  <th className="py-2.5 px-3 font-medium">Category</th>
                  <th className="py-2.5 px-3 font-medium text-right">Current Stock</th>
                  <th className="py-2.5 px-3 font-medium text-right">Reorder Level</th>
                  <th className="py-2.5 px-3 font-medium text-right">Unit Cost (৳)</th>
                  <th className="py-2.5 px-3 font-medium text-right">Stock Value (৳)</th>
                  <th className="py-2.5 px-3 font-medium">Stock Status</th>
                  <th className="py-2.5 px-3 font-medium text-right">Actions (Stock / Edit / Delete)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {(data.inventoryItems || []).map((item: any) => {
                  const isLow = item.currentStock <= item.reorderLevel;
                  const totalValue = item.currentStock * item.unitCost;
                  return (
                    <tr key={item.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-mono text-slate-600">{item.sku}</td>
                      <td className="py-2.5 px-3 font-medium text-slate-900">{item.name}</td>
                      <td className="py-2.5 px-3 text-slate-600">{item.category}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold">
                        {item.currentStock.toLocaleString('en-BD')} {item.unit}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-500">
                        {item.reorderLevel} {item.unit}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                        ৳{item.unitCost.toLocaleString('en-BD')}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold text-slate-900">
                        ৳{totalValue.toLocaleString('en-BD', { maximumFractionDigits: 0 })}
                      </td>
                      <td className="py-2.5 px-3">
                        {isLow ? (
                          <span className="inline-flex items-center gap-1 text-amber-700 font-semibold">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>Low Stock</span>
                          </span>
                        ) : (
                          <span className="text-emerald-700 font-medium">Optimal</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              onApiPut(`/api/erp/inventory/${item.id}/quick-stock`, {
                                currentStock: item.currentStock + 50,
                                unitCost: item.unitCost,
                                sellingPrice: item.sellingPrice,
                              })
                            }
                            className="px-2 py-1 text-[11px] font-mono font-medium bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded cursor-pointer"
                          >
                            +50
                          </button>
                          <button
                            type="button"
                            onClick={() => onOpenEditModal('inventory', item)}
                            className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                          >
                            <Pencil className="w-3 h-3" />
                            <span>Edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => onApiDelete('inventory', item.id)}
                            className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* Batch Production & CoGS Tracker */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="02. Mushroom Cultivation & Processing Batches (Yield & CoGS Analysis)"
            moduleName="Inventory & Batch"
            fileNamePrefix="Mr_Mushroom_Production_Batches"
            sheetName="Production_Batches"
            rows={data.productionBatches || []}
            onLogExport={onLogExport}
          />

          <form
            onSubmit={handleAddBatch}
            className="grid grid-cols-1 md:grid-cols-7 gap-3 mt-4 pb-4 border-b border-slate-200"
          >
            <input
              type="text"
              placeholder="Batch Code"
              value={batchForm.batchCode}
              onChange={(e) => setBatchForm({ ...batchForm, batchCode: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              required
            />
            <input
              type="text"
              placeholder="Variety / Product"
              value={batchForm.mushroomVariety}
              onChange={(e) => setBatchForm({ ...batchForm, mushroomVariety: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md md:col-span-2"
              required
            />
            <input
              type="number"
              placeholder="Bags Count"
              value={batchForm.bagCount}
              onChange={(e) => setBatchForm({ ...batchForm, bagCount: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <input
              type="number"
              placeholder="Yield (kg)"
              value={batchForm.actualYieldKg}
              onChange={(e) => setBatchForm({ ...batchForm, actualYieldKg: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <input
              type="number"
              placeholder="Total CoGS (৳)"
              value={batchForm.totalCogs}
              onChange={(e) => setBatchForm({ ...batchForm, totalCogs: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Batch</span>
            </button>
          </form>

          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Batch Code</th>
                  <th className="py-2.5 px-3 font-medium">Cultivation Variety / Line</th>
                  <th className="py-2.5 px-3 font-medium text-right">Autoclave Bags</th>
                  <th className="py-2.5 px-3 font-medium text-right">Substrate / Spawn</th>
                  <th className="py-2.5 px-3 font-medium text-right">Actual Yield</th>
                  <th className="py-2.5 px-3 font-medium text-right">Total CoGS (৳)</th>
                  <th className="py-2.5 px-3 font-medium text-right">Unit CoGS (৳/kg)</th>
                  <th className="py-2.5 px-3 font-medium">Stage</th>
                  <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {(data.productionBatches || []).map((b: any) => (
                  <tr key={b.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                      {b.batchCode}
                    </td>
                    <td className="py-2.5 px-3 text-slate-800">{b.mushroomVariety}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {b.bagCount.toLocaleString('en-BD')} bags
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                      {b.substrateKg} kg / {b.spawnKg} kg
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold text-emerald-700">
                      {b.actualYieldKg} kg
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      ৳{b.totalCogs.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold">
                      {b.costPerKg > 0 ? `৳${b.costPerKg.toFixed(1)}/kg` : 'In Progress'}
                    </td>
                    <td className="py-2.5 px-3 text-slate-700 font-medium">
                      {b.status} · {b.expectedHarvestDate}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenEditModal('batches', b)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onApiDelete('batches', b.id)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Wastage & Contamination Spoilage Log */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="03. Contamination, Spoilage & Wastage Register"
            moduleName="Inventory & Batch"
            fileNamePrefix="Mr_Mushroom_Wastage_Spoilage_Log"
            sheetName="Wastage_Spoilage"
            rows={data.wastageLogs || []}
            onLogExport={onLogExport}
          />

          <form
            onSubmit={handleAddWastage}
            className="grid grid-cols-1 md:grid-cols-6 gap-3 mt-4 pb-4 border-b border-slate-200"
          >
            <input
              type="text"
              placeholder="Batch Code"
              value={wasteForm.batchCode}
              onChange={(e) => setWasteForm({ ...wasteForm, batchCode: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <input
              type="text"
              placeholder="Affected Item"
              value={wasteForm.itemName}
              onChange={(e) => setWasteForm({ ...wasteForm, itemName: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            />
            <select
              value={wasteForm.category}
              onChange={(e) => setWasteForm({ ...wasteForm, category: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            >
              <option value="Contamination">Contamination (Trichoderma)</option>
              <option value="Post-Harvest Spoilage">Post-Harvest Spoilage</option>
              <option value="Packaging Damage">Packaging Damage</option>
              <option value="Processing Loss">Dehydration / Processing Loss</option>
            </select>
            <input
              type="number"
              placeholder="Est. Loss (৳)"
              value={wasteForm.estimatedLossBdt}
              onChange={(e) => setWasteForm({ ...wasteForm, estimatedLossBdt: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <input
              type="text"
              placeholder="Root Cause / Notes"
              value={wasteForm.reason}
              onChange={(e) => setWasteForm({ ...wasteForm, reason: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record Spoilage</span>
            </button>
          </form>

          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Date</th>
                  <th className="py-2.5 px-3 font-medium">Batch Ref</th>
                  <th className="py-2.5 px-3 font-medium">Item</th>
                  <th className="py-2.5 px-3 font-medium">Category</th>
                  <th className="py-2.5 px-3 font-medium text-right">Qty Lost</th>
                  <th className="py-2.5 px-3 font-medium text-right">Estimated Loss (৳)</th>
                  <th className="py-2.5 px-3 font-medium">Root Cause</th>
                  <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {(data.wastageLogs || []).map((w: any) => (
                  <tr key={w.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono tabular-nums">{w.loggedDate}</td>
                    <td className="py-2.5 px-3 font-mono">{w.batchCode}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-900">{w.itemName}</td>
                    <td className="py-2.5 px-3 text-amber-800 font-medium">{w.category}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {w.quantity} {w.unit}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold text-red-700">
                      ৳{w.estimatedLossBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">{w.reason}</td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenEditModal('wastage', w)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onApiDelete('wastage', w.id)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    );
  }

  // Module 3: Sales, POS & Multi-Format Invoicing
  const filteredSales = (data.salesInvoices || []).filter(
    (inv: any) =>
      inv.customerName.toLowerCase().includes(salesSearch.toLowerCase()) ||
      inv.invoiceNo.toLowerCase().includes(salesSearch.toLowerCase()) ||
      inv.channel.toLowerCase().includes(salesSearch.toLowerCase())
  );

  return (
    <div className="space-y-8">
      {/* Multi-Channel POS & Invoice Creator */}
      <section className="bg-white border border-slate-200 rounded-lg p-6">
        <div className="pb-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              01. Multi-Channel POS & Commercial Billing Terminal
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Supports Wholesale, Retail POS & E-commerce · Item-Level & Invoice-Level Discounts (Flat BDT or %) · Thermal 80mm & A4 Output
            </p>
          </div>
        </div>

        <form onSubmit={handleCreateInvoice} className="mt-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Sales Channel</label>
              <select
                value={posChannel}
                onChange={(e) => setPosChannel(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
              >
                <option value="Wholesale">Wholesale (B2B Superstores/Hotels)</option>
                <option value="Retail POS">Retail POS Counter</option>
                <option value="E-commerce">E-commerce & Online Delivery</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Customer / B2B Client Name
              </label>
              <input
                type="text"
                placeholder="e.g. Unimart Gulshan / Walk-in"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Customer Phone
              </label>
              <input
                type="text"
                placeholder="017XX-XXXXXX"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Payment Mode</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
              >
                <option value="Cash">Cash in Hand</option>
                <option value="Bkash">Bkash Merchant</option>
                <option value="Nagad">Nagad Business</option>
                <option value="Bank">Corporate Bank Transfer</option>
                <option value="Credit">Credit / Ledger Due</option>
              </select>
            </div>
          </div>

          {/* Line Item Builder */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-md space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-6 gap-2 items-end">
              <div className="md:col-span-2">
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Product SKU (Live Inventory Stock)
                </label>
                <select
                  value={selectedSku}
                  onChange={(e) => {
                    const sku = e.target.value;
                    setSelectedSku(sku);
                    const found = (data.inventoryItems || []).find((i: any) => i.sku === sku);
                    if (found) {
                      setLinePrice(String(found.sellingPrice > 0 ? found.sellingPrice : found.unitCost || 250));
                    }
                  }}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded"
                >
                  {(data.inventoryItems || []).map((i: any) => (
                    <option key={i.id} value={i.sku}>
                      {i.sku} · {i.name} (Stock: {i.currentStock} {i.unit} · ৳
                      {i.sellingPrice > 0 ? i.sellingPrice : i.unitCost})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Quantity
                </label>
                <input
                  type="number"
                  value={lineQty}
                  onChange={(e) => setLineQty(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Unit Price (৳)
                </label>
                <input
                  type="number"
                  value={linePrice}
                  onChange={(e) => setLinePrice(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Item Discount (৳)
                </label>
                <input
                  type="number"
                  value={lineDiscount}
                  onChange={(e) => setLineDiscount(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded"
                />
              </div>
              <button
                type="button"
                onClick={handleAddLineItem}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-800 text-white rounded hover:bg-slate-700 cursor-pointer whitespace-nowrap"
              >
                + Add Line Item
              </button>
            </div>

            {/* Cart Items Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-1.5">Product</th>
                    <th className="py-1.5 text-right">Current Stock</th>
                    <th className="py-1.5 text-right">Sale Qty</th>
                    <th className="py-1.5 text-right">Remaining Stock</th>
                    <th className="py-1.5 text-right">Rate (৳)</th>
                    <th className="py-1.5 text-right">Item Disc (৳)</th>
                    <th className="py-1.5 text-right">Line Net (৳)</th>
                    <th className="py-1.5 text-right">Remove</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {cartItems.map((c, idx) => {
                    const invItem = (data.inventoryItems || []).find(
                      (i: any) =>
                        i.sku === c.sku ||
                        i.name.trim().toLowerCase() === c.name.trim().toLowerCase()
                    );
                    const currentStock = invItem ? invItem.currentStock : 0;
                    const unit = invItem ? invItem.unit : 'unit';
                    const afterStock = Math.max(0, Number((currentStock - c.qty).toFixed(2)));
                    return (
                      <tr key={idx}>
                        <td className="py-1.5 font-medium text-slate-900">
                          {c.name} <span className="font-mono text-slate-500">({c.sku})</span>
                        </td>
                        <td className="py-1.5 text-right font-mono tabular-nums text-slate-600">
                          {currentStock} {unit}
                        </td>
                        <td className="py-1.5 text-right font-mono tabular-nums font-semibold text-slate-900">
                          {c.qty} {unit}
                        </td>
                        <td className="py-1.5 text-right font-mono tabular-nums font-semibold text-emerald-700">
                          {afterStock} {unit}
                        </td>
                        <td className="py-1.5 text-right font-mono tabular-nums">৳{c.price}</td>
                        <td className="py-1.5 text-right font-mono tabular-nums text-amber-700">
                          -৳{c.discount}
                        </td>
                        <td className="py-1.5 text-right font-mono tabular-nums font-semibold">
                          ৳{(c.qty * c.price - c.discount).toLocaleString('en-BD')}
                        </td>
                        <td className="py-1.5 text-right">
                          <button
                            type="button"
                            onClick={() => setCartItems(cartItems.filter((_, i) => i !== idx))}
                            className="text-red-600 hover:underline text-[11px] cursor-pointer"
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {saleSuccessMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-md flex items-center gap-2 text-xs font-medium text-emerald-900">
              <Check className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>{saleSuccessMessage}</span>
            </div>
          )}

          {/* Invoice Level Discount & Final Settlement Row */}
          <div className="grid grid-cols-1 md:grid-cols-6 gap-3 items-end pt-2">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Invoice Discount Mode
              </label>
              <select
                value={invoiceDiscountType}
                onChange={(e) => setInvoiceDiscountType(e.target.value as 'Flat' | 'Percentage')}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
              >
                <option value="Flat">Flat BDT (৳)</option>
                <option value="Percentage">Percentage (%)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Invoice Discount ({invoiceDiscountType === 'Percentage' ? '%' : '৳'})
              </label>
              <input
                type="number"
                value={invoiceDiscountVal}
                onChange={(e) => setInvoiceDiscountVal(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Paid Now (৳)</label>
              <input
                type="number"
                value={paidAmount}
                onChange={(e) => setPaidAmount(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              />
            </div>
            <div className="p-2.5 bg-slate-100 rounded-md text-xs">
              <div className="flex justify-between">
                <span className="text-slate-600">Net Payable:</span>
                <span className="font-mono font-bold text-slate-900">
                  ৳{netPayableBdt.toLocaleString('en-BD')}
                </span>
              </div>
              <div className="flex justify-between mt-0.5">
                <span className="text-slate-600">Ledger Due:</span>
                <span className="font-mono font-semibold text-red-700">
                  ৳{dueAmountBdt.toLocaleString('en-BD')}
                </span>
              </div>
            </div>
            <button
              type="submit"
              className="px-3.5 py-2.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-600 rounded-md cursor-pointer whitespace-nowrap"
            >
              Generate Invoice & Deduct Stock
            </button>
            <button
              type="button"
              onClick={() => submitInvoiceAndOptionallyPrintPos(true)}
              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md cursor-pointer whitespace-nowrap"
              title="Create Sales Invoice, deduct Inventory Stock, and immediately print 80mm POS Receipt"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Sale + Print POS (80mm)</span>
            </button>
          </div>
        </form>
      </section>

      {/* Sales Register & Customer Dues Ledger */}
      <section className="bg-white border border-slate-200 rounded-lg p-6">
        <UniversalExportBar
          title="02. Multi-Channel Sales Register & Customer Dues Ledger"
          moduleName="Sales & POS"
          fileNamePrefix="Mr_Mushroom_Sales_Register"
          sheetName="Sales_Register"
          rows={filteredSales}
          onLogExport={onLogExport}
        />

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <input
            type="text"
            placeholder="Filter by Invoice No, Customer, or Channel (Wholesale / Retail POS / E-commerce)..."
            value={salesSearch}
            onChange={(e) => setSalesSearch(e.target.value)}
            className="w-full max-w-md px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-md"
          />
          <div className="text-xs text-slate-600 font-mono tabular-nums">
            Total Receivables (Customer Dues):{' '}
            <span className="font-bold text-red-700">
              ৳
              {filteredSales
                .reduce((s: number, i: any) => s + (i.dueAmountBdt || 0), 0)
                .toLocaleString('en-BD')}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs text-slate-500">
                <th className="py-2.5 px-3 font-medium">Invoice & Date</th>
                <th className="py-2.5 px-3 font-medium">Customer & Channel</th>
                <th className="py-2.5 px-3 font-medium">Items Summary</th>
                <th className="py-2.5 px-3 font-medium text-right">Net Payable (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Paid (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Due (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">
                  Actions (Print / Settle / Edit / Delete)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {filteredSales.map((inv: SalesInvoiceRecord) => (
                <tr key={inv.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3">
                    <div className="font-mono font-semibold text-slate-900">{inv.invoiceNo}</div>
                    <div className="font-mono text-[11px] text-slate-500">{inv.date}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-medium text-slate-900">{inv.customerName}</div>
                    <div className="text-[11px] text-slate-500">
                      {inv.channel} · {inv.paymentMethod}
                    </div>
                  </td>
                  <td
                    className="py-2.5 px-3 text-slate-600 max-w-xs truncate"
                    title={inv.itemsSummary}
                  >
                    {inv.itemsSummary}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                    ৳{inv.netPayableBdt.toLocaleString('en-BD')}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-700">
                    ৳{inv.paidAmountBdt.toLocaleString('en-BD')}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold text-red-700">
                    ৳{inv.dueAmountBdt.toLocaleString('en-BD')}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          onOpenInvoiceModal(inv, 'a4');
                        }}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer whitespace-nowrap"
                        title="View & Print Standard A4 Invoice"
                      >
                        <Printer className="w-3 h-3" />
                        <span>A4</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onOpenInvoiceModal(inv, 'thermal');
                          printInvoiceDocument(inv, 'thermal');
                        }}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-mono font-semibold bg-slate-900 hover:bg-slate-800 text-white rounded cursor-pointer whitespace-nowrap"
                        title="Print 80mm POS Thermal Receipt Immediately"
                      >
                        <Printer className="w-3 h-3" />
                        <span>POS 80mm</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => downloadInvoicePdfDocument(inv, 'thermal')}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-mono font-medium bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded cursor-pointer whitespace-nowrap"
                        title="Download 80mm POS Receipt PDF"
                      >
                        <Download className="w-3 h-3" />
                        <span>POS PDF</span>
                      </button>
                      {inv.dueAmountBdt > 0 && (
                        <button
                          type="button"
                          onClick={() =>
                            onApiPost(`/api/erp/sales/${inv.id}/collect`, {
                              amount: inv.dueAmountBdt,
                            })
                          }
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded cursor-pointer whitespace-nowrap"
                          title="Settle remaining customer due"
                        >
                          <DollarSign className="w-3 h-3" />
                          <span>Settle</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onOpenEditModal('sales', inv)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                      >
                        <Pencil className="w-3 h-3" />
                        <span>Edit</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onApiDelete('sales', inv.id)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
