import React, { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';

export interface EditFieldConfig {
  key: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'time' | 'select';
  options?: string[];
}

export const EDIT_SCHEMAS: Record<string, { title: string; fields: EditFieldConfig[] }> = {
  employees: {
    title: 'Edit HR Officer / Team Member',
    fields: [
      { key: 'empCode', label: 'Officer / Employee Code', type: 'text' },
      { key: 'name', label: 'Full Name', type: 'text' },
      { key: 'designation', label: 'Designation / Role', type: 'text' },
      {
        key: 'department',
        label: 'Department',
        type: 'select',
        options: [
          'Spawn & Tissue Culture Lab',
          'Finance & Accounts',
          'Cultivation House A & B',
          'Sterilization Unit',
          'Processing & Powder Unit',
          'Sales & Distribution',
          'Management & HR',
        ],
      },
      { key: 'baseSalary', label: 'Monthly Base Salary (BDT ৳)', type: 'number' },
      { key: 'hourlyOvertimeRate', label: 'Hourly Overtime Rate (BDT ৳)', type: 'number' },
      { key: 'phone', label: 'Mobile Number', type: 'text' },
      {
        key: 'status',
        label: 'Employment Status',
        type: 'select',
        options: ['Active', 'On Leave', 'Probation', 'Resigned'],
      },
    ],
  },
  attendance: {
    title: 'Edit Daily Attendance Log',
    fields: [
      { key: 'empCode', label: 'Employee Code', type: 'text' },
      { key: 'empName', label: 'Employee Name', type: 'text' },
      { key: 'department', label: 'Department', type: 'text' },
      { key: 'date', label: 'Date', type: 'date' },
      { key: 'checkIn', label: 'Check-In Time', type: 'time' },
      { key: 'checkOut', label: 'Check-Out Time', type: 'time' },
      {
        key: 'status',
        label: 'Attendance Status',
        type: 'select',
        options: ['Present', 'Late', 'Leave', 'Absent'],
      },
      { key: 'overtimeHours', label: 'Overtime Hours', type: 'number' },
      { key: 'notes', label: 'Shift Notes', type: 'text' },
    ],
  },
  payroll: {
    title: 'Edit Monthly Payroll Record',
    fields: [
      { key: 'empCode', label: 'Employee Code', type: 'text' },
      { key: 'empName', label: 'Employee Name', type: 'text' },
      { key: 'designation', label: 'Designation', type: 'text' },
      { key: 'monthYear', label: 'Payroll Month (YYYY-MM)', type: 'text' },
      { key: 'baseSalary', label: 'Base Salary (৳)', type: 'number' },
      { key: 'presentDays', label: 'Present Days', type: 'number' },
      { key: 'absentDays', label: 'Absent Days', type: 'number' },
      { key: 'leaveDays', label: 'Leave Days', type: 'number' },
      { key: 'overtimeHours', label: 'Overtime Hours', type: 'number' },
      { key: 'overtimePay', label: 'Overtime Pay (৳)', type: 'number' },
      { key: 'bonusAdditions', label: 'Bonus / Additions (৳)', type: 'number' },
      { key: 'deductions', label: 'Total Deductions (৳)', type: 'number' },
      { key: 'netPayable', label: 'Net Payable (৳)', type: 'number' },
      {
        key: 'paymentStatus',
        label: 'Payment Status',
        type: 'select',
        options: ['Paid', 'Pending'],
      },
      {
        key: 'paymentMethod',
        label: 'Payment Method',
        type: 'select',
        options: ['Bank', 'Bkash', 'Nagad', 'Cash'],
      },
    ],
  },
  inventory: {
    title: 'Edit Inventory Stock Item',
    fields: [
      { key: 'sku', label: 'SKU Code', type: 'text' },
      { key: 'name', label: 'Item Name', type: 'text' },
      {
        key: 'category',
        label: 'Category',
        type: 'select',
        options: [
          'Raw Material',
          'Spawn & Culture',
          'Packaging',
          'Fresh Produce',
          'Processed Product',
        ],
      },
      { key: 'unit', label: 'Unit (kg, pcs, packet)', type: 'text' },
      { key: 'currentStock', label: 'Current Stock', type: 'number' },
      { key: 'reorderLevel', label: 'Reorder Alert Level', type: 'number' },
      { key: 'unitCost', label: 'Unit Cost (৳)', type: 'number' },
      { key: 'sellingPrice', label: 'Selling Price (৳)', type: 'number' },
    ],
  },
  batches: {
    title: 'Edit Production Batch & CoGS',
    fields: [
      { key: 'batchCode', label: 'Batch Code', type: 'text' },
      { key: 'mushroomVariety', label: 'Mushroom Variety / Product', type: 'text' },
      { key: 'bagCount', label: 'Autoclave Bag Count', type: 'number' },
      { key: 'substrateKg', label: 'Substrate Weight (kg)', type: 'number' },
      { key: 'spawnKg', label: 'Spawn Used (kg)', type: 'number' },
      { key: 'inoculationDate', label: 'Inoculation Date', type: 'date' },
      { key: 'expectedHarvestDate', label: 'Expected Harvest Date', type: 'date' },
      { key: 'actualYieldKg', label: 'Actual Yield (kg)', type: 'number' },
      { key: 'totalCogs', label: 'Total Batch CoGS (৳)', type: 'number' },
      {
        key: 'status',
        label: 'Batch Stage',
        type: 'select',
        options: ['Incubation', 'Fruiting', 'Harvested', 'Processed'],
      },
    ],
  },
  wastage: {
    title: 'Edit Spoilage & Wastage Log',
    fields: [
      { key: 'batchCode', label: 'Batch Reference', type: 'text' },
      { key: 'itemName', label: 'Affected Item Name', type: 'text' },
      {
        key: 'category',
        label: 'Spoilage Category',
        type: 'select',
        options: [
          'Contamination',
          'Post-Harvest Spoilage',
          'Packaging Damage',
          'Processing Loss',
        ],
      },
      { key: 'quantity', label: 'Quantity Lost', type: 'number' },
      { key: 'unit', label: 'Unit', type: 'text' },
      { key: 'estimatedLossBdt', label: 'Estimated Financial Loss (৳)', type: 'number' },
      { key: 'reason', label: 'Root Cause / Notes', type: 'text' },
      { key: 'loggedDate', label: 'Logged Date', type: 'date' },
    ],
  },
  sales: {
    title: 'Edit Sales Invoice & Customer Ledger',
    fields: [
      { key: 'invoiceNo', label: 'Invoice Number', type: 'text' },
      { key: 'date', label: 'Invoice Date', type: 'date' },
      {
        key: 'channel',
        label: 'Sales Channel',
        type: 'select',
        options: ['Wholesale', 'Retail POS', 'E-commerce'],
      },
      { key: 'customerName', label: 'Customer Name', type: 'text' },
      { key: 'customerPhone', label: 'Customer Phone', type: 'text' },
      { key: 'itemsSummary', label: 'Items Summary', type: 'text' },
      { key: 'subtotalBdt', label: 'Gross Subtotal (৳)', type: 'number' },
      { key: 'totalDiscountBdt', label: 'Total Discount (৳)', type: 'number' },
      { key: 'netPayableBdt', label: 'Net Payable (৳)', type: 'number' },
      { key: 'paidAmountBdt', label: 'Paid Amount (৳)', type: 'number' },
      {
        key: 'paymentMethod',
        label: 'Payment Method',
        type: 'select',
        options: ['Cash', 'Bank', 'Bkash', 'Nagad', 'Credit'],
      },
    ],
  },
  expenses: {
    title: 'Edit Operating Expense (OpEx) Voucher',
    fields: [
      { key: 'voucherNo', label: 'Voucher No', type: 'text' },
      { key: 'date', label: 'Date', type: 'date' },
      {
        key: 'category',
        label: 'Expense Category',
        type: 'select',
        options: [
          'Factory Rent',
          'Electricity & Humidity Control',
          'Raw Material Procurement',
          'Daily Labor Wages',
          'Lab Sterilization & Fuel',
          'Logistics & Cold Chain',
          'Marketing & Packaging',
        ],
      },
      { key: 'description', label: 'Description', type: 'text' },
      { key: 'amountBdt', label: 'Amount (৳)', type: 'number' },
      {
        key: 'paymentSource',
        label: 'Payment Source',
        type: 'select',
        options: [
          'Cash in Hand (Vault)',
          'City Bank PLC - Corporate A/C',
          'Dutch-Bangla Bank PLC',
          'Bkash Merchant Wallet',
          'Nagad Business Wallet',
        ],
      },
      { key: 'approvedBy', label: 'Approved By', type: 'text' },
    ],
  },
  equity: {
    title: 'Edit Shareholder Equity & Capital Record',
    fields: [
      { key: 'shareholderName', label: 'Shareholder Name', type: 'text' },
      { key: 'designation', label: 'Designation', type: 'text' },
      { key: 'sharePercentage', label: 'Shareholding Ratio (%)', type: 'number' },
      { key: 'numberOfShares', label: 'Number of Shares', type: 'number' },
      { key: 'initialCapitalBdt', label: 'Initial Capital (৳)', type: 'number' },
      { key: 'additionalInvestmentBdt', label: 'Additional Investment (৳)', type: 'number' },
      { key: 'dividendPaidBdt', label: 'Dividends Paid (৳)', type: 'number' },
      { key: 'directorsLoanOrDrawingBdt', label: 'Drawings / Loans (৳)', type: 'number' },
      {
        key: 'transactionType',
        label: 'Last Transaction Type',
        type: 'select',
        options: [
          'Capital Injection',
          'Dividend Distribution',
          'Director Drawing',
          'Director Loan',
        ],
      },
      { key: 'lastTransactionDate', label: 'Transaction Date', type: 'date' },
    ],
  },
  loans: {
    title: 'Edit Loan, EMI & Supplier Liability',
    fields: [
      { key: 'referenceNo', label: 'Reference No', type: 'text' },
      {
        key: 'liabilityType',
        label: 'Liability Type',
        type: 'select',
        options: [
          'Bank SME Agro Loan',
          'Equipment Lease EMI',
          'Accounts Payable (Supplier Due)',
          'Director Short-Term Loan',
        ],
      },
      { key: 'lenderOrSupplierName', label: 'Lender Bank / Supplier Name', type: 'text' },
      { key: 'principalOrBillAmountBdt', label: 'Principal / Bill Amount (৳)', type: 'number' },
      { key: 'interestRatePct', label: 'Interest Rate (%)', type: 'number' },
      { key: 'monthlyEmiBdt', label: 'Monthly EMI (৳)', type: 'number' },
      { key: 'totalPaidBdt', label: 'Total Paid (৳)', type: 'number' },
      { key: 'outstandingBalanceBdt', label: 'Outstanding Balance (৳)', type: 'number' },
      { key: 'nextDueDate', label: 'Next Due Date', type: 'date' },
      {
        key: 'status',
        label: 'Status',
        type: 'select',
        options: ['Active', 'Overdue', 'Settled'],
      },
    ],
  },
  accounts: {
    title: 'Edit Bank, Cash or Mobile Wallet Account',
    fields: [
      { key: 'accountName', label: 'Account Title', type: 'text' },
      {
        key: 'accountType',
        label: 'Account Type',
        type: 'select',
        options: ['Cash', 'Bank', 'Mobile Wallet'],
      },
      { key: 'accountNumber', label: 'Account / Wallet Number', type: 'text' },
      { key: 'openingBalanceBdt', label: 'Opening Balance (৳)', type: 'number' },
      { key: 'currentBalanceBdt', label: 'Current Balance (৳)', type: 'number' },
      { key: 'lastReconciledDate', label: 'Last Reconciled Date', type: 'date' },
    ],
  },
  transfers: {
    title: 'Edit Internal Fund Transfer Record',
    fields: [
      { key: 'transferRef', label: 'Transfer Reference', type: 'text' },
      { key: 'date', label: 'Date', type: 'date' },
      { key: 'fromAccount', label: 'Source Account', type: 'text' },
      { key: 'toAccount', label: 'Destination Account', type: 'text' },
      { key: 'amountBdt', label: 'Transfer Amount (৳)', type: 'number' },
      { key: 'transferFeeBdt', label: 'Transfer Fee (৳)', type: 'number' },
      { key: 'remarks', label: 'Remarks', type: 'text' },
      { key: 'executedBy', label: 'Executed By', type: 'text' },
    ],
  },
  users: {
    title: 'Edit System User & RBAC Access',
    fields: [
      { key: 'name', label: 'Officer / User Name', type: 'text' },
      { key: 'email', label: 'Email Address', type: 'text' },
      {
        key: 'role',
        label: 'System Role (RBAC)',
        type: 'select',
        options: ['Admin', 'Accountant', 'Manager'],
      },
    ],
  },
  audit: {
    title: 'Edit Audit Log Entry',
    fields: [
      {
        key: 'action',
        label: 'Action Type',
        type: 'select',
        options: ['CREATE', 'UPDATE', 'DELETE', 'EXPORT', 'RECONCILE'],
      },
      { key: 'module', label: 'Module Name', type: 'text' },
      { key: 'entityRef', label: 'Entity Reference', type: 'text' },
      { key: 'details', label: 'Audit Trail Details', type: 'text' },
    ],
  },
};

interface EditRecordModalProps {
  moduleKey: string | null;
  record: Record<string, any> | null;
  onClose: () => void;
  onSave: (moduleKey: string, id: number, updatedData: Record<string, any>) => Promise<void>;
}

export const EditRecordModal: React.FC<EditRecordModalProps> = ({
  moduleKey,
  record,
  onClose,
  onSave,
}) => {
  const [formState, setFormState] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (record) {
      setFormState({ ...record });
    }
  }, [record]);

  if (!moduleKey || !record) return null;

  const schema = EDIT_SCHEMAS[moduleKey];
  if (!schema) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSave(moduleKey, record.id, formState);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-lg max-w-xl w-full overflow-hidden my-8">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <h3 className="text-sm font-semibold">{schema.title}</h3>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {schema.fields.map((field) => (
              <div key={field.key}>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {field.label}
                </label>
                {field.type === 'select' ? (
                  <select
                    value={formState[field.key] ?? ''}
                    onChange={(e) =>
                      setFormState({ ...formState, [field.key]: e.target.value })
                    }
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
                  >
                    {(field.options || []).map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type={field.type}
                    step={field.type === 'number' ? 'any' : undefined}
                    value={formState[field.key] ?? ''}
                    onChange={(e) =>
                      setFormState({ ...formState, [field.key]: e.target.value })
                    }
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
                    required={field.key !== 'notes'}
                  />
                )}
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-600 rounded-md cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{saving ? 'Saving...' : 'Save Changes'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
