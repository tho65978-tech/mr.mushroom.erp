import React, { useState, useEffect } from 'react';
import { Printer, X, FileSpreadsheet, Download } from 'lucide-react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { exportToExcel, triggerIframePrint } from '../utils/exportUtils.ts';

export interface InvoiceLineItem {
  sku: string;
  name: string;
  qty: number;
  price: number;
  discount: number;
}

export interface SalesInvoiceRecord {
  id: number;
  invoiceNo: string;
  date: string;
  channel: string;
  customerName: string;
  customerPhone: string;
  itemsJson: string;
  itemsSummary: string;
  subtotalBdt: number;
  itemDiscountBdt: number;
  invoiceDiscountType: string;
  invoiceDiscountValue: number;
  totalDiscountBdt: number;
  netPayableBdt: number;
  paidAmountBdt: number;
  dueAmountBdt: number;
  paymentMethod: string;
  status: string;
}

export function parseInvoiceLineItems(invoice: SalesInvoiceRecord): InvoiceLineItem[] {
  try {
    const parsed = JSON.parse(invoice.itemsJson || '[]');
    if (Array.isArray(parsed) && parsed.length > 0) return parsed;
  } catch {
    // Fallback below
  }
  return [
    {
      sku: 'MM-ITEM',
      name: invoice.itemsSummary,
      qty: 1,
      price: invoice.subtotalBdt,
      discount: invoice.itemDiscountBdt,
    },
  ];
}

export function downloadInvoicePdfDocument(
  invoice: SalesInvoiceRecord,
  format: 'a4' | 'thermal'
) {
  const parsedItems = parseInvoiceLineItems(invoice);

  if (format === 'thermal') {
    const estimatedHeight = Math.max(150, 95 + parsedItems.length * 14);
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [80, estimatedHeight],
    });

    let y = 9;
    doc.setFont('courier', 'bold');
    doc.setFontSize(10);
    doc.text('MR. MUSHROOM LTD.', 40, y, { align: 'center' });
    y += 4;
    doc.setFont('courier', 'normal');
    doc.setFontSize(7.5);
    doc.text('Savar Agro Biotech Complex, Dhaka', 40, y, { align: 'center' });
    y += 3.5;
    doc.text('Tel: +880 1711-900400 | 80mm POS', 40, y, { align: 'center' });
    y += 4;
    doc.text('--------------------------------------', 40, y, { align: 'center' });
    y += 4;

    doc.text(`INV NO : ${invoice.invoiceNo}`, 4, y);
    y += 3.5;
    doc.text(`DATE   : ${invoice.date}`, 4, y);
    y += 3.5;
    doc.text(`CHANNEL: ${invoice.channel}`, 4, y);
    y += 3.5;
    doc.text(`CLIENT : ${invoice.customerName.slice(0, 24)}`, 4, y);
    y += 3.5;
    doc.text(`PHONE  : ${invoice.customerPhone || 'N/A'}`, 4, y);
    y += 4;
    doc.text('--------------------------------------', 40, y, { align: 'center' });
    y += 4;

    parsedItems.forEach((item) => {
      const lineNet = item.qty * item.price - (item.discount || 0);
      doc.setFont('courier', 'bold');
      doc.text(`${item.name.slice(0, 30)}`, 4, y);
      y += 3.5;
      doc.setFont('courier', 'normal');
      doc.text(
        `${item.qty} x ${item.price}${item.discount ? ` (-${item.discount})` : ''}`,
        4,
        y
      );
      doc.text(`BDT ${lineNet.toFixed(2)}`, 76, y, { align: 'right' });
      y += 4.5;
    });

    doc.text('--------------------------------------', 40, y, { align: 'center' });
    y += 4;
    doc.text('SUBTOTAL:', 4, y);
    doc.text(`BDT ${invoice.subtotalBdt.toFixed(2)}`, 76, y, { align: 'right' });
    y += 3.5;
    doc.text('TOTAL DISCOUNT:', 4, y);
    doc.text(`-BDT ${invoice.totalDiscountBdt.toFixed(2)}`, 76, y, { align: 'right' });
    y += 4;
    doc.setFont('courier', 'bold');
    doc.setFontSize(8.5);
    doc.text('NET PAYABLE:', 4, y);
    doc.text(`BDT ${invoice.netPayableBdt.toFixed(2)}`, 76, y, { align: 'right' });
    y += 4;
    doc.setFont('courier', 'normal');
    doc.setFontSize(7.5);
    doc.text(`PAID (${invoice.paymentMethod}):`, 4, y);
    doc.text(`BDT ${invoice.paidAmountBdt.toFixed(2)}`, 76, y, { align: 'right' });
    y += 3.5;
    doc.setFont('courier', 'bold');
    doc.text('DUE BALANCE:', 4, y);
    doc.text(`BDT ${invoice.dueAmountBdt.toFixed(2)}`, 76, y, { align: 'right' });
    y += 5;
    doc.setFont('courier', 'normal');
    doc.text('--------------------------------------', 40, y, { align: 'center' });
    y += 4;
    doc.text('100% Organic & Lab-Tested Mushrooms', 40, y, { align: 'center' });
    y += 3.5;
    doc.text('Thank You - Visit mrmushroom.com.bd', 40, y, { align: 'center' });

    doc.save(`${invoice.invoiceNo}_POS_80mm.pdf`);
    return;
  }

  // Standard A4 Corporate Invoice PDF
  const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' });
  doc.setFontSize(16);
  doc.setTextColor(15, 23, 42);
  doc.text('Mr. Mushroom Agro & Biotech Ltd.', 40, 45);

  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text('Savar Mushroom Cultivation & Processing Complex, Dhaka-1340, Bangladesh', 40, 60);
  doc.text('RJSC Reg: C-194820/2026 | BIN: 004928172-0102 | Hotline: +880 1711-900400', 40, 73);

  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text(`INVOICE: ${invoice.invoiceNo}`, 555, 45, { align: 'right' });
  doc.setFontSize(9);
  doc.text(`Date: ${invoice.date}`, 555, 60, { align: 'right' });
  doc.text(`Channel: ${invoice.channel}`, 555, 73, { align: 'right' });

  doc.setDrawColor(203, 213, 225);
  doc.line(40, 85, 555, 85);

  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text(`Billed To: ${invoice.customerName}`, 40, 105);
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text(`Phone: ${invoice.customerPhone}`, 40, 119);

  doc.text(`Payment Method: ${invoice.paymentMethod}`, 555, 105, { align: 'right' });
  doc.text(`Settlement Status: ${invoice.status}`, 555, 119, { align: 'right' });

  autoTable(doc, {
    startY: 135,
    head: [['SKU', 'Item Description', 'Qty', 'Unit Price (BDT)', 'Item Disc (BDT)', 'Line Net (BDT)']],
    body: parsedItems.map((it) => [
      it.sku,
      it.name,
      String(it.qty),
      it.price.toFixed(2),
      (it.discount || 0).toFixed(2),
      (it.qty * it.price - (it.discount || 0)).toFixed(2),
    ]),
    styles: { fontSize: 9, cellPadding: 6 },
    headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255] },
    margin: { left: 40, right: 40 },
  });

  const finalY = (doc as any).lastAutoTable.finalY + 20;
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text(`Gross Subtotal: BDT ${invoice.subtotalBdt.toFixed(2)}`, 555, finalY, { align: 'right' });
  doc.text(`Total Discounts: -BDT ${invoice.totalDiscountBdt.toFixed(2)}`, 555, finalY + 15, {
    align: 'right',
  });
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text(`Net Payable: BDT ${invoice.netPayableBdt.toFixed(2)}`, 555, finalY + 32, {
    align: 'right',
  });
  doc.setFontSize(9);
  doc.setTextColor(4, 120, 87);
  doc.text(`Paid Amount: BDT ${invoice.paidAmountBdt.toFixed(2)}`, 555, finalY + 47, {
    align: 'right',
  });
  doc.setTextColor(185, 28, 28);
  doc.text(`Balance Due: BDT ${invoice.dueAmountBdt.toFixed(2)}`, 555, finalY + 62, {
    align: 'right',
  });

  doc.setTextColor(100, 116, 139);
  doc.text('Customer Signature', 40, finalY + 110);
  doc.text('Authorized Signatory - Mr. Mushroom Ltd.', 555, finalY + 110, { align: 'right' });

  doc.save(`${invoice.invoiceNo}_A4_Invoice.pdf`);
}

export function printInvoiceDocument(
  invoice: SalesInvoiceRecord,
  format: 'a4' | 'thermal'
) {
  const parsedItems = parseInvoiceLineItems(invoice);

  const rowsHtml = parsedItems
    .map((item) => {
      const lineNet = item.qty * item.price - (item.discount || 0);
      return `<tr>
        <td><strong>${item.name}</strong><br/><small>${item.sku}</small></td>
        <td style="text-align:right">${item.qty}</td>
        <td style="text-align:right">${item.price.toFixed(2)}</td>
        <td style="text-align:right">${(item.discount || 0).toFixed(2)}</td>
        <td style="text-align:right"><strong>${lineNet.toFixed(2)}</strong></td>
      </tr>`;
    })
    .join('');

  const htmlDoc =
    format === 'thermal'
      ? `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>POS Receipt ${invoice.invoiceNo}</title>
  <style>
    @page { margin: 4mm; }
    .pos-receipt-print {
      font-family: 'Courier New', Courier, monospace;
      width: 74mm;
      max-width: 74mm;
      margin: 0 auto;
      padding: 2mm;
      font-size: 11px;
      line-height: 1.35;
      color: #000000;
      background: #ffffff;
    }
    .pos-receipt-print .center { text-align: center; }
    .pos-receipt-print .line { border-bottom: 1px dashed #000000; margin: 6px 0; }
    .pos-receipt-print table { width: 100%; border-collapse: collapse; }
    .pos-receipt-print td { padding: 1.5px 0; font-size: 11px; color: #000000; vertical-align: top; }
    .pos-receipt-print .right { text-align: right; }
    .pos-receipt-print .bold { font-weight: bold; }
  </style>
</head>
<body>
  <div class="pos-receipt-print">
    <div class="center bold" style="font-size:14px;">MR. MUSHROOM LTD.</div>
    <div class="center" style="font-size:10px;">Savar Agro Biotech Complex, Dhaka</div>
    <div class="center" style="font-size:10px;">Hotline: +880 1711-900400</div>
    <div class="center" style="font-size:10px; margin-top:2px;">[ 80mm POS Thermal Receipt ]</div>
    <div class="line"></div>
    <table>
      <tr><td>INV NO:</td><td class="right bold">${invoice.invoiceNo}</td></tr>
      <tr><td>DATE:</td><td class="right">${invoice.date}</td></tr>
      <tr><td>CHANNEL:</td><td class="right">${invoice.channel}</td></tr>
      <tr><td>CUSTOMER:</td><td class="right">${invoice.customerName}</td></tr>
      <tr><td>PHONE:</td><td class="right">${invoice.customerPhone || 'N/A'}</td></tr>
    </table>
    <div class="line"></div>
    <table>
      ${parsedItems
        .map(
          (item) => `
        <tr>
          <td colspan="2" class="bold">${item.name} (${item.sku})</td>
        </tr>
        <tr>
          <td>${item.qty} x ৳${item.price}${item.discount ? ` (-৳${item.discount})` : ''}</td>
          <td class="right bold">৳${(item.qty * item.price - (item.discount || 0)).toFixed(2)}</td>
        </tr>`
        )
        .join('')}
    </table>
    <div class="line"></div>
    <table>
      <tr><td>SUBTOTAL:</td><td class="right">৳${invoice.subtotalBdt.toFixed(2)}</td></tr>
      <tr><td>TOTAL DISCOUNT:</td><td class="right">-৳${invoice.totalDiscountBdt.toFixed(2)}</td></tr>
      <tr><td class="bold" style="font-size:12px; padding-top:4px;">NET PAYABLE:</td><td class="right bold" style="font-size:12px; padding-top:4px;">৳${invoice.netPayableBdt.toFixed(2)}</td></tr>
      <tr><td>PAID (${invoice.paymentMethod}):</td><td class="right">৳${invoice.paidAmountBdt.toFixed(2)}</td></tr>
      <tr><td class="bold">DUE BALANCE:</td><td class="right bold">৳${invoice.dueAmountBdt.toFixed(2)}</td></tr>
    </table>
    <div class="line"></div>
    <div class="center" style="font-size:10px; margin-top:6px;">
      100% Organic & Lab-Tested Mushrooms<br/>
      Thank You · Visit mrmushroom.com.bd
    </div>
  </div>
</body>
</html>`
      : `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Invoice ${invoice.invoiceNo}</title>
  <style>
    @page { size: A4; margin: 14mm; }
    .a4-invoice-print { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #0f172a; font-size: 12px; max-width: 190mm; margin: 0 auto; }
    .a4-invoice-print .top { display: flex; justify-content: space-between; border-bottom: 2px solid #0f172a; padding-bottom: 12px; }
    .a4-invoice-print .meta { display: flex; justify-content: space-between; padding: 14px 0; border-bottom: 1px solid #cbd5e1; }
    .a4-invoice-print table { width: 100%; border-collapse: collapse; margin-top: 16px; }
    .a4-invoice-print th, .a4-invoice-print td { border: 1px solid #cbd5e1; padding: 8px; font-size: 11px; text-align: left; }
    .a4-invoice-print th { background: #0f172a; color: #fff; }
    .a4-invoice-print .totals { width: 260px; margin-left: auto; margin-top: 16px; }
    .a4-invoice-print .totals-row { display: flex; justify-content: space-between; padding: 4px 0; }
    .a4-invoice-print .sig { display: flex; justify-content: space-between; margin-top: 50px; padding-top: 12px; border-top: 1px solid #cbd5e1; font-size: 11px; color: #475569; }
  </style>
</head>
<body>
  <div class="a4-invoice-print">
    <div class="top">
      <div>
        <h2 style="margin:0; font-size:18px;">Mr. Mushroom Agro & Biotech Ltd.</h2>
        <div style="color:#475569; font-size:11px; margin-top:4px;">Savar Mushroom Cultivation & Processing Complex, Dhaka-1340, Bangladesh</div>
        <div style="color:#475569; font-size:11px;">RJSC Reg: C-194820/2026 · BIN: 004928172-0102 · Hotline: +880 1711-900400</div>
      </div>
      <div style="text-align:right;">
        <div style="font-size:11px; text-transform:uppercase; color:#475569; font-weight:bold;">Commercial Invoice</div>
        <div style="font-size:15px; font-weight:bold; margin-top:4px;">${invoice.invoiceNo}</div>
        <div style="font-size:11px; color:#475569;">Date: ${invoice.date}</div>
      </div>
    </div>
    <div class="meta">
      <div>
        <div style="color:#64748b; font-size:11px;">Billed To:</div>
        <div style="font-weight:bold; font-size:13px; margin-top:2px;">${invoice.customerName}</div>
        <div>Phone: ${invoice.customerPhone}</div>
        <div>Channel: ${invoice.channel}</div>
      </div>
      <div style="text-align:right;">
        <div>Payment Mode: <strong>${invoice.paymentMethod}</strong></div>
        <div>Status: <strong>${invoice.status}</strong></div>
        <div>Currency: BDT (৳)</div>
      </div>
    </div>
    <table>
      <thead>
        <tr>
          <th>SKU & Description</th>
          <th style="text-align:right">Qty</th>
          <th style="text-align:right">Rate (৳)</th>
          <th style="text-align:right">Item Disc (৳)</th>
          <th style="text-align:right">Line Net (৳)</th>
        </tr>
      </thead>
      <tbody>${rowsHtml}</tbody>
    </table>
    <div class="totals">
      <div class="totals-row"><span>Gross Subtotal:</span><span>৳${invoice.subtotalBdt.toFixed(2)}</span></div>
      <div class="totals-row"><span>Total Discount:</span><span>-৳${invoice.totalDiscountBdt.toFixed(2)}</span></div>
      <div class="totals-row" style="font-weight:bold; font-size:14px; border-top:1px solid #0f172a; padding-top:6px;"><span>Net Payable:</span><span>৳${invoice.netPayableBdt.toFixed(2)}</span></div>
      <div class="totals-row" style="color:#047857; font-weight:bold;"><span>Paid Amount:</span><span>৳${invoice.paidAmountBdt.toFixed(2)}</span></div>
      <div class="totals-row" style="color:#b91c1c; font-weight:bold;"><span>Balance Due:</span><span>৳${invoice.dueAmountBdt.toFixed(2)}</td></tr>
    </div>
    <div class="sig">
      <div>Customer Signature & Seal</div>
      <div>Authorized Signatory · Mr. Mushroom Ltd.</div>
    </div>
  </div>
</body>
</html>`;

  triggerIframePrint(htmlDoc, () => downloadInvoicePdfDocument(invoice, format));
}

interface InvoicePrintModalProps {
  invoice: SalesInvoiceRecord | null;
  initialFormat?: 'a4' | 'thermal';
  onClose: () => void;
}

export const InvoicePrintModal: React.FC<InvoicePrintModalProps> = ({
  invoice,
  initialFormat = 'a4',
  onClose,
}) => {
  const [format, setFormat] = useState<'a4' | 'thermal'>(initialFormat);

  useEffect(() => {
    setFormat(initialFormat);
  }, [initialFormat, invoice]);

  if (!invoice) return null;

  const parsedItems = parseInvoiceLineItems(invoice);

  const handleExportSingleInvoiceExcel = () => {
    const rows = parsedItems.map((item, idx) => ({
      SL: idx + 1,
      Invoice_No: invoice.invoiceNo,
      Date: invoice.date,
      Customer: invoice.customerName,
      Channel: invoice.channel,
      SKU: item.sku,
      Item_Description: item.name,
      Quantity: item.qty,
      Unit_Price_BDT: item.price,
      Item_Discount_BDT: item.discount,
      Line_Total_BDT: item.qty * item.price - item.discount,
    }));
    exportToExcel(rows, `Invoice_${invoice.invoiceNo}`, invoice.invoiceNo);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-lg max-w-3xl w-full overflow-hidden my-8">
        {/* Top Modal Controls */}
        <div className="no-print flex flex-wrap items-center justify-between gap-3 px-6 py-3.5 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold">
              {format === 'thermal' ? 'POS Thermal Receipt (80mm)' : 'Standard A4 Invoice'}
            </span>
            <span className="text-slate-400">·</span>
            <span className="text-xs font-mono text-emerald-400">{invoice.invoiceNo}</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center bg-slate-800 p-0.5 rounded-md">
              <button
                type="button"
                onClick={() => setFormat('a4')}
                className={`px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
                  format === 'a4' ? 'bg-white text-slate-900' : 'text-slate-300 hover:text-white'
                }`}
              >
                Standard A4
              </button>
              <button
                type="button"
                onClick={() => setFormat('thermal')}
                className={`px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
                  format === 'thermal' ? 'bg-white text-slate-900' : 'text-slate-300 hover:text-white'
                }`}
              >
                POS Thermal (80mm)
              </button>
            </div>

            <button
              type="button"
              onClick={handleExportSingleInvoiceExcel}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-emerald-700 hover:bg-emerald-600 text-white rounded-md transition-colors cursor-pointer whitespace-nowrap"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>.xlsx</span>
            </button>

            <button
              type="button"
              onClick={() => downloadInvoicePdfDocument(invoice, format)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-white rounded-md transition-colors cursor-pointer whitespace-nowrap"
              title={
                format === 'thermal'
                  ? 'Download 80mm POS Thermal Receipt as PDF'
                  : 'Download Standard A4 Invoice as PDF'
              }
            >
              <Download className="w-3.5 h-3.5" />
              <span>{format === 'thermal' ? 'Download POS PDF' : 'Download A4 PDF'}</span>
            </button>

            <button
              type="button"
              onClick={() => printInvoiceDocument(invoice, format)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold bg-white text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer whitespace-nowrap"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{format === 'thermal' ? 'Print POS (80mm)' : 'Print A4'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
              aria-label="Close invoice viewer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Document Area */}
        <div className="p-6 bg-slate-100 flex justify-center max-h-[80vh] overflow-y-auto">
          {format === 'a4' ? (
            /* Standard A4 Corporate Invoice */
            <div className="bg-white border border-slate-200 p-8 w-full max-w-2xl text-slate-900">
              <div className="flex justify-between items-start pb-6 border-b border-slate-200">
                <div>
                  <h2 className="text-xl font-bold tracking-tight text-slate-900">
                    Mr. Mushroom Agro & Biotech Ltd.
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">
                    Savar Mushroom Cultivation & Processing Complex, Dhaka-1340, Bangladesh
                  </p>
                  <p className="text-xs text-slate-500">
                    RJSC Reg: C-194820/2026 · BIN: 004928172-0102 · Hotline: +880 1711-900400
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                    Tax & Commercial Invoice
                  </div>
                  <div className="text-base font-mono font-semibold text-slate-900 mt-1">
                    {invoice.invoiceNo}
                  </div>
                  <div className="text-xs text-slate-500 font-mono mt-0.5">Date: {invoice.date}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6 py-5 border-b border-slate-200 text-xs">
                <div>
                  <div className="text-slate-500 font-medium">Billed To</div>
                  <div className="text-sm font-semibold text-slate-900 mt-1">
                    {invoice.customerName}
                  </div>
                  <div className="font-mono text-slate-600 mt-0.5">Phone: {invoice.customerPhone}</div>
                  <div className="text-slate-600 mt-0.5">Sales Channel: {invoice.channel}</div>
                </div>
                <div className="text-right">
                  <div className="text-slate-500 font-medium">Settlement Details</div>
                  <div className="text-slate-900 font-semibold mt-1">
                    Payment Mode: {invoice.paymentMethod}
                  </div>
                  <div className="mt-0.5">
                    Settlement Status: <span className="font-semibold">{invoice.status}</span>
                  </div>
                  <div className="font-mono text-slate-600 mt-0.5">Currency: BDT (৳)</div>
                </div>
              </div>

              <div className="mt-5">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-300 text-xs text-slate-500">
                      <th className="py-2 font-medium">SKU & Description</th>
                      <th className="py-2 font-medium text-right">Qty</th>
                      <th className="py-2 font-medium text-right">Rate (৳)</th>
                      <th className="py-2 font-medium text-right">Item Disc (৳)</th>
                      <th className="py-2 font-medium text-right">Line Net (৳)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-xs">
                    {parsedItems.map((item, idx) => {
                      const lineNet = item.qty * item.price - (item.discount || 0);
                      return (
                        <tr key={idx}>
                          <td className="py-2.5">
                            <div className="font-medium text-slate-900">{item.name}</div>
                            <div className="font-mono text-[11px] text-slate-500">{item.sku}</div>
                          </td>
                          <td className="py-2.5 text-right font-mono tabular-nums">{item.qty}</td>
                          <td className="py-2.5 text-right font-mono tabular-nums">
                            {item.price.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-2.5 text-right font-mono tabular-nums text-slate-600">
                            {(item.discount || 0).toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-2.5 text-right font-mono tabular-nums font-semibold text-slate-900">
                            {lineNet.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-200 flex justify-end">
                <div className="w-72 space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Gross Subtotal:</span>
                    <span className="font-mono tabular-nums">
                      ৳{invoice.subtotalBdt.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Item-Level Discounts:</span>
                    <span className="font-mono tabular-nums text-amber-700">
                      -৳{invoice.itemDiscountBdt.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">
                      Invoice Discount ({invoice.invoiceDiscountType}: {invoice.invoiceDiscountValue}
                      {invoice.invoiceDiscountType === 'Percentage' ? '%' : ' ৳'}):
                    </span>
                    <span className="font-mono tabular-nums text-amber-700">
                      -৳
                      {(invoice.totalDiscountBdt - invoice.itemDiscountBdt).toLocaleString('en-BD', {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-300 text-sm font-bold text-slate-900">
                    <span>Net Payable:</span>
                    <span className="font-mono tabular-nums">
                      ৳{invoice.netPayableBdt.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Paid Amount ({invoice.paymentMethod}):</span>
                    <span className="font-mono tabular-nums">
                      ৳{invoice.paidAmountBdt.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="flex justify-between text-red-700 font-semibold pt-1 border-t border-slate-200">
                    <span>Balance Due:</span>
                    <span className="font-mono tabular-nums">
                      ৳{invoice.dueAmountBdt.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-10 pt-6 border-t border-slate-200 flex justify-between text-[11px] text-slate-500">
                <div>Customer Signature & Seal</div>
                <div>Authorized Signatory · Mr. Mushroom Ltd.</div>
              </div>
            </div>
          ) : (
            /* POS Thermal Receipt (80mm / 302px width) */
            <div className="bg-white border border-slate-300 p-5 w-[310px] font-mono text-xs text-slate-900">
              <div className="text-center border-b border-dashed border-slate-400 pb-3">
                <div className="font-bold text-sm">MR. MUSHROOM LTD.</div>
                <div className="text-[10px] text-slate-600 mt-0.5">
                  Savar Agro Biotech Complex, Dhaka
                </div>
                <div className="text-[10px] text-slate-600">Tel: +880 1711-900400</div>
                <div className="text-[10px] text-slate-600 mt-1">80mm POS Thermal Receipt</div>
              </div>

              <div className="py-2.5 border-b border-dashed border-slate-400 text-[11px] space-y-0.5">
                <div className="flex justify-between">
                  <span>INV:</span>
                  <span className="font-semibold">{invoice.invoiceNo}</span>
                </div>
                <div className="flex justify-between">
                  <span>DATE:</span>
                  <span>{invoice.date}</span>
                </div>
                <div className="flex justify-between">
                  <span>CHANNEL:</span>
                  <span>{invoice.channel}</span>
                </div>
                <div className="flex justify-between">
                  <span>CUSTOMER:</span>
                  <span className="truncate max-w-[160px]">{invoice.customerName}</span>
                </div>
              </div>

              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-2 text-[11px]">
                {parsedItems.map((item, idx) => {
                  const lineTotal = item.qty * item.price - (item.discount || 0);
                  return (
                    <div key={idx}>
                      <div className="font-semibold">{item.name}</div>
                      <div className="flex justify-between text-slate-600">
                        <span>
                          {item.qty} x {item.price}
                          {item.discount ? ` (-${item.discount})` : ''}
                        </span>
                        <span className="text-slate-900 font-semibold">
                          {lineTotal.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span>SUBTOTAL:</span>
                  <span>{invoice.subtotalBdt.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>TOTAL DISCOUNT:</span>
                  <span>-{invoice.totalDiscountBdt.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-xs pt-1 border-t border-dotted border-slate-300">
                  <span>NET PAYABLE (BDT):</span>
                  <span>{invoice.netPayableBdt.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>PAID ({invoice.paymentMethod}):</span>
                  <span>{invoice.paidAmountBdt.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-semibold">
                  <span>DUE BALANCE:</span>
                  <span>{invoice.dueAmountBdt.toFixed(2)}</span>
                </div>
              </div>

              <div className="pt-3 text-center text-[10px] text-slate-600">
                <div>100% Organic & Lab-Tested Mushrooms</div>
                <div className="mt-0.5">Thank You · Visit mrmushroom.com.bd</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
