import React, { useState } from 'react';
import { X, Copy, Check, Download, Terminal } from 'lucide-react';

interface PythonSpecModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PYTHON_UPDATED_PROMPT = `Mr. Mushroom ERP & Accounts Management System – Python Development Prompt

Objective:
Develop a full-featured, multi-user ERP & Accounting System in Python customized for "Mr. Mushroom Ltd." (a Private Limited Mushroom Cultivation & Processing Business). The system must ensure financial transparency, manage inventory & batch production, handle multi-channel sales with POS & A4 invoicing, track employee attendance & payroll, and strictly implement Universal One-Click Data Export (allowing EVERY single data table, register, ledger, and financial statement to be exported to Excel .xlsx and Google Sheets-ready UTF-8 .csv).

Technology Stack:
- Language: Python 3.11+
- GUI/Frontend: CustomTkinter (for Desktop UI) or FastAPI/Flask + Web UI
- Database: SQLite (local single-node) or PostgreSQL (multi-user network) via SQLAlchemy
- Universal Export Engine: pandas & openpyxl (for auto-formatted .xlsx and UTF-8-SIG .csv exports for Google Sheets), reportlab (for 80mm Thermal POS & A4 PDF Invoices)
- Deployment: Compile to standalone .exe using PyInstaller (pyinstaller --noconfirm --onefile --windowed mr_mushroom_erp.py)

1. Universal Data Export & Integration (CRITICAL REQUIREMENT)
- Export Everything: EVERY data grid, list, and financial statement (Sales Registers, Customer Dues Ledger, Expense Logs, Inventory Stock, Production Batches, Spoilage Logs, Payroll, Attendance, Shareholder Equity, Loans/EMI, Bank Reconciliation, P&L, Balance Sheet, Cash Flow, and Audit Trail) MUST include two dedicated action buttons:
  1) "Export to Excel (.xlsx)" -> Uses pandas/openpyxl with auto-adjusted column widths.
  2) "Export to CSV (Google Sheets)" -> Uses UTF-8 with BOM (utf-8-sig) and RFC-4180 escaping so Bengali and English text imports into Google Sheets with zero formatting issues.
- Master Backup Button: A global "Export Master Workbook (.xlsx)" button that exports all tables as separate worksheets in a single dated Excel file.

2. Core Modules & Features
- Module 1 (Attendance & Payroll): Daily check-in/out, status (Present, Absent, Leave, Late), overtime hours, auto-calculated monthly payroll (Base + Overtime Pay + Bonus - Deductions = Net Payable BDT).
- Module 2 (Inventory & Batch Production): Raw materials (sawdust, wheat bran, spawn, PP autoclave bags) with low-stock alerts; Production batches tracking bag count, yield (kg), Total CoGS, and Cost/kg; Processed products (Mushroom Powder, Soup Mix, Capsules); Wastage/Spoilage log.
- Module 3 (Sales, POS & Invoicing): Multi-channel sales (Wholesale, Retail POS, E-commerce); Item-level & Invoice-level discounts (Flat BDT or Percentage %); 80mm POS Thermal & Standard A4 Invoice generation; Customer ledger & due collection.
- Module 4 (Operating Expenses - OpEx): Category-wise vouchers (Rent, Electricity/Humidity, Wages, Sterilization, Logistics) with payment source tagging (Cash, Bank, Bkash, Nagad).
- Module 5 (Investment & Equity - Pvt. Ltd.): Shareholder cap table, share ratios %, initial capital, additional investments, dividend payouts, and director loans/drawings.
- Module 6 (Loans & Liabilities): Bank SME loans, equipment lease EMIs, director loans, and supplier accounts payable (AP) with installment tracking.
- Module 7 (Banking & Cash Reconciliation): Manage Cash in Hand (Vault), Corporate Bank Accounts, and Mobile Wallets (Bkash, Nagad) with internal fund transfer reconciliation.
- Module 8 (Corporate Reports & Dashboards): Real-time KPI Dashboard; Auto-computed Profit & Loss (P&L), Balance Sheet, and Cash Flow Statement (all exportable to Excel & Google Sheets).
- Module 9 (Audit Trail & Security): Role-Based Access Control (Admin, Accountant, Manager) and immutable Audit Log recording every CREATE, UPDATE, DELETE, RECONCILE, and EXPORT action with timestamp.`;

export const PYTHON_STARTER_CODE = `"""
Mr. Mushroom ERP & Accounts Management System
Universal Data Export Engine (pandas + openpyxl + Google Sheets UTF-8-SIG CSV)
Compatible with CustomTkinter / FastAPI / SQLite / PostgreSQL
"""

import os
from datetime import datetime
import pandas as pd

class UniversalExportEngine:
    """
    Guarantees 1-click export of EVERY ERP table & financial statement
    to Microsoft Excel (.xlsx) and Google Sheets Ready CSV (.csv).
    """

    @staticmethod
    def export_to_excel(records: list[dict], file_prefix: str, sheet_name: str = "Data") -> str:
        df = pd.DataFrame(records if records else [{"Status": "No records found"}])
        timestamp = datetime.now().strftime("%Y-%m-%d_%H%M")
        filename = f"{file_prefix}_{timestamp}.xlsx"

        with pd.ExcelWriter(filename, engine="openpyxl") as writer:
            safe_sheet = sheet_name[:31]
            df.to_excel(writer, index=False, sheet_name=safe_sheet)
            worksheet = writer.sheets[safe_sheet]
            for col in worksheet.columns:
                max_len = max(len(str(cell.value or "")) for cell in col)
                col_letter = col[0].column_letter
                worksheet.column_dimensions[col_letter].width = min(max(max_len + 4, 14), 48)

        return os.path.abspath(filename)

    @staticmethod
    def export_to_google_sheets_csv(records: list[dict], file_prefix: str) -> str:
        df = pd.DataFrame(records if records else [{"Status": "No records found"}])
        timestamp = datetime.now().strftime("%Y-%m-%d_%H%M")
        filename = f"{file_prefix}_GoogleSheets_{timestamp}.csv"
        # utf-8-sig ensures Bengali & English characters open cleanly in Google Sheets & Excel
        df.to_csv(filename, index=False, encoding="utf-8-sig")
        return os.path.abspath(filename)

    @staticmethod
    def export_master_workbook(all_modules: dict[str, list[dict]]) -> str:
        timestamp = datetime.now().strftime("%Y-%m-%d_%H%M")
        filename = f"Mr_Mushroom_Master_ERP_Backup_{timestamp}.xlsx"
        with pd.ExcelWriter(filename, engine="openpyxl") as writer:
            for sheet_name, rows in all_modules.items():
                df = pd.DataFrame(rows if rows else [{"Status": "Empty"}])
                safe_sheet = sheet_name[:31]
                df.to_excel(writer, index=False, sheet_name=safe_sheet)
        return os.path.abspath(filename)
`;

export const PythonSpecModal: React.FC<PythonSpecModalProps> = ({ isOpen, onClose }) => {
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  if (!isOpen) return null;

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(PYTHON_UPDATED_PROMPT);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(PYTHON_STARTER_CODE);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadPy = () => {
    const blob = new Blob([PYTHON_STARTER_CODE], { type: 'text/x-python;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mr_mushroom_universal_export.py';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-lg max-w-4xl w-full overflow-hidden my-8">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span className="text-sm font-semibold">
              Python ERP Prompt & Universal Export Reference (pandas / openpyxl)
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-semibold text-slate-900">
                1. Finalized Developer Prompt (Universal Excel & Google Sheets Export Highlighted)
              </h4>
              <button
                type="button"
                onClick={handleCopyPrompt}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-900 text-white rounded-md hover:bg-slate-800 cursor-pointer"
              >
                {copiedPrompt ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedPrompt ? 'Copied Prompt' : 'Copy Full Prompt'}</span>
              </button>
            </div>
            <pre className="p-4 bg-slate-50 border border-slate-200 rounded-md text-xs font-mono text-slate-800 whitespace-pre-wrap max-h-60 overflow-y-auto">
              {PYTHON_UPDATED_PROMPT}
            </pre>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-semibold text-slate-900">
                2. Python Universal Export Engine (pandas + openpyxl + utf-8-sig CSV)
              </h4>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-100 text-slate-800 border border-slate-300 rounded-md hover:bg-slate-200 cursor-pointer"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copied Code' : 'Copy Python Code'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownloadPy}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-emerald-700 text-white rounded-md hover:bg-emerald-600 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .py</span>
                </button>
              </div>
            </div>
            <pre className="p-4 bg-slate-900 text-slate-100 rounded-md text-xs font-mono whitespace-pre-wrap max-h-64 overflow-y-auto">
              {PYTHON_STARTER_CODE}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
