import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Pencil,
  ArrowRightLeft,
  ShieldCheck,
  CheckCircle2,
  UserPlus,
} from 'lucide-react';
import { UniversalExportBar } from './UniversalExportBar.tsx';

interface FinanceProps {
  activeSubTab: 'expenses' | 'equity' | 'loans' | 'banking' | 'statements' | 'audit';
  data: any;
  userRole: string;
  onApiPost: (endpoint: string, body: any) => Promise<void>;
  onApiDelete: (moduleKey: string, id: number) => Promise<void>;
  onOpenEditModal: (moduleKey: string, record: any) => void;
  onSwitchRole: (role: string) => Promise<void>;
  onLogExport: (moduleName: string, format: string, recordCount: number, fileName: string) => void;
}

export const FinanceModules: React.FC<FinanceProps> = ({
  activeSubTab,
  data,
  userRole,
  onApiPost,
  onApiDelete,
  onOpenEditModal,
  onSwitchRole,
  onLogExport,
}) => {
  // Module 4 State (OpEx)
  const [expForm, setExpForm] = useState({
    voucherNo: `EXP-2026-00${(data.operatingExpenses?.length || 5) + 1}`,
    date: new Date().toISOString().slice(0, 10),
    category: 'Electricity & Humidity Control',
    description: '',
    amountBdt: '',
    paymentSource: 'City Bank PLC - Corporate A/C',
    approvedBy: 'Managing Director',
  });

  // Module 5 State (Equity)
  const [eqForm, setEqForm] = useState({
    shareholderName: '',
    designation: 'Director',
    sharePercentage: '10',
    numberOfShares: '1000',
    initialCapitalBdt: '300000',
    additionalInvestmentBdt: '50000',
    dividendPaidBdt: '0',
    directorsLoanOrDrawingBdt: '0',
    transactionType: 'Capital Injection',
    lastTransactionDate: new Date().toISOString().slice(0, 10),
  });

  // Module 6 State (Loans & Liabilities)
  const [loanForm, setLoanForm] = useState({
    referenceNo: `LOAN-00${(data.loansLiabilities?.length || 4) + 1}`,
    liabilityType: 'Accounts Payable (Supplier Due)',
    lenderOrSupplierName: '',
    principalOrBillAmountBdt: '',
    interestRatePct: '0',
    monthlyEmiBdt: '0',
    totalPaidBdt: '0',
    nextDueDate: '2026-10-30',
  });

  // Module 7 State (Bank/Cash Accounts + Fund Transfers)
  const [accForm, setAccForm] = useState({
    accountName: '',
    accountType: 'Bank',
    accountNumber: '',
    openingBalanceBdt: '',
    currentBalanceBdt: '',
    lastReconciledDate: new Date().toISOString().slice(0, 10),
  });

  const [trfForm, setTrfForm] = useState({
    transferRef: `TRF-2026-00${(data.fundTransfers?.length || 3) + 1}`,
    date: new Date().toISOString().slice(0, 10),
    fromAccount: 'Bkash Merchant Wallet',
    toAccount: 'City Bank PLC - Corporate A/C',
    amountBdt: '',
    transferFeeBdt: '0',
    remarks: '',
  });

  // Module 9 State (Add System Officer / User)
  const [userForm, setUserForm] = useState({
    name: '',
    email: '',
    role: 'Manager',
  });

  // Handlers
  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!expForm.description || !expForm.amountBdt) return;
    await onApiPost('/api/erp/expenses', {
      ...expForm,
      amountBdt: Number(expForm.amountBdt) || 0,
    });
    setExpForm({
      ...expForm,
      voucherNo: `EXP-2026-00${(data.operatingExpenses?.length || 5) + 2}`,
      description: '',
      amountBdt: '',
    });
  };

  const handleAddEquity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!eqForm.shareholderName) return;
    await onApiPost('/api/erp/equity', {
      shareholderName: eqForm.shareholderName,
      designation: eqForm.designation,
      sharePercentage: Number(eqForm.sharePercentage) || 0,
      numberOfShares: Number(eqForm.numberOfShares) || 0,
      initialCapitalBdt: Number(eqForm.initialCapitalBdt) || 0,
      additionalInvestmentBdt: Number(eqForm.additionalInvestmentBdt) || 0,
      dividendPaidBdt: Number(eqForm.dividendPaidBdt) || 0,
      directorsLoanOrDrawingBdt: Number(eqForm.directorsLoanOrDrawingBdt) || 0,
      transactionType: eqForm.transactionType,
      lastTransactionDate: eqForm.lastTransactionDate,
    });
    setEqForm({ ...eqForm, shareholderName: '' });
  };

  const handleAddLoan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loanForm.lenderOrSupplierName || !loanForm.principalOrBillAmountBdt) return;
    const principal = Number(loanForm.principalOrBillAmountBdt) || 0;
    const paid = Number(loanForm.totalPaidBdt) || 0;
    const outstanding = Math.max(0, principal - paid);
    await onApiPost('/api/erp/loans', {
      referenceNo: loanForm.referenceNo,
      liabilityType: loanForm.liabilityType,
      lenderOrSupplierName: loanForm.lenderOrSupplierName,
      principalOrBillAmountBdt: principal,
      interestRatePct: Number(loanForm.interestRatePct) || 0,
      monthlyEmiBdt: Number(loanForm.monthlyEmiBdt) || 0,
      totalPaidBdt: paid,
      outstandingBalanceBdt: outstanding,
      nextDueDate: loanForm.nextDueDate,
      status: outstanding <= 0 ? 'Settled' : 'Active',
    });
    setLoanForm({
      ...loanForm,
      referenceNo: `LOAN-00${(data.loansLiabilities?.length || 4) + 2}`,
      lenderOrSupplierName: '',
      principalOrBillAmountBdt: '',
    });
  };

  const handleAddAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accForm.accountName || !accForm.accountNumber) return;
    const opening = Number(accForm.openingBalanceBdt) || 0;
    const current = Number(accForm.currentBalanceBdt || accForm.openingBalanceBdt) || 0;
    await onApiPost('/api/erp/accounts', {
      accountName: accForm.accountName,
      accountType: accForm.accountType,
      accountNumber: accForm.accountNumber,
      openingBalanceBdt: opening,
      currentBalanceBdt: current,
      lastReconciledDate: accForm.lastReconciledDate,
    });
    setAccForm({
      ...accForm,
      accountName: '',
      accountNumber: '',
      openingBalanceBdt: '',
      currentBalanceBdt: '',
    });
  };

  const handleExecuteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trfForm.amountBdt || trfForm.fromAccount === trfForm.toAccount) return;
    await onApiPost('/api/erp/transfers', {
      transferRef: trfForm.transferRef,
      date: trfForm.date,
      fromAccount: trfForm.fromAccount,
      toAccount: trfForm.toAccount,
      amountBdt: Number(trfForm.amountBdt) || 0,
      transferFeeBdt: Number(trfForm.transferFeeBdt) || 0,
      remarks: trfForm.remarks || 'Internal treasury sweep',
      executedBy: data.currentUser?.name || 'Admin',
    });
    setTrfForm({
      ...trfForm,
      transferRef: `TRF-2026-00${(data.fundTransfers?.length || 3) + 2}`,
      amountBdt: '',
      remarks: '',
    });
  };

  const handleAddSystemUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userForm.name || !userForm.email) return;
    await onApiPost('/api/erp/users', userForm);
    setUserForm({ name: '', email: '', role: 'Manager' });
  };

  // Module 4: Operating Expenses
  if (activeSubTab === 'expenses') {
    return (
      <section className="bg-white border border-slate-200 rounded-lg p-6">
        <UniversalExportBar
          title="Operating Expenses (OpEx) Voucher Log"
          moduleName="Operating Expenses"
          fileNamePrefix="Mr_Mushroom_Operating_Expenses"
          sheetName="Operating_Expenses"
          rows={data.operatingExpenses || []}
          onLogExport={onLogExport}
        />

        <form
          onSubmit={handleAddExpense}
          className="grid grid-cols-1 md:grid-cols-7 gap-3 mt-4 pb-4 border-b border-slate-200"
        >
          <input
            type="text"
            value={expForm.voucherNo}
            onChange={(e) => setExpForm({ ...expForm, voucherNo: e.target.value })}
            className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            placeholder="Voucher No"
            required
          />
          <input
            type="date"
            value={expForm.date}
            onChange={(e) => setExpForm({ ...expForm, date: e.target.value })}
            className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
          />
          <select
            value={expForm.category}
            onChange={(e) => setExpForm({ ...expForm, category: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
          >
            <option value="Factory Rent">Factory Rent</option>
            <option value="Electricity & Humidity Control">Electricity & Humidity Control</option>
            <option value="Raw Material Procurement">Raw Material Procurement</option>
            <option value="Daily Labor Wages">Daily Labor Wages</option>
            <option value="Lab Sterilization & Fuel">Lab Sterilization & Fuel</option>
            <option value="Logistics & Cold Chain">Logistics & Cold Chain</option>
            <option value="Marketing & Packaging">Marketing & Packaging</option>
          </select>
          <input
            type="text"
            placeholder="Expense Particular / Description"
            value={expForm.description}
            onChange={(e) => setExpForm({ ...expForm, description: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md md:col-span-2"
            required
          />
          <input
            type="number"
            placeholder="Amount (৳)"
            value={expForm.amountBdt}
            onChange={(e) => setExpForm({ ...expForm, amountBdt: e.target.value })}
            className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            required
          />
          <div className="flex gap-2">
            <select
              value={expForm.paymentSource}
              onChange={(e) => setExpForm({ ...expForm, paymentSource: e.target.value })}
              className="w-full px-2 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            >
              <option value="Cash in Hand (Vault)">Cash in Hand</option>
              <option value="City Bank PLC - Corporate A/C">City Bank</option>
              <option value="Dutch-Bangla Bank PLC">DBBL Bank</option>
              <option value="Bkash Merchant Wallet">Bkash</option>
              <option value="Nagad Business Wallet">Nagad</option>
            </select>
            <button
              type="submit"
              className="px-3 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              + Post
            </button>
          </div>
        </form>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs text-slate-500">
                <th className="py-2.5 px-3 font-medium">Voucher & Date</th>
                <th className="py-2.5 px-3 font-medium">Expense Head</th>
                <th className="py-2.5 px-3 font-medium">Description</th>
                <th className="py-2.5 px-3 font-medium">Payment Source</th>
                <th className="py-2.5 px-3 font-medium">Approved By</th>
                <th className="py-2.5 px-3 font-medium text-right">Amount (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {(data.operatingExpenses || []).map((exp: any) => (
                <tr key={exp.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-mono">
                    <span className="font-semibold text-slate-900">{exp.voucherNo}</span>
                    <span className="text-slate-400 mx-1">·</span>
                    <span className="text-slate-500">{exp.date}</span>
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">{exp.category}</td>
                  <td className="py-2.5 px-3 text-slate-600">{exp.description}</td>
                  <td className="py-2.5 px-3 text-slate-700">{exp.paymentSource}</td>
                  <td className="py-2.5 px-3 text-slate-600">{exp.approvedBy}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                    ৳{exp.amountBdt.toLocaleString('en-BD')}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onOpenEditModal('expenses', exp)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                      >
                        <Pencil className="w-3 h-3" />
                        <span>Edit</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onApiDelete('expenses', exp.id)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    );
  }

  // Module 5: Investment & Equity (Ltd. Company)
  if (activeSubTab === 'equity') {
    return (
      <section className="bg-white border border-slate-200 rounded-lg p-6">
        <UniversalExportBar
          title="Shareholder Cap Table, Paid-Up Capital, Dividends & Director Drawings (Pvt. Ltd.)"
          moduleName="Equity & Capital"
          fileNamePrefix="Mr_Mushroom_Shareholder_Equity"
          sheetName="Shareholder_Equity"
          rows={data.equityRecords || []}
          onLogExport={onLogExport}
        />

        <form
          onSubmit={handleAddEquity}
          className="grid grid-cols-1 md:grid-cols-7 gap-3 mt-4 pb-4 border-b border-slate-200"
        >
          <input
            type="text"
            placeholder="Shareholder Name"
            value={eqForm.shareholderName}
            onChange={(e) => setEqForm({ ...eqForm, shareholderName: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md md:col-span-2"
            required
          />
          <input
            type="text"
            placeholder="Designation"
            value={eqForm.designation}
            onChange={(e) => setEqForm({ ...eqForm, designation: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
          />
          <input
            type="number"
            step="0.5"
            placeholder="Share %"
            value={eqForm.sharePercentage}
            onChange={(e) => setEqForm({ ...eqForm, sharePercentage: e.target.value })}
            className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
          />
          <input
            type="number"
            placeholder="Capital BDT"
            value={eqForm.initialCapitalBdt}
            onChange={(e) => setEqForm({ ...eqForm, initialCapitalBdt: e.target.value })}
            className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
          />
          <select
            value={eqForm.transactionType}
            onChange={(e) => setEqForm({ ...eqForm, transactionType: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
          >
            <option value="Capital Injection">Capital Injection</option>
            <option value="Dividend Distribution">Dividend Distribution</option>
            <option value="Director Drawing">Director Drawing</option>
            <option value="Director Loan">Director Loan</option>
          </select>
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Entry</span>
          </button>
        </form>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs text-slate-500">
                <th className="py-2.5 px-3 font-medium">Shareholder & Role</th>
                <th className="py-2.5 px-3 font-medium text-right">Share Ratio (%)</th>
                <th className="py-2.5 px-3 font-medium text-right">Initial Capital (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Add. Capital (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Dividends Paid (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Drawings / Loans (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Net Capital (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {(data.equityRecords || []).map((eq: any) => {
                const netEquity =
                  eq.initialCapitalBdt +
                  eq.additionalInvestmentBdt -
                  eq.directorsLoanOrDrawingBdt;
                return (
                  <tr key={eq.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-slate-900">{eq.shareholderName}</div>
                      <div className="text-[11px] text-slate-500">
                        {eq.designation} · {eq.numberOfShares.toLocaleString('en-BD')} Shares
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold">
                      {eq.sharePercentage.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      ৳{eq.initialCapitalBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-700">
                      +৳{eq.additionalInvestmentBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      ৳{eq.dividendPaidBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-amber-700">
                      -৳{eq.directorsLoanOrDrawingBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                      ৳{netEquity.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenEditModal('equity', eq)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onApiDelete('equity', eq.id)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    );
  }

  // Module 6: Loans & Liabilities
  if (activeSubTab === 'loans') {
    return (
      <section className="bg-white border border-slate-200 rounded-lg p-6">
        <UniversalExportBar
          title="Bank SME Loans, Equipment EMIs & Supplier Accounts Payable (AP)"
          moduleName="Loans & Liabilities"
          fileNamePrefix="Mr_Mushroom_Loans_Liabilities"
          sheetName="Loans_Liabilities"
          rows={data.loansLiabilities || []}
          onLogExport={onLogExport}
        />

        <form
          onSubmit={handleAddLoan}
          className="grid grid-cols-1 md:grid-cols-7 gap-3 mt-4 pb-4 border-b border-slate-200"
        >
          <input
            type="text"
            value={loanForm.referenceNo}
            onChange={(e) => setLoanForm({ ...loanForm, referenceNo: e.target.value })}
            className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            placeholder="Ref No"
          />
          <select
            value={loanForm.liabilityType}
            onChange={(e) => setLoanForm({ ...loanForm, liabilityType: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
          >
            <option value="Bank SME Agro Loan">Bank SME Agro Loan</option>
            <option value="Equipment Lease EMI">Equipment Lease EMI</option>
            <option value="Accounts Payable (Supplier Due)">Accounts Payable (Supplier Due)</option>
            <option value="Director Short-Term Loan">Director Short-Term Loan</option>
          </select>
          <input
            type="text"
            placeholder="Lender Bank or Supplier Name"
            value={loanForm.lenderOrSupplierName}
            onChange={(e) =>
              setLoanForm({ ...loanForm, lenderOrSupplierName: e.target.value })
            }
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md md:col-span-2"
            required
          />
          <input
            type="number"
            placeholder="Principal / Bill (৳)"
            value={loanForm.principalOrBillAmountBdt}
            onChange={(e) =>
              setLoanForm({ ...loanForm, principalOrBillAmountBdt: e.target.value })
            }
            className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            required
          />
          <input
            type="number"
            placeholder="Monthly EMI (৳)"
            value={loanForm.monthlyEmiBdt}
            onChange={(e) => setLoanForm({ ...loanForm, monthlyEmiBdt: e.target.value })}
            className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
          />
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Liability</span>
          </button>
        </form>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs text-slate-500">
                <th className="py-2.5 px-3 font-medium">Reference & Type</th>
                <th className="py-2.5 px-3 font-medium">Lender / Supplier</th>
                <th className="py-2.5 px-3 font-medium text-right">Principal / Bill (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Interest / EMI</th>
                <th className="py-2.5 px-3 font-medium text-right">Total Paid (৳)</th>
                <th className="py-2.5 px-3 font-medium text-right">Outstanding (৳)</th>
                <th className="py-2.5 px-3 font-medium">Next Due</th>
                <th className="py-2.5 px-3 font-medium text-right">
                  Actions (Pay / Edit / Delete)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {(data.loansLiabilities || []).map((item: any) => {
                const payChunk =
                  item.monthlyEmiBdt > 0 ? item.monthlyEmiBdt : item.outstandingBalanceBdt;
                return (
                  <tr key={item.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3">
                      <div className="font-mono font-semibold text-slate-900">
                        {item.referenceNo}
                      </div>
                      <div className="text-[11px] text-slate-500">{item.liabilityType}</div>
                    </td>
                    <td className="py-2.5 px-3 font-medium text-slate-900">
                      {item.lenderOrSupplierName}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      ৳{item.principalOrBillAmountBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                      {item.interestRatePct}% · EMI ৳{item.monthlyEmiBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-700">
                      ৳{item.totalPaidBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-red-700">
                      ৳{item.outstandingBalanceBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">
                      {item.nextDueDate} ({item.status})
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        {item.outstandingBalanceBdt > 0 && (
                          <button
                            type="button"
                            onClick={() =>
                              onApiPost(`/api/erp/loans/${item.id}/pay`, {
                                amount: Math.min(item.outstandingBalanceBdt, payChunk),
                              })
                            }
                            className="px-2 py-1 text-[11px] font-mono font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded cursor-pointer whitespace-nowrap"
                          >
                            Pay ৳
                            {Math.min(item.outstandingBalanceBdt, payChunk).toLocaleString(
                              'en-BD'
                            )}
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onOpenEditModal('loans', item)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onApiDelete('loans', item.id)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    );
  }

  // Module 7: Banking & Cash Reconciliation
  if (activeSubTab === 'banking') {
    return (
      <div className="space-y-8">
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="01. Cash in Hand, Corporate Bank Accounts & Mobile Wallets (Bkash / Nagad)"
            moduleName="Banking & Cash"
            fileNamePrefix="Mr_Mushroom_Treasury_Balances"
            sheetName="Bank_Cash_Balances"
            rows={data.bankCashAccounts || []}
            onLogExport={onLogExport}
          />

          <form
            onSubmit={handleAddAccount}
            className="grid grid-cols-1 md:grid-cols-6 gap-3 mt-4 pb-4 border-b border-slate-200"
          >
            <input
              type="text"
              placeholder="Account Name (e.g. Brac Bank SME)"
              value={accForm.accountName}
              onChange={(e) => setAccForm({ ...accForm, accountName: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md md:col-span-2"
              required
            />
            <select
              value={accForm.accountType}
              onChange={(e) => setAccForm({ ...accForm, accountType: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            >
              <option value="Bank">Bank Account</option>
              <option value="Mobile Wallet">Mobile Wallet (Bkash/Nagad/Rocket)</option>
              <option value="Cash">Cash Vault / Petty Cash</option>
            </select>
            <input
              type="text"
              placeholder="Account / Wallet Number"
              value={accForm.accountNumber}
              onChange={(e) => setAccForm({ ...accForm, accountNumber: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              required
            />
            <input
              type="number"
              placeholder="Opening Balance (৳)"
              value={accForm.openingBalanceBdt}
              onChange={(e) =>
                setAccForm({
                  ...accForm,
                  openingBalanceBdt: e.target.value,
                  currentBalanceBdt: e.target.value,
                })
              }
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              required
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Account</span>
            </button>
          </form>

          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Account Title</th>
                  <th className="py-2.5 px-3 font-medium">Type</th>
                  <th className="py-2.5 px-3 font-medium">Account / Merchant Number</th>
                  <th className="py-2.5 px-3 font-medium text-right">Opening Balance (৳)</th>
                  <th className="py-2.5 px-3 font-medium text-right">
                    Current Reconciled Balance (৳)
                  </th>
                  <th className="py-2.5 px-3 font-medium">Last Reconciled</th>
                  <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {(data.bankCashAccounts || []).map((acc: any) => (
                  <tr key={acc.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-semibold text-slate-900">
                      {acc.accountName}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">{acc.accountType}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">{acc.accountNumber}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                      ৳{acc.openingBalanceBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-emerald-700">
                      ৳{acc.currentBalanceBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-500">
                      {acc.lastReconciledDate}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenEditModal('accounts', acc)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onApiDelete('accounts', acc.id)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="02. Internal Fund Transfer & Settlement Reconciliation Register"
            moduleName="Banking & Cash"
            fileNamePrefix="Mr_Mushroom_Fund_Transfers"
            sheetName="Fund_Transfers"
            rows={data.fundTransfers || []}
            onLogExport={onLogExport}
          />

          <form
            onSubmit={handleExecuteTransfer}
            className="grid grid-cols-1 md:grid-cols-6 gap-3 mt-4 pb-4 border-b border-slate-200"
          >
            <select
              value={trfForm.fromAccount}
              onChange={(e) => setTrfForm({ ...trfForm, fromAccount: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            >
              {(data.bankCashAccounts || []).map((a: any) => (
                <option key={a.id} value={a.accountName}>
                  From: {a.accountName}
                </option>
              ))}
            </select>
            <select
              value={trfForm.toAccount}
              onChange={(e) => setTrfForm({ ...trfForm, toAccount: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            >
              {(data.bankCashAccounts || []).map((a: any) => (
                <option key={a.id} value={a.accountName}>
                  To: {a.accountName}
                </option>
              ))}
            </select>
            <input
              type="number"
              placeholder="Transfer Amount (৳)"
              value={trfForm.amountBdt}
              onChange={(e) => setTrfForm({ ...trfForm, amountBdt: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
              required
            />
            <input
              type="number"
              placeholder="Cashout/Bank Fee (৳)"
              value={trfForm.transferFeeBdt}
              onChange={(e) => setTrfForm({ ...trfForm, transferFeeBdt: e.target.value })}
              className="px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md"
            />
            <input
              type="text"
              placeholder="Settlement Remarks"
              value={trfForm.remarks}
              onChange={(e) => setTrfForm({ ...trfForm, remarks: e.target.value })}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap"
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
              <span>Transfer Funds</span>
            </button>
          </form>

          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Ref & Date</th>
                  <th className="py-2.5 px-3 font-medium">Source Account</th>
                  <th className="py-2.5 px-3 font-medium">Destination Account</th>
                  <th className="py-2.5 px-3 font-medium text-right">Amount (৳)</th>
                  <th className="py-2.5 px-3 font-medium text-right">Fee (৳)</th>
                  <th className="py-2.5 px-3 font-medium">Remarks</th>
                  <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {(data.fundTransfers || []).map((t: any) => (
                  <tr key={t.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono">
                      <span className="font-semibold text-slate-900">{t.transferRef}</span> ·{' '}
                      {t.date}
                    </td>
                    <td className="py-2.5 px-3 text-slate-800">{t.fromAccount}</td>
                    <td className="py-2.5 px-3 text-emerald-800 font-medium">{t.toAccount}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold">
                      ৳{t.amountBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-500">
                      ৳{t.transferFeeBdt.toLocaleString('en-BD')}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">{t.remarks}</td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenEditModal('transfers', t)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                        >
                          <Pencil className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onApiDelete('transfers', t.id)}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    );
  }

  // Module 8: Corporate Financial Statements (P&L, Balance Sheet, Cash Flow)
  if (activeSubTab === 'statements') {
    const grossSales = (data.salesInvoices || []).reduce(
      (s: number, i: any) => s + i.subtotalBdt,
      0
    );
    const salesDiscounts = (data.salesInvoices || []).reduce(
      (s: number, i: any) => s + i.totalDiscountBdt,
      0
    );
    const netSalesRevenue = grossSales - salesDiscounts;
    const totalBatchCogs = (data.productionBatches || []).reduce(
      (s: number, b: any) => s + b.totalCogs,
      0
    );
    const totalWastageLoss = (data.wastageLogs || []).reduce(
      (s: number, w: any) => s + w.estimatedLossBdt,
      0
    );
    const grossProfit = netSalesRevenue - totalBatchCogs * 0.18 - totalWastageLoss;
    const totalOpEx = (data.operatingExpenses || []).reduce(
      (s: number, e: any) => s + e.amountBdt,
      0
    );
    const totalPayroll = (data.payrollRecords || []).reduce(
      (s: number, p: any) => s + p.netPayable,
      0
    );
    const netOperatingProfit = grossProfit - totalOpEx - totalPayroll;

    const pnlRows = [
      {
        Line_Item: 'Gross Multi-Channel Sales Revenue',
        Category: 'Revenue',
        Amount_BDT: grossSales,
      },
      {
        Line_Item: 'Less: Item & Invoice Discounts',
        Category: 'Contra Revenue',
        Amount_BDT: -salesDiscounts,
      },
      { Line_Item: 'Net Sales Revenue', Category: 'Subtotal', Amount_BDT: netSalesRevenue },
      {
        Line_Item: 'Allocated Batch Cultivation CoGS',
        Category: 'Direct Cost',
        Amount_BDT: -Number((totalBatchCogs * 0.18).toFixed(2)),
      },
      {
        Line_Item: 'Contamination & Spoilage Loss',
        Category: 'Direct Cost',
        Amount_BDT: -totalWastageLoss,
      },
      {
        Line_Item: 'Gross Profit',
        Category: 'Subtotal',
        Amount_BDT: Number(grossProfit.toFixed(2)),
      },
      {
        Line_Item: 'Operating Expenses (OpEx Vouchers)',
        Category: 'Operating Expense',
        Amount_BDT: -totalOpEx,
      },
      {
        Line_Item: 'Monthly Employee Payroll & Overtime',
        Category: 'Operating Expense',
        Amount_BDT: -totalPayroll,
      },
      {
        Line_Item: 'Net Profit / (Loss) Before Tax',
        Category: 'Bottom Line',
        Amount_BDT: Number(netOperatingProfit.toFixed(2)),
      },
    ];

    const totalCashAndBank = (data.bankCashAccounts || []).reduce(
      (s: number, a: any) => s + a.currentBalanceBdt,
      0
    );
    const totalReceivables = (data.salesInvoices || []).reduce(
      (s: number, i: any) => s + i.dueAmountBdt,
      0
    );
    const totalInventoryValue = (data.inventoryItems || []).reduce(
      (s: number, i: any) => s + i.currentStock * i.unitCost,
      0
    );
    const fixedBiotechAssets = 2650000;
    const totalAssets =
      totalCashAndBank + totalReceivables + totalInventoryValue + fixedBiotechAssets;

    const totalLiabilities = (data.loansLiabilities || []).reduce(
      (s: number, l: any) => s + l.outstandingBalanceBdt,
      0
    );
    const totalPaidUpEquity = (data.equityRecords || []).reduce(
      (s: number, eq: any) =>
        s + eq.initialCapitalBdt + eq.additionalInvestmentBdt - eq.directorsLoanOrDrawingBdt,
      0
    );
    const retainedEarnings = totalAssets - totalLiabilities - totalPaidUpEquity;

    const balanceSheetRows = [
      {
        Section: 'Current Assets',
        Head: 'Cash, Bank & Mobile Wallets (Bkash/Nagad)',
        Amount_BDT: totalCashAndBank,
      },
      {
        Section: 'Current Assets',
        Head: 'Accounts Receivable (Customer Dues)',
        Amount_BDT: totalReceivables,
      },
      {
        Section: 'Current Assets',
        Head: 'Inventory Valuation (Raw, Spawn & Processed)',
        Amount_BDT: Number(totalInventoryValue.toFixed(2)),
      },
      {
        Section: 'Non-Current Assets',
        Head: 'Cultivation Chambers, Autoclave & Lab Plant',
        Amount_BDT: fixedBiotechAssets,
      },
      {
        Section: 'TOTAL ASSETS',
        Head: 'Total Company Assets',
        Amount_BDT: Number(totalAssets.toFixed(2)),
      },
      {
        Section: 'Liabilities',
        Head: 'Bank SME Loans, Lease EMIs & Supplier Payables',
        Amount_BDT: totalLiabilities,
      },
      {
        Section: 'Shareholders Equity',
        Head: 'Paid-Up Share Capital & Additional Injections',
        Amount_BDT: totalPaidUpEquity,
      },
      {
        Section: 'Shareholders Equity',
        Head: 'Retained Earnings & Reserves',
        Amount_BDT: Number(retainedEarnings.toFixed(2)),
      },
      {
        Section: 'TOTAL LIABILITIES & EQUITY',
        Head: 'Total Liabilities & Shareholders Equity',
        Amount_BDT: Number(totalAssets.toFixed(2)),
      },
    ];

    const cashInflowsSales = (data.salesInvoices || []).reduce(
      (s: number, i: any) => s + i.paidAmountBdt,
      0
    );
    const cashFlowRows = [
      {
        Activity: 'Operating',
        Particular: 'Cash Collections from Customers (POS/Wholesale)',
        Cash_Flow_BDT: cashInflowsSales,
      },
      {
        Activity: 'Operating',
        Particular: 'Operating Expense Disbursements',
        Cash_Flow_BDT: -totalOpEx,
      },
      {
        Activity: 'Operating',
        Particular: 'Staff Payroll & Overtime Paid',
        Cash_Flow_BDT: -totalPayroll,
      },
      {
        Activity: 'Financing',
        Particular: 'Additional Shareholder Capital Injected',
        Cash_Flow_BDT: (data.equityRecords || []).reduce(
          (s: number, e: any) => s + e.additionalInvestmentBdt,
          0
        ),
      },
      {
        Activity: 'Financing',
        Particular: 'Dividends & Loan EMIs Repaid',
        Cash_Flow_BDT: -(data.equityRecords || []).reduce(
          (s: number, e: any) => s + e.dividendPaidBdt,
          0
        ),
      },
      {
        Activity: 'Closing Treasury Position',
        Particular: 'Reconciled Cash, Bank & Mobile Wallets',
        Cash_Flow_BDT: totalCashAndBank,
      },
    ];

    return (
      <div className="space-y-8">
        {/* P&L Statement */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="01. Statement of Profit & Loss (Income Statement)"
            moduleName="Corporate Reports"
            fileNamePrefix="Mr_Mushroom_Profit_And_Loss"
            sheetName="Profit_And_Loss"
            rows={pnlRows}
            onLogExport={onLogExport}
          />
          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Statement Line Item</th>
                  <th className="py-2.5 px-3 font-medium">Classification</th>
                  <th className="py-2.5 px-3 font-medium text-right">Amount (BDT ৳)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {pnlRows.map((r, idx) => {
                  const isBold = r.Category === 'Subtotal' || r.Category === 'Bottom Line';
                  return (
                    <tr
                      key={idx}
                      className={isBold ? 'bg-slate-50 font-semibold' : 'hover:bg-slate-50'}
                    >
                      <td className="py-2.5 px-3 text-slate-900">{r.Line_Item}</td>
                      <td className="py-2.5 px-3 text-slate-500">{r.Category}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                        ৳{r.Amount_BDT.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* Balance Sheet */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="02. Corporate Balance Sheet (Statement of Financial Position)"
            moduleName="Corporate Reports"
            fileNamePrefix="Mr_Mushroom_Balance_Sheet"
            sheetName="Balance_Sheet"
            rows={balanceSheetRows}
            onLogExport={onLogExport}
          />
          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Balance Sheet Section</th>
                  <th className="py-2.5 px-3 font-medium">Account Head</th>
                  <th className="py-2.5 px-3 font-medium text-right">Valuation (BDT ৳)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {balanceSheetRows.map((r, idx) => {
                  const isTotal = r.Section.startsWith('TOTAL');
                  return (
                    <tr
                      key={idx}
                      className={isTotal ? 'bg-slate-50 font-bold' : 'hover:bg-slate-50'}
                    >
                      <td className="py-2.5 px-3 text-slate-700">{r.Section}</td>
                      <td className="py-2.5 px-3 text-slate-900">{r.Head}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                        ৳{r.Amount_BDT.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* Cash Flow Statement */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <UniversalExportBar
            title="03. Statement of Cash Flows"
            moduleName="Corporate Reports"
            fileNamePrefix="Mr_Mushroom_Cash_Flow_Statement"
            sheetName="Cash_Flow"
            rows={cashFlowRows}
            onLogExport={onLogExport}
          />
          <div className="overflow-x-auto mt-4">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Cash Flow Activity</th>
                  <th className="py-2.5 px-3 font-medium">Particulars</th>
                  <th className="py-2.5 px-3 font-medium text-right">Cash Impact (BDT ৳)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {cashFlowRows.map((r, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-medium text-slate-700">{r.Activity}</td>
                    <td className="py-2.5 px-3 text-slate-900">{r.Particular}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold">
                      ৳{r.Cash_Flow_BDT.toLocaleString('en-BD', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    );
  }

  // Module 9: Audit Trail & RBAC Security
  return (
    <div className="space-y-8">
      <section className="bg-white border border-slate-200 rounded-lg p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              01. Role-Based Access Control (RBAC) & System Officers Management
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Active User Role: <span className="font-semibold text-slate-900">{userRole}</span> ·
              Add, Edit or Delete system users & officers below
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(['Admin', 'Accountant', 'Manager'] as const).map((roleOption) => (
              <button
                key={roleOption}
                type="button"
                onClick={() => onSwitchRole(roleOption)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  userRole === roleOption
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {roleOption}
              </button>
            ))}
          </div>
        </div>

        <form
          onSubmit={handleAddSystemUser}
          className="grid grid-cols-1 md:grid-cols-4 gap-3 mt-4 pb-4 border-b border-slate-200"
        >
          <input
            type="text"
            placeholder="Officer / User Full Name"
            value={userForm.name}
            onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            required
          />
          <input
            type="email"
            placeholder="Officer Email Address"
            value={userForm.email}
            onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
            required
          />
          <select
            value={userForm.role}
            onChange={(e) => setUserForm({ ...userForm, role: e.target.value })}
            className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md"
          >
            <option value="Admin">Admin (Full Control)</option>
            <option value="Accountant">Accountant (Finance & Reports)</option>
            <option value="Manager">Manager (Plant, HR & Inventory)</option>
          </select>
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 rounded-md hover:bg-emerald-600 cursor-pointer whitespace-nowrap"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Add System Officer</span>
          </button>
        </form>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2 px-3 font-medium">Officer / User Name</th>
                <th className="py-2 px-3 font-medium">Email</th>
                <th className="py-2 px-3 font-medium">Assigned RBAC Role</th>
                <th className="py-2 px-3 font-medium text-right">Edit / Delete</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {(data.systemUsers || []).map((u: any) => (
                <tr key={u.id} className="hover:bg-slate-50">
                  <td className="py-2 px-3 font-semibold text-slate-900">{u.name}</td>
                  <td className="py-2 px-3 font-mono text-slate-600">{u.email}</td>
                  <td className="py-2 px-3 font-medium text-emerald-800">{u.role}</td>
                  <td className="py-2 px-3 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onOpenEditModal('users', u)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                      >
                        <Pencil className="w-3 h-3" />
                        <span>Edit</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onApiDelete('users', u.id)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6 pt-4 border-t border-slate-200 text-xs">
          <div className="p-4 border border-slate-200 rounded-md">
            <div className="flex items-center gap-2 font-semibold text-slate-900">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>Admin (Managing Director)</span>
            </div>
            <p className="text-slate-600 mt-1">
              Full access to all 9 modules, Shareholder Cap Table, Loan settlements, record edits/deletions, and universal Excel/Google Sheets exports.
            </p>
          </div>
          <div className="p-4 border border-slate-200 rounded-md">
            <div className="flex items-center gap-2 font-semibold text-slate-900">
              <CheckCircle2 className="w-4 h-4 text-slate-700" />
              <span>Accountant (Finance Officer)</span>
            </div>
            <p className="text-slate-600 mt-1">
              Manages invoices, OpEx vouchers, payroll, bank reconciliations, and financial statements.
            </p>
          </div>
          <div className="p-4 border border-slate-200 rounded-md">
            <div className="flex items-center gap-2 font-semibold text-slate-900">
              <CheckCircle2 className="w-4 h-4 text-slate-700" />
              <span>Manager (Plant & Lab Head)</span>
            </div>
            <p className="text-slate-600 mt-1">
              Manages HR officers, cultivation batches, spawn & sawdust stock, spoilage logs, and attendance.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-white border border-slate-200 rounded-lg p-6">
        <UniversalExportBar
          title="02. Compliance & Security Audit Log"
          moduleName="Audit & RBAC"
          fileNamePrefix="Mr_Mushroom_Security_Audit_Log"
          sheetName="Audit_Log"
          rows={data.auditLogs || []}
          onLogExport={onLogExport}
        />

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs text-slate-500">
                <th className="py-2.5 px-3 font-medium">Timestamp</th>
                <th className="py-2.5 px-3 font-medium">User & Role</th>
                <th className="py-2.5 px-3 font-medium">Action</th>
                <th className="py-2.5 px-3 font-medium">Module</th>
                <th className="py-2.5 px-3 font-medium">Reference</th>
                <th className="py-2.5 px-3 font-medium">Audit Trail Details</th>
                <th className="py-2.5 px-3 font-medium text-right">Edit / Delete</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {(data.auditLogs || []).map((log: any) => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-mono tabular-nums text-slate-600 whitespace-nowrap">
                    {log.timestamp}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="font-medium text-slate-900">{log.userName}</span>
                    <span className="text-slate-400 mx-1">·</span>
                    <span className="text-slate-500">{log.userRole}</span>
                  </td>
                  <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                    {log.action}
                  </td>
                  <td className="py-2.5 px-3 text-slate-700">{log.module}</td>
                  <td className="py-2.5 px-3 font-mono text-slate-600">{log.entityRef}</td>
                  <td className="py-2.5 px-3 text-slate-700">{log.details}</td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onOpenEditModal('audit', log)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded cursor-pointer"
                      >
                        <Pencil className="w-3 h-3" />
                        <span>Edit</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onApiDelete('audit', log.id)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium bg-red-50 hover:bg-red-100 text-red-700 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
