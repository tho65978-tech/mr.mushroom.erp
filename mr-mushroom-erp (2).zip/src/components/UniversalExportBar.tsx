import React, { useState } from 'react';
import {
  FileSpreadsheet,
  FileText,
  Check,
  CloudUpload,
  ExternalLink,
  X,
  Printer,
  Download,
} from 'lucide-react';
import {
  exportToExcel,
  exportToGoogleSheetsCsv,
  exportTableToPdf,
  printDataTable,
  createLiveGoogleSpreadsheet,
  ExportColumn,
} from '../utils/exportUtils.ts';

interface UniversalExportBarProps<T = any> {
  title: string;
  moduleName: string;
  fileNamePrefix: string;
  sheetName: string;
  rows: T[];
  columns?: ExportColumn<T>[];
  onLogExport?: (moduleName: string, format: string, recordCount: number, fileName: string) => void;
}

export function UniversalExportBar<T = any>({
  title,
  moduleName,
  fileNamePrefix,
  sheetName,
  rows,
  columns,
  onLogExport,
}: UniversalExportBarProps<T>) {
  const [recentExport, setRecentExport] = useState<'xlsx' | 'csv' | 'pdf' | 'print' | null>(null);
  const [confirmGoogleSheet, setConfirmGoogleSheet] = useState(false);
  const [isSyncingSheets, setIsSyncingSheets] = useState(false);
  const [createdSheetUrl, setCreatedSheetUrl] = useState<string | null>(null);
  const [sheetError, setSheetError] = useState<string | null>(null);

  const handlePrint = () => {
    printDataTable(rows, title, moduleName, fileNamePrefix, columns, (fileName, count) => {
      if (onLogExport) {
        onLogExport(moduleName, 'Print Report', count, fileName);
      }
    });
    setRecentExport('print');
    setTimeout(() => setRecentExport(null), 2200);
  };

  const handlePdf = () => {
    exportTableToPdf(rows, title, moduleName, fileNamePrefix, columns, (fileName, count) => {
      if (onLogExport) {
        onLogExport(moduleName, 'PDF Document (.pdf)', count, fileName);
      }
    });
    setRecentExport('pdf');
    setTimeout(() => setRecentExport(null), 2200);
  };

  const handleExcel = () => {
    exportToExcel(rows, fileNamePrefix, sheetName, columns, (fileName, count) => {
      if (onLogExport) {
        onLogExport(moduleName, 'Excel (.xlsx)', count, fileName);
      }
    });
    setRecentExport('xlsx');
    setTimeout(() => setRecentExport(null), 2200);
  };

  const handleCsv = () => {
    exportToGoogleSheetsCsv(rows, fileNamePrefix, columns, (fileName, count) => {
      if (onLogExport) {
        onLogExport(moduleName, 'Google Sheets (.csv)', count, fileName);
      }
    });
    setRecentExport('csv');
    setTimeout(() => setRecentExport(null), 2200);
  };

  const handleConfirmedGoogleSheetsSync = async () => {
    setConfirmGoogleSheet(false);
    setIsSyncingSheets(true);
    setSheetError(null);
    try {
      const res = await createLiveGoogleSpreadsheet(
        rows,
        fileNamePrefix.replace(/_/g, ' '),
        sheetName,
        columns,
        (url, count) => {
          if (onLogExport) {
            onLogExport(moduleName, 'Live Google Sheet API', count, url);
          }
        }
      );
      setCreatedSheetUrl(res.spreadsheetUrl);
    } catch (err: any) {
      setSheetError(err.message || 'Failed to sync with Google Sheets');
    } finally {
      setIsSyncingSheets(false);
    }
  };

  return (
    <div className="space-y-2 pb-3 border-b border-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold text-slate-900">{title}</h3>
          <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
            <span>{moduleName}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{rows.length} records</span>
            <span aria-hidden="true">·</span>
            <span>Print, PDF, Excel (.xlsx) & Google Sheets Ready</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 border border-slate-300 rounded-md hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Print formatted report table"
          >
            {recentExport === 'print' ? (
              <Check className="w-3.5 h-3.5 text-emerald-700" />
            ) : (
              <Printer className="w-3.5 h-3.5 text-slate-700" />
            )}
            <span>{recentExport === 'print' ? 'Printing...' : 'Print Data'}</span>
          </button>

          <button
            type="button"
            onClick={handlePdf}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Download clean printable PDF report"
          >
            {recentExport === 'pdf' ? (
              <Check className="w-3.5 h-3.5 text-emerald-700" />
            ) : (
              <Download className="w-3.5 h-3.5 text-slate-700" />
            )}
            <span>{recentExport === 'pdf' ? 'Downloaded .pdf' : 'Download PDF'}</span>
          </button>

          <button
            type="button"
            onClick={handleExcel}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-50 border border-emerald-300 rounded-md hover:bg-emerald-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Download formatted Microsoft Excel (.xlsx) workbook"
          >
            {recentExport === 'xlsx' ? (
              <Check className="w-3.5 h-3.5 text-emerald-700" />
            ) : (
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            )}
            <span>{recentExport === 'xlsx' ? 'Exported .xlsx' : 'Excel (.xlsx)'}</span>
          </button>

          <button
            type="button"
            onClick={handleCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Download UTF-8 CSV ready for direct import into Google Sheets"
          >
            {recentExport === 'csv' ? (
              <Check className="w-3.5 h-3.5 text-emerald-700" />
            ) : (
              <FileText className="w-3.5 h-3.5 text-slate-600" />
            )}
            <span>{recentExport === 'csv' ? 'Exported .csv' : 'CSV'}</span>
          </button>

          <button
            type="button"
            onClick={() => setConfirmGoogleSheet(true)}
            disabled={isSyncingSheets}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Create a live Google Spreadsheet in your Google Drive"
          >
            <CloudUpload className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isSyncingSheets ? 'Creating Sheet...' : 'Google Sheets'}</span>
          </button>
        </div>
      </div>

      {/* Confirmation Dialog for Mutating User's Google Drive / Sheets */}
      {confirmGoogleSheet && (
        <div className="p-3 bg-slate-100 border border-slate-300 rounded-md flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="text-slate-800">
            <span className="font-semibold">Confirm Google Sheets Export:</span> Create a new spreadsheet{' '}
            <span className="font-mono font-medium">"{fileNamePrefix}"</span> with{' '}
            <span className="font-mono font-semibold">{rows.length}</span> rows in your Google Drive?
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleConfirmedGoogleSheetsSync}
              className="px-3 py-1 font-semibold bg-emerald-700 text-white rounded hover:bg-emerald-600 cursor-pointer whitespace-nowrap"
            >
              Confirm & Create Sheet
            </button>
            <button
              type="button"
              onClick={() => setConfirmGoogleSheet(false)}
              className="px-3 py-1 font-medium bg-white text-slate-700 border border-slate-300 rounded hover:bg-slate-50 cursor-pointer whitespace-nowrap"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Created Live Google Sheet Banner */}
      {createdSheetUrl && (
        <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-md flex items-center justify-between text-xs text-emerald-900">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>Live Google Spreadsheet created in your Google Drive!</span>
            <a
              href={createdSheetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 font-semibold text-emerald-800 underline hover:text-emerald-950"
            >
              <span>Open in Google Sheets</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <button
            type="button"
            onClick={() => setCreatedSheetUrl(null)}
            className="text-emerald-700 hover:text-emerald-950 p-0.5 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {sheetError && (
        <div className="p-2.5 bg-red-50 border border-red-200 rounded-md flex items-center justify-between text-xs text-red-800">
          <span>{sheetError}</span>
          <button
            type="button"
            onClick={() => setSheetError(null)}
            className="text-red-600 hover:text-red-900 p-0.5 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}
