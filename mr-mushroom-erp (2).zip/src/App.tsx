import React, { useEffect, useState, useCallback } from 'react';
import { User } from 'firebase/auth';
import {
  FileSpreadsheet,
  LayoutDashboard,
  Users,
  Package,
  ShoppingCart,
  Receipt,
  PieChart,
  Landmark,
  Wallet,
  FileBarChart,
  ShieldAlert,
  LogOut,
  Terminal,
  AlertTriangle,
} from 'lucide-react';
import { auth, initAuth, googleSignIn, logout } from './lib/firebase.ts';
import { exportMasterErpWorkbook } from './utils/exportUtils.ts';
import { UniversalExportBar } from './components/UniversalExportBar.tsx';
import { OperationsModules } from './components/OperationsModules.tsx';
import { FinanceModules } from './components/FinanceModules.tsx';
import { InvoicePrintModal, SalesInvoiceRecord } from './components/InvoicePrintModal.tsx';
import { PythonSpecModal } from './components/PythonSpecModal.tsx';
import { EditRecordModal } from './components/EditRecordModal.tsx';

import facilityBannerImg from './assets/images/mushroom_facility_banner_1791113477698.jpg';
import productPowderImg from './assets/images/product_oyster_powder_1791113491562.jpg';
import directorAvatarImg from './assets/images/avatar_managing_director_1791113505959.jpg';

type ModuleKey =
  | 'dashboard'
  | 'attendance'
  | 'inventory'
  | 'sales'
  | 'expenses'
  | 'equity'
  | 'loans'
  | 'banking'
  | 'statements'
  | 'audit';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [idToken, setIdToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState<boolean>(true);
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);
  const [loadingData, setLoadingData] = useState<boolean>(false);
  const [apiError, setApiError] = useState<string | null>(null);

  const [activeModule, setActiveModule] = useState<ModuleKey>('dashboard');
  const [erpData, setErpData] = useState<any>({
    currentUser: { name: 'Ariful Haque', email: '', role: 'Admin' },
    employees: [],
    attendanceLogs: [],
    payrollRecords: [],
    inventoryItems: [],
    productionBatches: [],
    wastageLogs: [],
    salesInvoices: [],
    operatingExpenses: [],
    equityRecords: [],
    loansLiabilities: [],
    bankCashAccounts: [],
    fundTransfers: [],
    auditLogs: [],
  });

  const [invoiceModalState, setInvoiceModalState] = useState<{
    invoice: SalesInvoiceRecord | null;
    format: 'a4' | 'thermal';
  }>({ invoice: null, format: 'a4' });
  const [editModalState, setEditModalState] = useState<{
    moduleKey: string | null;
    record: Record<string, any> | null;
  }>({ moduleKey: null, record: null });
  const [isPythonModalOpen, setIsPythonModalOpen] = useState(false);

  const fetchBootstrapData = useCallback(async (currentUser: User) => {
    setLoadingData(true);
    setApiError(null);
    try {
      const freshIdToken = await currentUser.getIdToken();
      setIdToken(freshIdToken);
      const res = await fetch('/api/erp/bootstrap', {
        headers: { Authorization: `Bearer ${freshIdToken}` },
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Failed to load ERP data');
      }
      const payload = await res.json();
      setErpData(payload);
    } catch (err: any) {
      console.error('Error loading ERP bootstrap:', err);
      setApiError(err.message || 'Could not load database records.');
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = initAuth(
      async (authedUser) => {
        setUser(authedUser);
        setNeedsAuth(false);
        await fetchBootstrapData(authedUser);
      },
      () => {
        setUser(null);
        setIdToken(null);
        setNeedsAuth(true);
      }
    );
    return () => unsubscribe();
  }, [fetchBootstrapData]);

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setApiError(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setUser(result.user);
        setIdToken(result.idToken);
        setNeedsAuth(false);
        await fetchBootstrapData(result.user);
      }
    } catch (err: any) {
      setApiError(err.message || 'Google Sign-In failed. Please try again.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSignOut = async () => {
    await logout();
    setUser(null);
    setIdToken(null);
    setNeedsAuth(true);
  };

  const getValidIdToken = async (): Promise<string> => {
    if (auth.currentUser) {
      return await auth.currentUser.getIdToken();
    }
    if (idToken) return idToken;
    throw new Error('Authentication required');
  };

  const handleApiPost = async (endpoint: string, body: any) => {
    setApiError(null);
    try {
      const token = await getValidIdToken();
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Operation failed');
      }
      if (auth.currentUser) {
        await fetchBootstrapData(auth.currentUser);
      }
    } catch (err: any) {
      setApiError(err.message);
    }
  };

  const handleApiPut = async (endpoint: string, body: any) => {
    setApiError(null);
    try {
      const token = await getValidIdToken();
      const res = await fetch(endpoint, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Update failed');
      }
      if (auth.currentUser) {
        await fetchBootstrapData(auth.currentUser);
      }
    } catch (err: any) {
      setApiError(err.message);
    }
  };

  const handleApiDelete = async (moduleKey: string, id: number) => {
    setApiError(null);
    try {
      const token = await getValidIdToken();
      const res = await fetch(`/api/erp/${moduleKey}/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Delete failed');
      }
      if (auth.currentUser) {
        await fetchBootstrapData(auth.currentUser);
      }
    } catch (err: any) {
      setApiError(err.message);
    }
  };

  const handleLogExport = async (
    moduleName: string,
    format: string,
    recordCount: number,
    fileName: string
  ) => {
    try {
      const token = await getValidIdToken();
      await fetch('/api/erp/audit-export', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ moduleName, format, recordCount, fileName }),
      });
      if (auth.currentUser) {
        await fetchBootstrapData(auth.currentUser);
      }
    } catch {
      // Non-blocking audit log
    }
  };

  const handleMasterWorkbookExport = () => {
    exportMasterErpWorkbook(
      [
        { sheetName: 'Sales_Register', rows: erpData.salesInvoices || [] },
        { sheetName: 'Operating_Expenses', rows: erpData.operatingExpenses || [] },
        { sheetName: 'Inventory_Stock', rows: erpData.inventoryItems || [] },
        { sheetName: 'Production_Batches', rows: erpData.productionBatches || [] },
        { sheetName: 'Wastage_Spoilage', rows: erpData.wastageLogs || [] },
        { sheetName: 'Attendance_Logs', rows: erpData.attendanceLogs || [] },
        { sheetName: 'Monthly_Payroll', rows: erpData.payrollRecords || [] },
        { sheetName: 'HR_Officers_Team', rows: erpData.employees || [] },
        { sheetName: 'System_Officers_RBAC', rows: erpData.systemUsers || [] },
        { sheetName: 'Shareholder_Equity', rows: erpData.equityRecords || [] },
        { sheetName: 'Loans_Liabilities', rows: erpData.loansLiabilities || [] },
        { sheetName: 'Bank_Cash_Balances', rows: erpData.bankCashAccounts || [] },
        { sheetName: 'Fund_Transfers', rows: erpData.fundTransfers || [] },
        { sheetName: 'Security_Audit_Log', rows: erpData.auditLogs || [] },
      ],
      (fileName, totalRows) => {
        handleLogExport('Master ERP Backup (All 13 Sheets)', 'Excel (.xlsx)', totalRows, fileName);
      }
    );
  };

  // Unauthenticated Portal View
  if (needsAuth || !user) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
        {/* Top Bar Contract */}
        <header className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200">
          <a href="#top" className="text-lg font-bold tracking-tight text-slate-900">
            Mr. Mushroom ERP
          </a>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a href="#modules" className="hover:text-slate-900 transition-colors">
              9 Core Modules
            </a>
            <a href="#exports" className="hover:text-slate-900 transition-colors">
              Universal Excel & Sheets Export
            </a>
          </nav>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsPythonModalOpen(true)}
              className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors whitespace-nowrap cursor-pointer"
            >
              View Python Prompt & .py
            </button>
          </div>
        </header>

        <main className="flex-1 max-w-6xl w-full mx-auto px-6 py-12 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="text-xs font-medium text-emerald-800">
              Private Limited Mushroom Cultivation & Processing Enterprise
            </div>
            <h1
              className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900"
              style={{ textWrap: 'balance' }}
            >
              Mr. Mushroom ERP & Accounts Management System
            </h1>
            <p className="text-base text-slate-600 leading-relaxed max-w-2xl">
              Complete multi-user financial & operational system for cultivation batches, spawn & sawdust stock, multi-channel POS invoicing (80mm Thermal & A4), shareholder equity, and 1-click export of every table to Excel (.xlsx) and Google Sheets (.csv & Live API).
            </p>

            {apiError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-md text-xs text-red-800">
                {apiError}
              </div>
            )}

            <div className="pt-2 flex flex-wrap items-center gap-4">
              {/* Official Sign in with Google Button */}
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={isLoggingIn}
                className="inline-flex items-center gap-3 px-5 py-3 bg-white text-slate-800 font-medium text-sm border border-slate-300 rounded-md shadow-xs hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
              >
                <div className="w-5 h-5">
                  <svg
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 48 48"
                    style={{ display: 'block' }}
                  >
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    ></path>
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    ></path>
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    ></path>
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    ></path>
                    <path fill="none" d="M0 0h48v48H0z"></path>
                  </svg>
                </div>
                <span>{isLoggingIn ? 'Signing in...' : 'Sign in with Google'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsPythonModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-3 text-xs font-semibold text-slate-800 bg-slate-100 border border-slate-300 rounded-md hover:bg-slate-200 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Terminal className="w-4 h-4" />
                <span>Copy Updated Python Prompt & Export Code</span>
              </button>
            </div>

            <div className="pt-4 border-t border-slate-200 grid grid-cols-3 gap-4 text-xs text-slate-600">
              <div>
                <div className="font-mono font-semibold text-slate-900">9 ERP Modules</div>
                <div>Sales, OpEx, Batches, Equity, Payroll & Audit</div>
              </div>
              <div>
                <div className="font-mono font-semibold text-slate-900">1-Click .XLSX & .CSV</div>
                <div>Every single table & financial statement</div>
              </div>
              <div>
                <div className="font-mono font-semibold text-slate-900">Live Google Sheets</div>
                <div>Direct Google Drive spreadsheet creation</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="relative rounded-lg overflow-hidden border border-slate-200 bg-slate-900">
              <img
                src={facilityBannerImg}
                alt="Mr. Mushroom climate-controlled cultivation and processing chamber"
                referrerPolicy="no-referrer"
                className="w-full h-72 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6 text-white">
                <div className="text-sm font-semibold">
                  Savar Mushroom Cultivation & Processing Complex
                </div>
                <div className="text-xs text-slate-300 mt-0.5">
                  PostgreSQL Cloud Database · Google Sheets API Connected
                </div>
              </div>
            </div>
          </div>
        </main>

        <PythonSpecModal isOpen={isPythonModalOpen} onClose={() => setIsPythonModalOpen(false)} />
      </div>
    );
  }

  // Computed KPI Metrics for Dashboard
  const totalSalesNet = (erpData.salesInvoices || []).reduce(
    (s: number, i: any) => s + (i.netPayableBdt || 0),
    0
  );
  const totalCustomerDues = (erpData.salesInvoices || []).reduce(
    (s: number, i: any) => s + (i.dueAmountBdt || 0),
    0
  );
  const totalOpEx = (erpData.operatingExpenses || []).reduce(
    (s: number, e: any) => s + (e.amountBdt || 0),
    0
  );
  const totalCashAndBank = (erpData.bankCashAccounts || []).reduce(
    (s: number, a: any) => s + (a.currentBalanceBdt || 0),
    0
  );
  const lowStockItems = (erpData.inventoryItems || []).filter(
    (i: any) => i.currentStock <= i.reorderLevel
  );
  const totalHarvestKg = (erpData.productionBatches || []).reduce(
    (s: number, b: any) => s + (b.actualYieldKg || 0),
    0
  );

  const dashboardSummaryRows = [
    { Metric: 'Total Multi-Channel Net Sales (BDT)', Value: totalSalesNet, Category: 'Sales & POS' },
    { Metric: 'Total Customer Receivable Dues (BDT)', Value: totalCustomerDues, Category: 'Sales & POS' },
    { Metric: 'Total Operating Expenses OpEx (BDT)', Value: totalOpEx, Category: 'Operating Expenses' },
    { Metric: 'Total Cash, Bank & Mobile Wallets (BDT)', Value: totalCashAndBank, Category: 'Treasury' },
    { Metric: 'Total Harvested Mushroom Yield (kg)', Value: totalHarvestKg, Category: 'Batch Production' },
    { Metric: 'Low Stock Alert SKU Count', Value: lowStockItems.length, Category: 'Inventory' },
  ];

  const sidebarItems: { key: ModuleKey; label: string; icon: React.ReactNode; group: string }[] = [
    { key: 'dashboard', label: '00. Executive Dashboard', icon: <LayoutDashboard className="w-4 h-4" />, group: 'Overview' },
    { key: 'attendance', label: '01. Attendance & Payroll', icon: <Users className="w-4 h-4" />, group: 'Operations' },
    { key: 'inventory', label: '02. Inventory & Batches', icon: <Package className="w-4 h-4" />, group: 'Operations' },
    { key: 'sales', label: '03. Sales, POS & Invoicing', icon: <ShoppingCart className="w-4 h-4" />, group: 'Operations' },
    { key: 'expenses', label: '04. Operating Expenses', icon: <Receipt className="w-4 h-4" />, group: 'Finance' },
    { key: 'equity', label: '05. Investment & Equity', icon: <PieChart className="w-4 h-4" />, group: 'Finance' },
    { key: 'loans', label: '06. Loans & Liabilities', icon: <Landmark className="w-4 h-4" />, group: 'Finance' },
    { key: 'banking', label: '07. Banking & Cash', icon: <Wallet className="w-4 h-4" />, group: 'Finance' },
    { key: 'statements', label: '08. P&L & Balance Sheet', icon: <FileBarChart className="w-4 h-4" />, group: 'Corporate' },
    { key: 'audit', label: '09. Audit Trail & RBAC', icon: <ShieldAlert className="w-4 h-4" />, group: 'Corporate' },
  ];

  const activeUserRole = erpData.currentUser?.role || 'Admin';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="no-print flex items-center justify-between px-6 py-3.5 bg-white border-b border-slate-200 sticky top-0 z-30">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#dashboard"
          onClick={(e) => {
            e.preventDefault();
            setActiveModule('dashboard');
          }}
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap"
        >
          Mr. Mushroom ERP
        </a>

        {/* Zone 2: 5 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-600">
          <button
            type="button"
            onClick={() => setActiveModule('dashboard')}
            className={`hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap ${
              activeModule === 'dashboard' ? 'text-slate-900 underline underline-offset-4 font-semibold' : ''
            }`}
          >
            Dashboard
          </button>
          <button
            type="button"
            onClick={() => setActiveModule('sales')}
            className={`hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap ${
              activeModule === 'sales' ? 'text-slate-900 underline underline-offset-4 font-semibold' : ''
            }`}
          >
            Sales & POS
          </button>
          <button
            type="button"
            onClick={() => setActiveModule('inventory')}
            className={`hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap ${
              activeModule === 'inventory' ? 'text-slate-900 underline underline-offset-4 font-semibold' : ''
            }`}
          >
            Inventory & Batches
          </button>
          <button
            type="button"
            onClick={() => setActiveModule('statements')}
            className={`hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap ${
              activeModule === 'statements' ? 'text-slate-900 underline underline-offset-4 font-semibold' : ''
            }`}
          >
            P&L & Balance Sheet
          </button>
          <button
            type="button"
            onClick={() => setActiveModule('audit')}
            className={`hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap ${
              activeModule === 'audit' ? 'text-slate-900 underline underline-offset-4 font-semibold' : ''
            }`}
          >
            Audit Trail
          </button>
        </nav>

        {/* Zone 3: 2 primary actions */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleMasterWorkbookExport}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-600 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Download all 13 ERP tables in one multi-sheet Excel (.xlsx) workbook"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export All Modules (.xlsx)</span>
          </button>

          <button
            type="button"
            onClick={() => setIsPythonModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="View finalized Python ERP prompt and openpyxl/pandas code"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Python Prompt</span>
          </button>
        </div>
      </header>

      {/* Workspace Body: 260px Sidebar + Main Content Viewport */}
      <div className="flex-1 flex flex-col md:flex-row max-w-[1440px] w-full mx-auto">
        {/* Sidebar Navigation */}
        <aside className="no-print w-full md:w-64 bg-white border-b md:border-b-0 md:border-r border-slate-200 p-4 flex flex-col justify-between shrink-0">
          <div className="space-y-1">
            {sidebarItems.map((item) => {
              const isActive = activeModule === item.key;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => setActiveModule(item.key)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer text-left whitespace-nowrap ${
                    isActive
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {item.icon}
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Account Profile Footer */}
          <div className="mt-6 pt-4 border-t border-slate-200 space-y-3">
            <div className="flex items-center gap-2.5">
              <img
                src={directorAvatarImg}
                alt="Managing Director avatar"
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full object-cover border border-slate-300 shrink-0"
              />
              <div className="min-w-0 flex-1">
                <div className="text-xs font-semibold text-slate-900 truncate">
                  {user.displayName || erpData.currentUser?.name}
                </div>
                <div className="text-[11px] text-slate-500 truncate">
                  {activeUserRole} · {user.email}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleSignOut}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </aside>

        {/* Main Viewport */}
        <main className="flex-1 p-6 space-y-6 min-w-0">
          {apiError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-md text-xs text-red-800 flex items-center justify-between">
              <span>{apiError}</span>
              <button
                type="button"
                onClick={() => setApiError(null)}
                className="font-semibold underline ml-4 cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          )}

          {loadingData && (
            <div className="text-xs font-mono text-slate-500">Synchronizing ERP ledger...</div>
          )}

          {activeModule === 'dashboard' && (
            <div className="space-y-6">
              {/* Facility & Product Overview Banner */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-8 relative rounded-lg overflow-hidden border border-slate-200 bg-slate-900 min-h-[190px]">
                  <img
                    src={facilityBannerImg}
                    alt="Mr. Mushroom cultivation facility"
                    referrerPolicy="no-referrer"
                    className="w-full h-48 object-cover opacity-85"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-6 flex flex-col justify-end text-white">
                    <div className="text-xs text-emerald-300 font-medium">
                      Mr. Mushroom Agro & Biotech Pvt. Ltd. · Savar Plant
                    </div>
                    <h2 className="text-xl font-bold tracking-tight mt-0.5">
                      Real-Time ERP & Universal Data Export Command Center
                    </h2>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-200 mt-1">
                      <span>Every module exports to Excel (.xlsx)</span>
                      <span aria-hidden="true">·</span>
                      <span>Google Sheets Ready (.csv)</span>
                      <span aria-hidden="true">·</span>
                      <span>Direct Google Drive Sheets Sync</span>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-4 bg-white border border-slate-200 rounded-lg p-4 flex flex-col justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={productPowderImg}
                      alt="Mr. Mushroom Pure Oyster Powder"
                      referrerPolicy="no-referrer"
                      className="w-20 h-20 rounded-md object-cover border border-slate-200 shrink-0"
                    />
                    <div>
                      <div className="text-xs font-semibold text-slate-900">
                        Batch & Processed Line
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        Total Harvested:{' '}
                        <span className="font-mono font-semibold text-slate-900">
                          {totalHarvestKg} kg
                        </span>
                      </div>
                      <div className="text-xs text-slate-500">
                        Active Batches:{' '}
                        <span className="font-mono font-semibold text-emerald-700">
                          {(erpData.productionBatches || []).length}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="pt-3 mt-3 border-t border-slate-200 flex items-center justify-between text-xs">
                    <span className="text-slate-600">Master Multi-Tab Backup:</span>
                    <button
                      type="button"
                      onClick={handleMasterWorkbookExport}
                      className="font-semibold text-emerald-700 hover:underline cursor-pointer"
                    >
                      Download 13-Sheet .XLSX
                    </button>
                  </div>
                </div>
              </div>

              {/* Real-Time KPI Strip */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white border border-slate-200 rounded-lg p-4">
                  <div className="text-xs text-slate-500">Net Sales Revenue</div>
                  <div className="text-xl font-mono font-bold tabular-nums text-slate-900 mt-1">
                    ৳{totalSalesNet.toLocaleString('en-BD')}
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Receivable Dues:{' '}
                    <span className="font-mono text-red-700 font-semibold">
                      ৳{totalCustomerDues.toLocaleString('en-BD')}
                    </span>
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-lg p-4">
                  <div className="text-xs text-slate-500">Operating Expenses (OpEx)</div>
                  <div className="text-xl font-mono font-bold tabular-nums text-slate-900 mt-1">
                    ৳{totalOpEx.toLocaleString('en-BD')}
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    {(erpData.operatingExpenses || []).length} posted vouchers
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-lg p-4">
                  <div className="text-xs text-slate-500">Cash, Bank & Mobile Wallets</div>
                  <div className="text-xl font-mono font-bold tabular-nums text-emerald-700 mt-1">
                    ৳{totalCashAndBank.toLocaleString('en-BD')}
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Vault · City Bank · DBBL · Bkash · Nagad
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-lg p-4">
                  <div className="text-xs text-slate-500">Inventory & Reorder Alerts</div>
                  <div className="text-xl font-mono font-bold tabular-nums text-amber-700 mt-1">
                    {lowStockItems.length} Low-Stock SKUs
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Out of {(erpData.inventoryItems || []).length} tracked items
                  </div>
                </div>
              </div>

              {/* Executive KPI Table with Universal Export */}
              <section className="bg-white border border-slate-200 rounded-lg p-6">
                <UniversalExportBar
                  title="Executive Summary KPI Ledger"
                  moduleName="Dashboard Overview"
                  fileNamePrefix="Mr_Mushroom_Executive_Summary"
                  sheetName="Executive_KPIs"
                  rows={dashboardSummaryRows}
                  onLogExport={handleLogExport}
                />

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-4">
                  <div>
                    <h4 className="text-xs font-semibold text-slate-800 mb-2">
                      Recent Multi-Channel Sales Invoices
                    </h4>
                    <div className="overflow-x-auto border border-slate-200 rounded-md">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-500">
                            <th className="py-2 px-3 font-medium">Invoice</th>
                            <th className="py-2 px-3 font-medium">Customer</th>
                            <th className="py-2 px-3 font-medium text-right">Net (৳)</th>
                            <th className="py-2 px-3 font-medium text-right">Print</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {(erpData.salesInvoices || []).slice(0, 4).map((inv: SalesInvoiceRecord) => (
                            <tr key={inv.id}>
                              <td className="py-2 px-3 font-mono font-medium">{inv.invoiceNo}</td>
                              <td className="py-2 px-3 truncate max-w-[140px]">{inv.customerName}</td>
                              <td className="py-2 px-3 text-right font-mono tabular-nums font-semibold">
                                ৳{inv.netPayableBdt.toLocaleString('en-BD')}
                              </td>
                              <td className="py-2 px-3 text-right">
                                <button
                                  type="button"
                                  onClick={() => setInvoiceModalState({ invoice: inv, format: 'a4' })}
                                  className="text-emerald-700 hover:underline font-medium cursor-pointer"
                                >
                                  A4 / 80mm
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-xs font-semibold text-slate-800 mb-2">
                      Low Stock Raw Materials & Spawn Alerts
                    </h4>
                    <div className="overflow-x-auto border border-slate-200 rounded-md">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-500">
                            <th className="py-2 px-3 font-medium">SKU & Item</th>
                            <th className="py-2 px-3 font-medium text-right">Stock</th>
                            <th className="py-2 px-3 font-medium text-right">Reorder At</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {lowStockItems.map((item: any) => (
                            <tr key={item.id}>
                              <td className="py-2 px-3">
                                <div className="font-medium text-slate-900 flex items-center gap-1.5">
                                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                  <span>{item.name}</span>
                                </div>
                              </td>
                              <td className="py-2 px-3 text-right font-mono tabular-nums font-bold text-amber-700">
                                {item.currentStock} {item.unit}
                              </td>
                              <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-500">
                                {item.reorderLevel} {item.unit}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          )}

          {(activeModule === 'attendance' ||
            activeModule === 'inventory' ||
            activeModule === 'sales') && (
            <OperationsModules
              activeSubTab={activeModule}
              data={erpData}
              userRole={activeUserRole}
              onApiPost={handleApiPost}
              onApiPut={handleApiPut}
              onApiDelete={handleApiDelete}
              onOpenEditModal={(moduleKey, record) => setEditModalState({ moduleKey, record })}
              onLogExport={handleLogExport}
              onOpenInvoiceModal={(inv, format) => setInvoiceModalState({ invoice: inv, format })}
            />
          )}

          {(activeModule === 'expenses' ||
            activeModule === 'equity' ||
            activeModule === 'loans' ||
            activeModule === 'banking' ||
            activeModule === 'statements' ||
            activeModule === 'audit') && (
            <FinanceModules
              activeSubTab={activeModule}
              data={erpData}
              userRole={activeUserRole}
              onApiPost={handleApiPost}
              onApiDelete={handleApiDelete}
              onOpenEditModal={(moduleKey, record) => setEditModalState({ moduleKey, record })}
              onSwitchRole={(role) => handleApiPost('/api/erp/role', { role })}
              onLogExport={handleLogExport}
            />
          )}
        </main>
      </div>

      {/* Universal Edit Record Modal across ALL sections */}
      <EditRecordModal
        moduleKey={editModalState.moduleKey}
        record={editModalState.record}
        onClose={() => setEditModalState({ moduleKey: null, record: null })}
        onSave={async (moduleKey, id, updatedData) => {
          await handleApiPut(`/api/erp/${moduleKey}/${id}`, updatedData);
        }}
      />

      {/* POS Thermal 80mm & Standard A4 Invoice Print Modal */}
      <InvoicePrintModal
        invoice={invoiceModalState.invoice}
        initialFormat={invoiceModalState.format}
        onClose={() => setInvoiceModalState({ invoice: null, format: 'a4' })}
      />

      {/* Python ERP Prompt & Universal Export Reference Modal */}
      <PythonSpecModal isOpen={isPythonModalOpen} onClose={() => setIsPythonModalOpen(false)} />
    </div>
  );
}
