import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { getWorkspaceAccessToken, googleSignIn } from '../lib/firebase.ts';

export interface ExportColumn<T = any> {
  key: keyof T | string;
  header: string;
  format?: (val: any, row: T) => string | number;
}

function getDateStamp(): string {
  return new Date().toISOString().slice(0, 10);
}

export function normalizeRowsForExport<T>(
  rows: T[],
  columns?: ExportColumn<T>[]
): Record<string, string | number>[] {
  if (!rows || rows.length === 0) {
    if (columns && columns.length > 0) {
      const emptyRow: Record<string, string | number> = {};
      columns.forEach((col) => {
        emptyRow[col.header] = '';
      });
      return [emptyRow];
    }
    return [{ Note: 'No records available' }];
  }

  if (!columns || columns.length === 0) {
    return rows.map((r: any) => {
      const clean: Record<string, string | number> = {};
      Object.keys(r).forEach((k) => {
        if (k !== 'itemsJson') {
          const val = r[k];
          clean[k] = typeof val === 'object' && val !== null ? JSON.stringify(val) : val ?? '';
        }
      });
      return clean;
    });
  }

  return rows.map((row: any) => {
    const formatted: Record<string, string | number> = {};
    columns.forEach((col) => {
      const rawVal = row[col.key as string];
      formatted[col.header] = col.format ? col.format(rawVal, row) : rawVal ?? '';
    });
    return formatted;
  });
}

export function exportToExcel<T>(
  rows: T[],
  fileNamePrefix: string,
  sheetName: string = 'Sheet1',
  columns?: ExportColumn<T>[],
  onAuditLog?: (fileName: string, count: number) => void
) {
  const cleanRows = normalizeRowsForExport(rows, columns);
  const worksheet = XLSX.utils.json_to_sheet(cleanRows);

  const headers = Object.keys(cleanRows[0] || {});
  worksheet['!cols'] = headers.map((header) => {
    const maxCellLen = cleanRows.reduce((max, row) => {
      const cellStr = String(row[header] ?? '');
      return Math.max(max, cellStr.length);
    }, header.length);
    return { wch: Math.min(Math.max(maxCellLen + 3, 12), 48) };
  });

  const workbook = XLSX.utils.book_new();
  const safeSheetName = sheetName.replace(/[\\/?*[\]]/g, '').slice(0, 31) || 'Data';
  XLSX.utils.book_append_sheet(workbook, worksheet, safeSheetName);

  const fileName = `${fileNamePrefix}_${getDateStamp()}.xlsx`;
  XLSX.writeFile(workbook, fileName);

  if (onAuditLog) {
    onAuditLog(fileName, rows.length);
  }
}

export function exportToGoogleSheetsCsv<T>(
  rows: T[],
  fileNamePrefix: string,
  columns?: ExportColumn<T>[],
  onAuditLog?: (fileName: string, count: number) => void
) {
  const cleanRows = normalizeRowsForExport(rows, columns);
  const headers = Object.keys(cleanRows[0] || {});

  const escapeCsvCell = (val: any): string => {
    if (val === null || val === undefined) return '';
    const str = String(val).replace(/\r?\n/g, ' ');
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const csvLines = [
    headers.map(escapeCsvCell).join(','),
    ...cleanRows.map((row) => headers.map((h) => escapeCsvCell(row[h])).join(',')),
  ];

  const csvContent = '\uFEFF' + csvLines.join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const fileName = `${fileNamePrefix}_GoogleSheets_${getDateStamp()}.csv`;
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  if (onAuditLog) {
    onAuditLog(fileName, rows.length);
  }
}

/**
 * Synchronously injects printable markup into #mr-mushroom-print-portal and calls window.print()
 * within the same user gesture so Chrome/Edge/Safari print preview never fails or loses activation.
 */
export function triggerIframePrint(htmlDocumentString: string, fallbackPdfDownload?: () => void) {
  try {
    let portal = document.getElementById('mr-mushroom-print-portal');
    if (!portal) {
      portal = document.createElement('div');
      portal.id = 'mr-mushroom-print-portal';
      document.body.appendChild(portal);
    }

    // Extract <style> and <body> contents if a full HTML document string was passed
    const styleMatches = htmlDocumentString.match(/<style[^>]*>([\s\S]*?)<\/style>/gi) || [];
    const bodyMatch = htmlDocumentString.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    const bodyContent = bodyMatch ? bodyMatch[1] : htmlDocumentString;

    // Sanitize @page size rules that can cause Chrome Print Preview to fail on thermal sizes
    const cleanedStyles = styleMatches
      .map((s) => s.replace(/size:\s*80mm\s+auto\s*;?/gi, ''))
      .join('\n');

    portal.innerHTML = `${cleanedStyles}<div class="mr-print-wrapper">${bodyContent}</div>`;
    document.body.classList.add('mr-printing-active');

    const cleanup = () => {
      document.body.classList.remove('mr-printing-active');
      window.removeEventListener('afterprint', cleanup);
    };
    window.addEventListener('afterprint', cleanup);

    window.print();

    // Fallback cleanup in case afterprint does not fire in some embedded webviews
    setTimeout(() => {
      document.body.classList.remove('mr-printing-active');
    }, 2500);
  } catch {
    document.body.classList.remove('mr-printing-active');
    if (fallbackPdfDownload) fallbackPdfDownload();
  }
}

/**
 * Universal PDF Download for any ERP Data Table
 */
export function exportTableToPdf<T>(
  rows: T[],
  title: string,
  moduleName: string,
  fileNamePrefix: string,
  columns?: ExportColumn<T>[],
  onAuditLog?: (fileName: string, count: number) => void
) {
  const cleanRows = normalizeRowsForExport(rows, columns);
  const headers = Object.keys(cleanRows[0] || {});
  const bodyRows = cleanRows.map((r) => headers.map((h) => String(r[h] ?? '')));

  const orientation = headers.length > 6 ? 'landscape' : 'portrait';
  const doc = new jsPDF({ orientation, unit: 'pt', format: 'a4' });

  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42);
  doc.text('Mr. Mushroom Agro & Biotech Ltd.', 40, 36);

  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105);
  doc.text(`${title} (${moduleName})`, 40, 52);

  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(
    `Generated: ${getDateStamp()} | Total Records: ${rows.length} | Savar Mushroom Complex, Dhaka`,
    40,
    66
  );

  autoTable(doc, {
    startY: 78,
    head: [headers],
    body: bodyRows,
    styles: {
      fontSize: 7.5,
      cellPadding: 4,
      textColor: [15, 23, 42],
      lineColor: [226, 232, 240],
      lineWidth: 0.5,
    },
    headStyles: {
      fillColor: [15, 23, 42],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    margin: { left: 40, right: 40, bottom: 40 },
  });

  const fileName = `${fileNamePrefix}_${getDateStamp()}.pdf`;
  doc.save(fileName);

  if (onAuditLog) {
    onAuditLog(fileName, rows.length);
  }
}

/**
 * Universal Print Table Report for any ERP Data Table
 */
export function printDataTable<T>(
  rows: T[],
  title: string,
  moduleName: string,
  fileNamePrefix: string,
  columns?: ExportColumn<T>[],
  onAuditLog?: (fileName: string, count: number) => void
) {
  const cleanRows = normalizeRowsForExport(rows, columns);
  const headers = Object.keys(cleanRows[0] || {});

  const escapeHtml = (val: any) =>
    String(val ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

  const theadHtml = headers.map((h) => `<th>${escapeHtml(h)}</th>`).join('');
  const tbodyHtml = cleanRows
    .map(
      (row) =>
        `<tr>${headers.map((h) => `<td>${escapeHtml(row[h])}</td>`).join('')}</tr>`
    )
    .join('');

  const htmlString = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(title)} - Mr. Mushroom ERP</title>
  <style>
    @page { size: auto; margin: 12mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      color: #0f172a;
      margin: 0;
      padding: 0;
      font-size: 11px;
    }
    .header {
      border-bottom: 2px solid #0f172a;
      padding-bottom: 10px;
      margin-bottom: 14px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
    }
    .company { font-size: 16px; font-weight: 700; }
    .sub { font-size: 11px; color: #475569; margin-top: 2px; }
    .report-title { font-size: 13px; font-weight: 700; margin-top: 6px; color: #047857; }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 8px;
    }
    th, td {
      border: 1px solid #cbd5e1;
      padding: 6px 8px;
      text-align: left;
      font-size: 10px;
      word-break: break-word;
    }
    th {
      background-color: #0f172a;
      color: #ffffff;
      font-weight: 600;
    }
    tr:nth-child(even) td {
      background-color: #f8fafc;
    }
    .footer {
      margin-top: 24px;
      padding-top: 10px;
      border-top: 1px solid #cbd5e1;
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      color: #64748b;
    }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="company">Mr. Mushroom Agro & Biotech Ltd.</div>
      <div class="sub">Savar Mushroom Cultivation & Processing Complex, Dhaka-1340, Bangladesh</div>
      <div class="report-title">${escapeHtml(title)}</div>
    </div>
    <div style="text-align: right;">
      <div class="sub">Module: <strong>${escapeHtml(moduleName)}</strong></div>
      <div class="sub">Date: <strong>${getDateStamp()}</strong></div>
      <div class="sub">Records: <strong>${rows.length}</strong></div>
    </div>
  </div>
  <table>
    <thead><tr>${theadHtml}</tr></thead>
    <tbody>${tbodyHtml}</tbody>
  </table>
  <div class="footer">
    <div>Prepared By: Mr. Mushroom ERP System</div>
    <div>Authorized Signatory & Company Seal</div>
  </div>
</body>
</html>`;

  triggerIframePrint(htmlString, () => {
    exportTableToPdf(rows, title, moduleName, fileNamePrefix, columns, onAuditLog);
  });

  if (onAuditLog) {
    onAuditLog(`${fileNamePrefix}_Print`, rows.length);
  }
}

export function exportMasterErpWorkbook(
  allSheets: { sheetName: string; rows: Record<string, any>[] }[],
  onAuditLog?: (fileName: string, totalRows: number) => void
) {
  const workbook = XLSX.utils.book_new();
  let totalRows = 0;

  allSheets.forEach(({ sheetName, rows }) => {
    const cleanRows = normalizeRowsForExport(rows);
    totalRows += rows.length;
    const worksheet = XLSX.utils.json_to_sheet(cleanRows);
    const headers = Object.keys(cleanRows[0] || {});
    worksheet['!cols'] = headers.map((header) => {
      const maxCellLen = cleanRows.reduce((max, row) => {
        const cellStr = String(row[header] ?? '');
        return Math.max(max, cellStr.length);
      }, header.length);
      return { wch: Math.min(Math.max(maxCellLen + 3, 12), 45) };
    });

    const safeName = sheetName.replace(/[\\/?*[\]]/g, '').slice(0, 31);
    XLSX.utils.book_append_sheet(workbook, worksheet, safeName);
  });

  const fileName = `Mr_Mushroom_Master_ERP_All_Modules_${getDateStamp()}.xlsx`;
  XLSX.writeFile(workbook, fileName);

  if (onAuditLog) {
    onAuditLog(fileName, totalRows);
  }
}

/**
 * Creates a live Google Spreadsheet in the user's Google Drive using the Google Sheets v4 API
 */
export async function createLiveGoogleSpreadsheet<T>(
  rows: T[],
  titlePrefix: string,
  sheetTabName: string,
  columns?: ExportColumn<T>[],
  onAuditLog?: (spreadsheetUrl: string, count: number) => void
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  let token = getWorkspaceAccessToken();
  if (!token) {
    const signInResult = await googleSignIn();
    token = signInResult?.accessToken || null;
  }
  if (!token) {
    throw new Error('Google Workspace access token unavailable. Please sign in with Google again.');
  }

  const cleanRows = normalizeRowsForExport(rows, columns);
  const headers = Object.keys(cleanRows[0] || {});
  const valuesMatrix = [
    headers,
    ...cleanRows.map((r) => headers.map((h) => String(r[h] ?? ''))),
  ];

  const safeTab = sheetTabName.replace(/[\\/?*[\]:]/g, '').slice(0, 30) || 'ERP_Data';
  const fullTitle = `${titlePrefix} (${getDateStamp()})`;

  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: { title: fullTitle },
      sheets: [
        {
          properties: {
            title: safeTab,
            gridProperties: { frozenRowCount: 1 },
          },
        },
      ],
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`Google Sheets API error (${createRes.status}): ${errText}`);
  }

  const createdSheet = await createRes.json();
  const spreadsheetId = createdSheet.spreadsheetId;
  const spreadsheetUrl = createdSheet.spreadsheetUrl;

  const range = `'${safeTab}'!A1`;
  const updateRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(
      range
    )}?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        range,
        majorDimension: 'ROWS',
        values: valuesMatrix,
      }),
    }
  );

  if (!updateRes.ok) {
    const errText = await updateRes.text();
    throw new Error(`Failed to write rows to Google Sheet: ${errText}`);
  }

  if (onAuditLog) {
    onAuditLog(spreadsheetUrl, rows.length);
  }

  return { spreadsheetId, spreadsheetUrl };
}
