import { db } from './index.ts';
import {
  users,
  employees,
  attendanceLogs,
  payrollRecords,
  inventoryItems,
  productionBatches,
  wastageLogs,
  salesInvoices,
  operatingExpenses,
  equityRecords,
  loansLiabilities,
  bankCashAccounts,
  fundTransfers,
  auditLogs,
} from './schema.ts';
import { desc, eq } from 'drizzle-orm';

export async function logAuditAction(params: {
  userEmail: string;
  userName: string;
  userRole: string;
  action: string;
  module: string;
  entityRef: string;
  details: string;
}) {
  try {
    const nowStr = new Date().toISOString().replace('T', ' ').slice(0, 19);
    const result = await db
      .insert(auditLogs)
      .values({
        timestamp: nowStr,
        userEmail: params.userEmail,
        userName: params.userName,
        userRole: params.userRole,
        action: params.action,
        module: params.module,
        entityRef: params.entityRef,
        details: params.details,
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error('Failed to write audit log:', error);
    throw new Error('Failed to record audit trail entry.', { cause: error });
  }
}

export async function getAllErpData() {
  try {
    const [
      empList,
      attList,
      payList,
      invList,
      batchList,
      wasteList,
      salesList,
      expenseList,
      equityList,
      loanList,
      accountList,
      transferList,
      auditList,
    ] = await Promise.all([
      db.select().from(employees).orderBy(desc(employees.id)),
      db.select().from(attendanceLogs).orderBy(desc(attendanceLogs.id)),
      db.select().from(payrollRecords).orderBy(desc(payrollRecords.id)),
      db.select().from(inventoryItems).orderBy(desc(inventoryItems.id)),
      db.select().from(productionBatches).orderBy(desc(productionBatches.id)),
      db.select().from(wastageLogs).orderBy(desc(wastageLogs.id)),
      db.select().from(salesInvoices).orderBy(desc(salesInvoices.id)),
      db.select().from(operatingExpenses).orderBy(desc(operatingExpenses.id)),
      db.select().from(equityRecords).orderBy(desc(equityRecords.id)),
      db.select().from(loansLiabilities).orderBy(desc(loansLiabilities.id)),
      db.select().from(bankCashAccounts).orderBy(desc(bankCashAccounts.id)),
      db.select().from(fundTransfers).orderBy(desc(fundTransfers.id)),
      db.select().from(auditLogs).orderBy(desc(auditLogs.id)),
    ]);

    return {
      employees: empList,
      attendanceLogs: attList,
      payrollRecords: payList,
      inventoryItems: invList,
      productionBatches: batchList,
      wastageLogs: wasteList,
      salesInvoices: salesList,
      operatingExpenses: expenseList,
      equityRecords: equityList,
      loansLiabilities: loanList,
      bankCashAccounts: accountList,
      fundTransfers: transferList,
      auditLogs: auditList,
    };
  } catch (error) {
    console.error('Database query failed in getAllErpData:', error);
    throw new Error('Failed to load ERP data from database. Please try again later.', {
      cause: error,
    });
  }
}

// Module 1 Mutations
export async function createAttendanceLog(data: typeof attendanceLogs.$inferInsert) {
  try {
    const res = await db.insert(attendanceLogs).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createAttendanceLog failed:', error);
    throw new Error('Failed to save attendance log.', { cause: error });
  }
}

export async function createEmployee(data: typeof employees.$inferInsert) {
  try {
    const res = await db.insert(employees).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createEmployee failed:', error);
    throw new Error('Failed to create employee record.', { cause: error });
  }
}

export async function createPayrollRecord(data: typeof payrollRecords.$inferInsert) {
  try {
    const res = await db.insert(payrollRecords).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createPayrollRecord failed:', error);
    throw new Error('Failed to generate payroll record.', { cause: error });
  }
}

// Module 2 Mutations
export async function createInventoryItem(data: typeof inventoryItems.$inferInsert) {
  try {
    const res = await db.insert(inventoryItems).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createInventoryItem failed:', error);
    throw new Error('Failed to create inventory item.', { cause: error });
  }
}

export async function updateInventoryStock(
  id: number,
  currentStock: number,
  unitCost: number,
  sellingPrice: number
) {
  try {
    const res = await db
      .update(inventoryItems)
      .set({ currentStock, unitCost, sellingPrice, updatedAt: new Date() })
      .where(eq(inventoryItems.id, id))
      .returning();
    return res[0];
  } catch (error) {
    console.error('updateInventoryStock failed:', error);
    throw new Error('Failed to update inventory stock.', { cause: error });
  }
}

export async function createProductionBatch(data: typeof productionBatches.$inferInsert) {
  try {
    const res = await db.insert(productionBatches).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createProductionBatch failed:', error);
    throw new Error('Failed to create production batch.', { cause: error });
  }
}

export async function createWastageLog(data: typeof wastageLogs.$inferInsert) {
  try {
    const qtyLost = Number(data.quantity) || 0;
    if (qtyLost > 0 && data.itemName) {
      const allInv = await db.select().from(inventoryItems);
      const targetName = data.itemName.trim().toLowerCase();
      const matched = allInv.find(
        (i) =>
          i.name.trim().toLowerCase() === targetName ||
          i.sku.trim().toLowerCase() === targetName
      );
      if (matched) {
        const nextStock = Math.max(0, Number((matched.currentStock - qtyLost).toFixed(2)));
        await db
          .update(inventoryItems)
          .set({ currentStock: nextStock, updatedAt: new Date() })
          .where(eq(inventoryItems.id, matched.id));
      }
    }
    const res = await db.insert(wastageLogs).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createWastageLog failed:', error);
    throw new Error('Failed to record wastage log.', { cause: error });
  }
}

// Module 3 Mutations
export async function createSalesInvoice(data: typeof salesInvoices.$inferInsert) {
  try {
    // 1. Parse sold line items and deduct stock from inventoryItems
    let soldItems: { sku?: string; name?: string; qty?: number }[] = [];
    try {
      soldItems = JSON.parse(data.itemsJson || '[]');
    } catch {
      soldItems = [];
    }

    if (soldItems.length > 0) {
      const allInventory = await db.select().from(inventoryItems);
      for (const line of soldItems) {
        const qtyToDeduct = Number(line.qty) || 0;
        if (qtyToDeduct <= 0) continue;

        const targetSku = String(line.sku || '').trim().toLowerCase();
        const targetName = String(line.name || '').trim().toLowerCase();

        const matchedItem = allInventory.find(
          (inv) =>
            (targetSku && inv.sku.trim().toLowerCase() === targetSku) ||
            (targetName && inv.name.trim().toLowerCase() === targetName)
        );

        if (matchedItem) {
          const updatedStock = Math.max(
            0,
            Number((matchedItem.currentStock - qtyToDeduct).toFixed(2))
          );
          await db
            .update(inventoryItems)
            .set({
              currentStock: updatedStock,
              updatedAt: new Date(),
            })
            .where(eq(inventoryItems.id, matchedItem.id));
          matchedItem.currentStock = updatedStock;
        }
      }
    }

    // 2. Credit corresponding Bank / Cash / Mobile Wallet account if paidAmountBdt > 0
    const paidNow = Number(data.paidAmountBdt) || 0;
    if (paidNow > 0 && data.paymentMethod && data.paymentMethod !== 'Credit') {
      const allAccounts = await db.select().from(bankCashAccounts);
      const methodLower = data.paymentMethod.toLowerCase();
      const matchedAcc = allAccounts.find((acc) => {
        const nameLower = acc.accountName.toLowerCase();
        const typeLower = acc.accountType.toLowerCase();
        if (methodLower === 'cash') return typeLower === 'cash' || nameLower.includes('cash');
        if (methodLower === 'bkash') return nameLower.includes('bkash');
        if (methodLower === 'nagad') return nameLower.includes('nagad');
        if (methodLower === 'bank') return typeLower === 'bank';
        return false;
      });
      if (matchedAcc) {
        await db
          .update(bankCashAccounts)
          .set({
            currentBalanceBdt: Number((matchedAcc.currentBalanceBdt + paidNow).toFixed(2)),
            lastReconciledDate: data.date,
            updatedAt: new Date(),
          })
          .where(eq(bankCashAccounts.id, matchedAcc.id));
      }
    }

    const res = await db.insert(salesInvoices).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createSalesInvoice failed:', error);
    throw new Error('Failed to create sales invoice.', { cause: error });
  }
}

export async function recordDueCollection(id: number, additionalPaid: number) {
  try {
    const existing = await db.select().from(salesInvoices).where(eq(salesInvoices.id, id));
    if (!existing.length) {
      throw new Error('Invoice not found.');
    }
    const inv = existing[0];
    const newPaid = Math.min(inv.netPayableBdt, inv.paidAmountBdt + additionalPaid);
    const newDue = Math.max(0, Number((inv.netPayableBdt - newPaid).toFixed(2)));
    const newStatus = newDue <= 0 ? 'Paid' : 'Partial';

    const res = await db
      .update(salesInvoices)
      .set({
        paidAmountBdt: newPaid,
        dueAmountBdt: newDue,
        status: newStatus,
      })
      .where(eq(salesInvoices.id, id))
      .returning();
    return res[0];
  } catch (error) {
    console.error('recordDueCollection failed:', error);
    throw new Error('Failed to update invoice payment.', { cause: error });
  }
}

// Module 4 Mutations
export async function createOperatingExpense(data: typeof operatingExpenses.$inferInsert) {
  try {
    const res = await db.insert(operatingExpenses).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createOperatingExpense failed:', error);
    throw new Error('Failed to save operating expense.', { cause: error });
  }
}

// Module 5 Mutations
export async function createEquityRecord(data: typeof equityRecords.$inferInsert) {
  try {
    const res = await db.insert(equityRecords).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createEquityRecord failed:', error);
    throw new Error('Failed to save shareholder equity record.', { cause: error });
  }
}

// Module 6 Mutations
export async function createLoanLiability(data: typeof loansLiabilities.$inferInsert) {
  try {
    const res = await db.insert(loansLiabilities).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createLoanLiability failed:', error);
    throw new Error('Failed to save loan/liability record.', { cause: error });
  }
}

export async function payLoanInstallment(id: number, paymentAmount: number) {
  try {
    const existing = await db.select().from(loansLiabilities).where(eq(loansLiabilities.id, id));
    if (!existing.length) {
      throw new Error('Liability record not found.');
    }
    const item = existing[0];
    const newPaid = item.totalPaidBdt + paymentAmount;
    const newOutstanding = Math.max(
      0,
      Number((item.outstandingBalanceBdt - paymentAmount).toFixed(2))
    );
    const newStatus = newOutstanding <= 0 ? 'Settled' : 'Active';

    const res = await db
      .update(loansLiabilities)
      .set({
        totalPaidBdt: newPaid,
        outstandingBalanceBdt: newOutstanding,
        status: newStatus,
      })
      .where(eq(loansLiabilities.id, id))
      .returning();
    return res[0];
  } catch (error) {
    console.error('payLoanInstallment failed:', error);
    throw new Error('Failed to record loan installment payment.', { cause: error });
  }
}

// Module 7 Mutations
export async function createBankCashAccount(data: typeof bankCashAccounts.$inferInsert) {
  try {
    const res = await db.insert(bankCashAccounts).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('createBankCashAccount failed:', error);
    throw new Error('Failed to create bank/cash account.', { cause: error });
  }
}

export async function executeFundTransfer(data: typeof fundTransfers.$inferInsert) {
  try {
    const accounts = await db.select().from(bankCashAccounts);
    const fromAcc = accounts.find((a) => a.accountName === data.fromAccount);
    const toAcc = accounts.find((a) => a.accountName === data.toAccount);

    if (fromAcc) {
      await db
        .update(bankCashAccounts)
        .set({
          currentBalanceBdt: Number(
            (fromAcc.currentBalanceBdt - data.amountBdt - (data.transferFeeBdt || 0)).toFixed(2)
          ),
          lastReconciledDate: data.date,
          updatedAt: new Date(),
        })
        .where(eq(bankCashAccounts.id, fromAcc.id));
    }

    if (toAcc) {
      await db
        .update(bankCashAccounts)
        .set({
          currentBalanceBdt: Number((toAcc.currentBalanceBdt + data.amountBdt).toFixed(2)),
          lastReconciledDate: data.date,
          updatedAt: new Date(),
        })
        .where(eq(bankCashAccounts.id, toAcc.id));
    }

    const res = await db.insert(fundTransfers).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('executeFundTransfer failed:', error);
    throw new Error('Failed to execute internal fund transfer.', { cause: error });
  }
}

// Module 9: Create System Officer User
export async function createSystemOfficerUser(data: {
  name: string;
  email: string;
  role: string;
}) {
  try {
    const syntheticUid = `officer-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const res = await db
      .insert(users)
      .values({
        uid: syntheticUid,
        name: data.name,
        email: data.email,
        role: data.role,
      })
      .returning();
    return res[0];
  } catch (error) {
    console.error('createSystemOfficerUser failed:', error);
    throw new Error('Failed to add system officer user.', { cause: error });
  }
}

// Universal Update across ALL sections
export async function updateErpRecord(moduleKey: string, id: number, payload: Record<string, any>) {
  try {
    switch (moduleKey) {
      case 'employees': {
        const res = await db
          .update(employees)
          .set({
            empCode: String(payload.empCode),
            name: String(payload.name),
            designation: String(payload.designation),
            department: String(payload.department),
            baseSalary: Number(payload.baseSalary) || 0,
            hourlyOvertimeRate: Number(payload.hourlyOvertimeRate) || 0,
            phone: String(payload.phone),
            status: String(payload.status || 'Active'),
          })
          .where(eq(employees.id, id))
          .returning();
        return res[0];
      }
      case 'attendance': {
        const res = await db
          .update(attendanceLogs)
          .set({
            empCode: String(payload.empCode),
            empName: String(payload.empName),
            department: String(payload.department),
            date: String(payload.date),
            checkIn: String(payload.checkIn),
            checkOut: String(payload.checkOut),
            status: String(payload.status),
            overtimeHours: Number(payload.overtimeHours) || 0,
            notes: String(payload.notes || ''),
          })
          .where(eq(attendanceLogs.id, id))
          .returning();
        return res[0];
      }
      case 'payroll': {
        const baseSalary = Number(payload.baseSalary) || 0;
        const overtimeHours = Number(payload.overtimeHours) || 0;
        const overtimePay = Number(payload.overtimePay) || 0;
        const bonusAdditions = Number(payload.bonusAdditions) || 0;
        const deductions = Number(payload.deductions) || 0;
        const netPayable = Number(
          payload.netPayable ?? baseSalary + overtimePay + bonusAdditions - deductions
        );
        const res = await db
          .update(payrollRecords)
          .set({
            empCode: String(payload.empCode),
            empName: String(payload.empName),
            designation: String(payload.designation),
            monthYear: String(payload.monthYear),
            baseSalary,
            presentDays: Number(payload.presentDays) || 0,
            absentDays: Number(payload.absentDays) || 0,
            leaveDays: Number(payload.leaveDays) || 0,
            overtimeHours,
            overtimePay,
            bonusAdditions,
            deductions,
            netPayable,
            paymentStatus: String(payload.paymentStatus),
            paymentMethod: String(payload.paymentMethod),
          })
          .where(eq(payrollRecords.id, id))
          .returning();
        return res[0];
      }
      case 'inventory': {
        const res = await db
          .update(inventoryItems)
          .set({
            sku: String(payload.sku),
            name: String(payload.name),
            category: String(payload.category),
            unit: String(payload.unit),
            currentStock: Number(payload.currentStock) || 0,
            reorderLevel: Number(payload.reorderLevel) || 0,
            unitCost: Number(payload.unitCost) || 0,
            sellingPrice: Number(payload.sellingPrice) || 0,
            updatedAt: new Date(),
          })
          .where(eq(inventoryItems.id, id))
          .returning();
        return res[0];
      }
      case 'batches': {
        const actualYieldKg = Number(payload.actualYieldKg) || 0;
        const totalCogs = Number(payload.totalCogs) || 0;
        const costPerKg =
          actualYieldKg > 0 ? Number((totalCogs / actualYieldKg).toFixed(2)) : 0;
        const res = await db
          .update(productionBatches)
          .set({
            batchCode: String(payload.batchCode),
            mushroomVariety: String(payload.mushroomVariety),
            bagCount: Number(payload.bagCount) || 0,
            substrateKg: Number(payload.substrateKg) || 0,
            spawnKg: Number(payload.spawnKg) || 0,
            inoculationDate: String(payload.inoculationDate),
            expectedHarvestDate: String(payload.expectedHarvestDate),
            actualYieldKg,
            totalCogs,
            costPerKg,
            status: String(payload.status),
          })
          .where(eq(productionBatches.id, id))
          .returning();
        return res[0];
      }
      case 'wastage': {
        const res = await db
          .update(wastageLogs)
          .set({
            batchCode: String(payload.batchCode),
            itemName: String(payload.itemName),
            category: String(payload.category),
            quantity: Number(payload.quantity) || 0,
            unit: String(payload.unit),
            estimatedLossBdt: Number(payload.estimatedLossBdt) || 0,
            reason: String(payload.reason),
            loggedDate: String(payload.loggedDate),
          })
          .where(eq(wastageLogs.id, id))
          .returning();
        return res[0];
      }
      case 'sales': {
        const netPayableBdt = Number(payload.netPayableBdt) || 0;
        const paidAmountBdt = Number(payload.paidAmountBdt) || 0;
        const dueAmountBdt = Math.max(0, Number((netPayableBdt - paidAmountBdt).toFixed(2)));
        const status = dueAmountBdt <= 0 ? 'Paid' : paidAmountBdt > 0 ? 'Partial' : 'Due';
        const res = await db
          .update(salesInvoices)
          .set({
            invoiceNo: String(payload.invoiceNo),
            date: String(payload.date),
            channel: String(payload.channel),
            customerName: String(payload.customerName),
            customerPhone: String(payload.customerPhone),
            itemsSummary: String(payload.itemsSummary),
            subtotalBdt: Number(payload.subtotalBdt) || 0,
            totalDiscountBdt: Number(payload.totalDiscountBdt) || 0,
            netPayableBdt,
            paidAmountBdt,
            dueAmountBdt,
            paymentMethod: String(payload.paymentMethod),
            status,
          })
          .where(eq(salesInvoices.id, id))
          .returning();
        return res[0];
      }
      case 'expenses': {
        const res = await db
          .update(operatingExpenses)
          .set({
            voucherNo: String(payload.voucherNo),
            date: String(payload.date),
            category: String(payload.category),
            description: String(payload.description),
            amountBdt: Number(payload.amountBdt) || 0,
            paymentSource: String(payload.paymentSource),
            approvedBy: String(payload.approvedBy),
          })
          .where(eq(operatingExpenses.id, id))
          .returning();
        return res[0];
      }
      case 'equity': {
        const res = await db
          .update(equityRecords)
          .set({
            shareholderName: String(payload.shareholderName),
            designation: String(payload.designation),
            sharePercentage: Number(payload.sharePercentage) || 0,
            numberOfShares: Number(payload.numberOfShares) || 0,
            initialCapitalBdt: Number(payload.initialCapitalBdt) || 0,
            additionalInvestmentBdt: Number(payload.additionalInvestmentBdt) || 0,
            dividendPaidBdt: Number(payload.dividendPaidBdt) || 0,
            directorsLoanOrDrawingBdt: Number(payload.directorsLoanOrDrawingBdt) || 0,
            transactionType: String(payload.transactionType),
            lastTransactionDate: String(payload.lastTransactionDate),
          })
          .where(eq(equityRecords.id, id))
          .returning();
        return res[0];
      }
      case 'loans': {
        const principal = Number(payload.principalOrBillAmountBdt) || 0;
        const paid = Number(payload.totalPaidBdt) || 0;
        const outstanding = Number(
          payload.outstandingBalanceBdt ?? Math.max(0, principal - paid)
        );
        const res = await db
          .update(loansLiabilities)
          .set({
            referenceNo: String(payload.referenceNo),
            liabilityType: String(payload.liabilityType),
            lenderOrSupplierName: String(payload.lenderOrSupplierName),
            principalOrBillAmountBdt: principal,
            interestRatePct: Number(payload.interestRatePct) || 0,
            monthlyEmiBdt: Number(payload.monthlyEmiBdt) || 0,
            totalPaidBdt: paid,
            outstandingBalanceBdt: outstanding,
            nextDueDate: String(payload.nextDueDate),
            status: String(payload.status || (outstanding <= 0 ? 'Settled' : 'Active')),
          })
          .where(eq(loansLiabilities.id, id))
          .returning();
        return res[0];
      }
      case 'accounts': {
        const res = await db
          .update(bankCashAccounts)
          .set({
            accountName: String(payload.accountName),
            accountType: String(payload.accountType),
            accountNumber: String(payload.accountNumber),
            openingBalanceBdt: Number(payload.openingBalanceBdt) || 0,
            currentBalanceBdt: Number(payload.currentBalanceBdt) || 0,
            lastReconciledDate: String(payload.lastReconciledDate),
            updatedAt: new Date(),
          })
          .where(eq(bankCashAccounts.id, id))
          .returning();
        return res[0];
      }
      case 'transfers': {
        const res = await db
          .update(fundTransfers)
          .set({
            transferRef: String(payload.transferRef),
            date: String(payload.date),
            fromAccount: String(payload.fromAccount),
            toAccount: String(payload.toAccount),
            amountBdt: Number(payload.amountBdt) || 0,
            transferFeeBdt: Number(payload.transferFeeBdt) || 0,
            remarks: String(payload.remarks),
            executedBy: String(payload.executedBy || 'Admin'),
          })
          .where(eq(fundTransfers.id, id))
          .returning();
        return res[0];
      }
      case 'users': {
        const res = await db
          .update(users)
          .set({
            name: String(payload.name),
            email: String(payload.email),
            role: String(payload.role),
          })
          .where(eq(users.id, id))
          .returning();
        return res[0];
      }
      case 'audit': {
        const res = await db
          .update(auditLogs)
          .set({
            action: String(payload.action),
            module: String(payload.module),
            entityRef: String(payload.entityRef),
            details: String(payload.details),
          })
          .where(eq(auditLogs.id, id))
          .returning();
        return res[0];
      }
      default:
        throw new Error(`Unsupported moduleKey for update: ${moduleKey}`);
    }
  } catch (error) {
    console.error('updateErpRecord failed:', error);
    throw new Error('Failed to update record in database.', { cause: error });
  }
}

export async function deleteErpRecord(moduleKey: string, id: number) {
  try {
    switch (moduleKey) {
      case 'employees':
        await db.delete(employees).where(eq(employees.id, id));
        break;
      case 'attendance':
        await db.delete(attendanceLogs).where(eq(attendanceLogs.id, id));
        break;
      case 'payroll':
        await db.delete(payrollRecords).where(eq(payrollRecords.id, id));
        break;
      case 'inventory':
        await db.delete(inventoryItems).where(eq(inventoryItems.id, id));
        break;
      case 'batches':
        await db.delete(productionBatches).where(eq(productionBatches.id, id));
        break;
      case 'wastage':
        await db.delete(wastageLogs).where(eq(wastageLogs.id, id));
        break;
      case 'sales': {
        const existingInv = await db
          .select()
          .from(salesInvoices)
          .where(eq(salesInvoices.id, id));
        if (existingInv.length > 0) {
          let soldItems: { sku?: string; name?: string; qty?: number }[] = [];
          try {
            soldItems = JSON.parse(existingInv[0].itemsJson || '[]');
          } catch {
            soldItems = [];
          }
          if (soldItems.length > 0) {
            const allInventory = await db.select().from(inventoryItems);
            for (const line of soldItems) {
              const qtyToRestore = Number(line.qty) || 0;
              if (qtyToRestore <= 0) continue;
              const targetSku = String(line.sku || '').trim().toLowerCase();
              const targetName = String(line.name || '').trim().toLowerCase();
              const matchedItem = allInventory.find(
                (inv) =>
                  (targetSku && inv.sku.trim().toLowerCase() === targetSku) ||
                  (targetName && inv.name.trim().toLowerCase() === targetName)
              );
              if (matchedItem) {
                const restoredStock = Number(
                  (matchedItem.currentStock + qtyToRestore).toFixed(2)
                );
                await db
                  .update(inventoryItems)
                  .set({ currentStock: restoredStock, updatedAt: new Date() })
                  .where(eq(inventoryItems.id, matchedItem.id));
                matchedItem.currentStock = restoredStock;
              }
            }
          }
        }
        await db.delete(salesInvoices).where(eq(salesInvoices.id, id));
        break;
      }
      case 'expenses':
        await db.delete(operatingExpenses).where(eq(operatingExpenses.id, id));
        break;
      case 'equity':
        await db.delete(equityRecords).where(eq(equityRecords.id, id));
        break;
      case 'loans':
        await db.delete(loansLiabilities).where(eq(loansLiabilities.id, id));
        break;
      case 'accounts':
        await db.delete(bankCashAccounts).where(eq(bankCashAccounts.id, id));
        break;
      case 'transfers':
        await db.delete(fundTransfers).where(eq(fundTransfers.id, id));
        break;
      case 'users':
        await db.delete(users).where(eq(users.id, id));
        break;
      case 'audit':
        await db.delete(auditLogs).where(eq(auditLogs.id, id));
        break;
      default:
        throw new Error('Invalid module key for deletion');
    }
    return { deleted: true, id };
  } catch (error) {
    console.error('deleteErpRecord failed:', error);
    throw new Error('Failed to delete record from database.', { cause: error });
  }
}
