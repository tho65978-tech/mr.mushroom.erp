import { integer, pgTable, real, serial, text, timestamp } from 'drizzle-orm/pg-core';

// Users & RBAC (Module 9)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  name: text('name').notNull().default('System User'),
  role: text('role').notNull().default('Admin'), // Admin | Accountant | Manager
  createdAt: timestamp('created_at').defaultNow(),
});

// Module 1: Attendance & Payroll
export const employees = pgTable('employees', {
  id: serial('id').primaryKey(),
  empCode: text('emp_code').notNull(),
  name: text('name').notNull(),
  designation: text('designation').notNull(),
  department: text('department').notNull(),
  baseSalary: real('base_salary').notNull(),
  hourlyOvertimeRate: real('hourly_overtime_rate').notNull(),
  phone: text('phone').notNull(),
  status: text('status').notNull().default('Active'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const attendanceLogs = pgTable('attendance_logs', {
  id: serial('id').primaryKey(),
  empCode: text('emp_code').notNull(),
  empName: text('emp_name').notNull(),
  department: text('department').notNull(),
  date: text('date').notNull(),
  checkIn: text('check_in').notNull(),
  checkOut: text('check_out').notNull(),
  status: text('status').notNull(), // Present | Absent | Leave | Late
  overtimeHours: real('overtime_hours').notNull().default(0),
  notes: text('notes').notNull().default(''),
  createdAt: timestamp('created_at').defaultNow(),
});

export const payrollRecords = pgTable('payroll_records', {
  id: serial('id').primaryKey(),
  empCode: text('emp_code').notNull(),
  empName: text('emp_name').notNull(),
  designation: text('designation').notNull(),
  monthYear: text('month_year').notNull(),
  baseSalary: real('base_salary').notNull(),
  presentDays: integer('present_days').notNull(),
  absentDays: integer('absent_days').notNull(),
  leaveDays: integer('leave_days').notNull(),
  overtimeHours: real('overtime_hours').notNull(),
  overtimePay: real('overtime_pay').notNull(),
  bonusAdditions: real('bonus_additions').notNull(),
  deductions: real('deductions').notNull(),
  netPayable: real('net_payable').notNull(),
  paymentStatus: text('payment_status').notNull(), // Paid | Pending
  paymentMethod: text('payment_method').notNull(), // Bank | Cash | Bkash | Nagad
  createdAt: timestamp('created_at').defaultNow(),
});

// Module 2: Inventory & Batch Production
export const inventoryItems = pgTable('inventory_items', {
  id: serial('id').primaryKey(),
  sku: text('sku').notNull(),
  name: text('name').notNull(),
  category: text('category').notNull(), // Raw Material | Spawn & Culture | Packaging | Fresh Produce | Processed Product
  unit: text('unit').notNull(),
  currentStock: real('current_stock').notNull(),
  reorderLevel: real('reorder_level').notNull(),
  unitCost: real('unit_cost').notNull(),
  sellingPrice: real('selling_price').notNull(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const productionBatches = pgTable('production_batches', {
  id: serial('id').primaryKey(),
  batchCode: text('batch_code').notNull(),
  mushroomVariety: text('mushroom_variety').notNull(),
  bagCount: integer('bag_count').notNull(),
  substrateKg: real('substrate_kg').notNull(),
  spawnKg: real('spawn_kg').notNull(),
  inoculationDate: text('inoculation_date').notNull(),
  expectedHarvestDate: text('expected_harvest_date').notNull(),
  actualYieldKg: real('actual_yield_kg').notNull(),
  totalCogs: real('total_cogs').notNull(),
  costPerKg: real('cost_per_kg').notNull(),
  status: text('status').notNull(), // Incubation | Fruiting | Harvested | Processed
  createdAt: timestamp('created_at').defaultNow(),
});

export const wastageLogs = pgTable('wastage_logs', {
  id: serial('id').primaryKey(),
  batchCode: text('batch_code').notNull(),
  itemName: text('item_name').notNull(),
  category: text('category').notNull(), // Contamination | Post-Harvest Spoilage | Packaging Damage | Processing Loss
  quantity: real('quantity').notNull(),
  unit: text('unit').notNull(),
  estimatedLossBdt: real('estimated_loss_bdt').notNull(),
  reason: text('reason').notNull(),
  loggedDate: text('logged_date').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Module 3: Sales, POS & Invoicing
export const salesInvoices = pgTable('sales_invoices', {
  id: serial('id').primaryKey(),
  invoiceNo: text('invoice_no').notNull(),
  date: text('date').notNull(),
  channel: text('channel').notNull(), // Wholesale | Retail POS | E-commerce
  customerName: text('customer_name').notNull(),
  customerPhone: text('customer_phone').notNull(),
  itemsJson: text('items_json').notNull(), // JSON array of items with qty, price, itemDiscount
  itemsSummary: text('items_summary').notNull(),
  subtotalBdt: real('subtotal_bdt').notNull(),
  itemDiscountBdt: real('item_discount_bdt').notNull(),
  invoiceDiscountType: text('invoice_discount_type').notNull(), // Flat | Percentage
  invoiceDiscountValue: real('invoice_discount_value').notNull(),
  totalDiscountBdt: real('total_discount_bdt').notNull(),
  netPayableBdt: real('net_payable_bdt').notNull(),
  paidAmountBdt: real('paid_amount_bdt').notNull(),
  dueAmountBdt: real('due_amount_bdt').notNull(),
  paymentMethod: text('payment_method').notNull(), // Cash | Bank | Bkash | Nagad | Credit
  status: text('status').notNull(), // Paid | Partial | Due
  createdAt: timestamp('created_at').defaultNow(),
});

// Module 4: Operating Expenses (OpEx)
export const operatingExpenses = pgTable('operating_expenses', {
  id: serial('id').primaryKey(),
  voucherNo: text('voucher_no').notNull(),
  date: text('date').notNull(),
  category: text('category').notNull(),
  description: text('description').notNull(),
  amountBdt: real('amount_bdt').notNull(),
  paymentSource: text('payment_source').notNull(), // Cash in Hand | City Bank PLC | Dutch-Bangla Bank | Bkash Merchant | Nagad Business
  approvedBy: text('approved_by').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Module 5: Investment & Equity (Ltd. Company)
export const equityRecords = pgTable('equity_records', {
  id: serial('id').primaryKey(),
  shareholderName: text('shareholder_name').notNull(),
  designation: text('designation').notNull(),
  sharePercentage: real('share_percentage').notNull(),
  numberOfShares: integer('number_of_shares').notNull(),
  initialCapitalBdt: real('initial_capital_bdt').notNull(),
  additionalInvestmentBdt: real('additional_investment_bdt').notNull(),
  dividendPaidBdt: real('dividend_paid_bdt').notNull(),
  directorsLoanOrDrawingBdt: real('directors_loan_or_drawing_bdt').notNull(),
  transactionType: text('transaction_type').notNull(),
  lastTransactionDate: text('last_transaction_date').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Module 6: Loans & Liabilities
export const loansLiabilities = pgTable('loans_liabilities', {
  id: serial('id').primaryKey(),
  referenceNo: text('reference_no').notNull(),
  liabilityType: text('liability_type').notNull(), // Bank SME Loan | Equipment Lease EMI | Director Loan | Supplier Accounts Payable
  lenderOrSupplierName: text('lender_or_supplier_name').notNull(),
  principalOrBillAmountBdt: real('principal_or_bill_amount_bdt').notNull(),
  interestRatePct: real('interest_rate_pct').notNull(),
  monthlyEmiBdt: real('monthly_emi_bdt').notNull(),
  totalPaidBdt: real('total_paid_bdt').notNull(),
  outstandingBalanceBdt: real('outstanding_balance_bdt').notNull(),
  nextDueDate: text('next_due_date').notNull(),
  status: text('status').notNull(), // Active | Overdue | Settled
  createdAt: timestamp('created_at').defaultNow(),
});

// Module 7: Banking & Cash Reconciliation
export const bankCashAccounts = pgTable('bank_cash_accounts', {
  id: serial('id').primaryKey(),
  accountName: text('account_name').notNull(),
  accountType: text('account_type').notNull(), // Cash | Bank | Mobile Wallet
  accountNumber: text('account_number').notNull(),
  openingBalanceBdt: real('opening_balance_bdt').notNull(),
  currentBalanceBdt: real('current_balance_bdt').notNull(),
  lastReconciledDate: text('last_reconciled_date').notNull(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const fundTransfers = pgTable('fund_transfers', {
  id: serial('id').primaryKey(),
  transferRef: text('transfer_ref').notNull(),
  date: text('date').notNull(),
  fromAccount: text('from_account').notNull(),
  toAccount: text('to_account').notNull(),
  amountBdt: real('amount_bdt').notNull(),
  transferFeeBdt: real('transfer_fee_bdt').notNull(),
  remarks: text('remarks').notNull(),
  executedBy: text('executed_by').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Module 9: Audit Trail & Security
export const auditLogs = pgTable('audit_logs', {
  id: serial('id').primaryKey(),
  timestamp: text('timestamp').notNull(),
  userEmail: text('user_email').notNull(),
  userName: text('user_name').notNull(),
  userRole: text('user_role').notNull(),
  action: text('action').notNull(), // CREATE | UPDATE | DELETE | EXPORT | RECONCILE
  module: text('module').notNull(),
  entityRef: text('entity_ref').notNull(),
  details: text('details').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});
